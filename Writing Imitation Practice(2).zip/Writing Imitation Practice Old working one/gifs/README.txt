Place reusable reaction GIFs for UI feedback in this folder.

Current files:
- no-copy-paste.gif  -> shown when the user tries to paste the original sentence into the practice input.

Future idea:
- Add more GIFs here and register them in js/ui.js via GifFeedbackSystem.registerGif(...)
