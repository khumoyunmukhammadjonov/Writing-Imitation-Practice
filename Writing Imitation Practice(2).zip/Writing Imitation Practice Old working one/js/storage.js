const storageApp = window.WritingImitationPractice || (window.WritingImitationPractice = {});
storageApp.state = storageApp.state || {};
storageApp.services = storageApp.services || {};
storageApp.modules = storageApp.modules || {};
storageApp.utils = storageApp.utils || {};
storageApp.storage = storageApp.storage || {};
storageApp.dom = storageApp.dom || {};


/*
 * Storage and shared utility helpers.
 * Split from the legacy monolithic script for easier maintenance.
 */

/*
 * Main script for the Writing Imitation Practice Chrome extension.
 *
 * This script re‑implements the functionality of the standalone web
 * application provided by the user. All logic is self contained here.
 *
 * Note: The original implementation relied on the external "compromise"
 * library for sentence detection. For security and compliance reasons
 * remote code cannot be loaded in a Chrome extension. Instead, this
 * script defines a simple sentence splitting function that uses a
 * regular expression to break text into sentences. If more precise
 * sentence parsing is required, consider bundling a local NLP library
 * into the extension rather than loading it from a CDN.
 */

// 0. Sentence splitting helper.
// Prefer the locally bundled offline NLP shim when available so the
// extension keeps the old nlp(...).sentences().out('array') behavior.
// We do not trust it blindly though, because pasted text often arrives with
// missing terminal punctuation, line-broken sentences, bullets or abbreviations.
// This helper now sanitizes pasted text first and then cross-checks the NLP
// result against a more defensive local splitter.
function sanitizeArticleText(text) {
    if (text == null) return '';

    return String(text)
        .replace(/\r\n?/g, '\n')
        .replace(/[\u00A0\u2002-\u200B\u202F\u205F\u3000]/g, ' ')
        .replace(/\t+/g, ' ')
        .replace(/[ \f\v]+/g, ' ')
        .replace(/\n[ \t]+/g, '\n')
        .replace(/[ \t]+\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

function protectSentenceDots(text) {
    return String(text || '')
        .replace(/\b(?:[A-Z]\.){2,}/g, (match) => match.replace(/\./g, '∯'))
        .replace(/\b(?:e\.g|i\.e|etc|Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Mt|No|vs)\./gi, (match) => match.replace(/\./g, '∯'))
        .replace(/(\d)\.(\d)/g, '$1∯$2')
        .replace(/\b(?:https?:\/\/|www\.)\S+/gi, (match) => match.replace(/\./g, '∯'))
        .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, (match) => match.replace(/\./g, '∯'));
}

function restoreProtectedDots(text) {
    return String(text || '').replace(/∯/g, '.');
}

function splitLineBasedSentences(text) {
    return sanitizeArticleText(text)
        .split(/\n+/)
        .map((sentence) => sentence.trim())
        .filter(Boolean);
}

function splitSentencesHeuristically(text) {
    const cleaned = sanitizeArticleText(text);
    if (!cleaned) return [];

    const protectedText = protectSentenceDots(cleaned)
        .replace(/(^|\n)\s*(?:[-*•▪‣◦]|\d+[.)])\s+/g, '$1¶')
        .replace(/\n{2,}/g, '¶');

    const punctuated = protectedText.replace(
        /([.!?…]+(?:["'”’)\]]+)?)\s+(?=[“"'(\[]*[\p{L}\d])/gu,
        '$1¶'
    );

    let parts = punctuated
        .split('¶')
        .map((sentence) => restoreProtectedDots(sentence).replace(/\s+/g, ' ').trim())
        .filter(Boolean);

    if (parts.length <= 1 && /\n/.test(cleaned)) {
        parts = splitLineBasedSentences(cleaned);
    }

    return parts;
}

function splitSentences(text) {
    const cleaned = sanitizeArticleText(text);
    if (!cleaned) return [];

    const heuristicSentences = splitSentencesHeuristically(cleaned);
    const heuristicCoverage = heuristicSentences.join(' ').replace(/\s+/g, ' ').trim().length;
    const cleanedCoverage = cleaned.replace(/\s+/g, ' ').trim().length;

    try {
        if (typeof window.nlp === 'function') {
            const doc = window.nlp(cleaned);
            if (doc && typeof doc.sentences === 'function') {
                const nlpSentences = doc.sentences().out('array')
                    .map((sentence) => String(sentence).replace(/\s+/g, ' ').trim())
                    .filter(Boolean);

                if (nlpSentences.length) {
                    const nlpCoverage = nlpSentences.join(' ').replace(/\s+/g, ' ').trim().length;
                    const keepsCoverage = nlpCoverage >= Math.max(cleanedCoverage - 2, 1);
                    const keepsTrailingFragment = heuristicCoverage <= 0 || nlpCoverage >= heuristicCoverage - 2;

                    if (keepsCoverage && keepsTrailingFragment) {
                        return nlpSentences;
                    }
                }
            }
        }
    } catch (error) {
        console.warn('Local NLP sentence splitting failed. Falling back to heuristic splitter.', error);
    }

    return heuristicSentences.length ? heuristicSentences : [cleaned];
}

function normalizeSentenceTerminal(text) {
    return String(text || '')
        .replace(/\s+/g, ' ')
        .trim()
        .replace(/([.!?…]+)(?=(?:["'”’)\]]*)$)/gu, '')
        .replace(/["'”’)\]]+$/gu, '')
        .trim();
}

function areSentencesEquivalent(left, right) {
    const normalizedLeft = normalizeSentenceTerminal(left);
    const normalizedRight = normalizeSentenceTerminal(right);
    return normalizedLeft === normalizedRight;
}



function escapeValidationHTML(value) {
    return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

const SourceTextValidator = {
    maxIssuesToShow: 6,
    state: {
        status: 'idle',
        approved: false,
        issues: [],
        sourceHash: '',
        checkedText: '',
        checkedAt: 0,
        note: '',
        provider: 'local'
    },

    getState() {
        return { ...this.state, issues: Array.isArray(this.state.issues) ? [...this.state.issues] : [] };
    },

    hashText(text) {
        const normalized = sanitizeArticleText(text);
        let hash = 0;
        for (let i = 0; i < normalized.length; i += 1) {
            hash = ((hash << 5) - hash) + normalized.charCodeAt(i);
            hash |= 0;
        }
        return `${normalized.length}:${hash}`;
    },

    reset() {
        this.state = {
            status: 'idle',
            approved: false,
            issues: [],
            sourceHash: '',
            checkedText: '',
            checkedAt: 0,
            note: '',
            provider: 'local'
        };
        return this.getState();
    },

    approveCurrentText() {
        this.state.approved = true;
        if (this.state.status === 'issues') {
            this.state.note = 'You approved this text as-is. The original text stays unchanged.';
        }
        return this.getState();
    },

    hasUnapprovedIssues(text) {
        const incomingHash = this.hashText(text);
        return this.state.status === 'issues' && this.state.sourceHash === incomingHash && !this.state.approved;
    },

    localServerBaseUrl: 'http://localhost:8081/v2',

    async validate(text) {
        const cleaned = sanitizeArticleText(text);
        const sourceHash = this.hashText(cleaned);
        this.state = {
            status: cleaned ? 'checking' : 'idle',
            approved: false,
            issues: [],
            sourceHash,
            checkedText: cleaned,
            checkedAt: Date.now(),
            note: cleaned ? 'Checking with your local offline LanguageTool server…' : '',
            provider: 'local'
        };

        if (!cleaned) {
            return this.getState();
        }

        const localIssues = this.getLocalIssues(cleaned);
        let languageToolIssues = [];
        let provider = 'local heuristics';
        let note = 'Checked with built-in local heuristics only.';
        let serviceIssue = null;

        try {
            languageToolIssues = await this.getLanguageToolIssues(cleaned);
            provider = 'LanguageTool local + local heuristics';
            note = 'Checked with your offline LanguageTool server on localhost. The original text was not changed.';
        } catch (error) {
            console.warn('Local LanguageTool server unavailable. Using heuristic checks only.', error);
            serviceIssue = {
                severity: 'error',
                category: 'offline-checker',
                message: 'Local LanguageTool is not running. Start the offline server, then click Re-check.',
                context: 'Expected server: http://localhost:8081/v2/check',
                suggestions: ['Run start-languagetool-local.bat', 'Keep the server window open', 'Try Re-check']
            };
            note = 'Offline LanguageTool was not reachable, so only the built-in fallback rules ran. The original text was not changed.';
        }

        const issues = this.mergeIssues(localIssues, languageToolIssues, serviceIssue ? [serviceIssue] : []);
        this.state = {
            status: issues.length ? 'issues' : 'clean',
            approved: false,
            issues,
            sourceHash,
            checkedText: cleaned,
            checkedAt: Date.now(),
            note,
            provider
        };
        return this.getState();
    },

    mergeIssues(localIssues, remoteIssues, extraIssues = []) {
        const all = [...(Array.isArray(remoteIssues) ? remoteIssues : []), ...(Array.isArray(localIssues) ? localIssues : []), ...(Array.isArray(extraIssues) ? extraIssues : [])]
            .filter(Boolean)
            .map((issue) => ({
                severity: issue.severity || 'warning',
                category: issue.category || 'style',
                message: issue.message || 'Possible issue found.',
                context: issue.context || '',
                suggestions: Array.isArray(issue.suggestions) ? issue.suggestions.slice(0, 3) : []
            }));

        const seen = new Set();
        return all.filter((issue) => {
            const key = `${issue.category}|${issue.message}|${issue.context}`.toLowerCase();
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        }).sort((a, b) => {
            const score = { error: 0, warning: 1, info: 2 };
            return (score[a.severity] ?? 9) - (score[b.severity] ?? 9);
        });
    },

    async getLanguageToolIssues(text) {
        const controller = new AbortController();
        const timeoutId = window.setTimeout(() => controller.abort(), 5000);

        let response;
        try {
            response = await fetch(`${this.localServerBaseUrl}/check`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                },
                body: new URLSearchParams({
                    text,
                    language: 'en-US'
                }).toString(),
                signal: controller.signal
            });
        } finally {
            window.clearTimeout(timeoutId);
        }

        if (!response || !response.ok) {
            throw new Error(`LanguageTool local request failed with ${response ? response.status : 'no response'}`);
        }

        const payload = await response.json();
        const matches = Array.isArray(payload && payload.matches) ? payload.matches : [];

        return matches.map((match) => {
            const offset = Math.max(0, Number(match.offset) || 0);
            const length = Math.max(1, Number(match.length) || 1);
            const context = text.slice(Math.max(0, offset - 25), Math.min(text.length, offset + length + 25)).trim();
            const categoryId = String(match?.rule?.category?.id || '').toLowerCase();
            const issueType = String(match?.rule?.issueType || '').toLowerCase();
            const severity = /misspelling|typographical|grammar/.test(issueType) || /typos|grammar/.test(categoryId)
                ? 'error'
                : /punctuation|casing/.test(issueType + ' ' + categoryId)
                    ? 'warning'
                    : 'info';

            return {
                severity,
                category: categoryId || issueType || 'style',
                message: String(match.message || 'Possible issue found.'),
                context,
                suggestions: Array.isArray(match.replacements)
                    ? match.replacements.slice(0, 3).map((item) => item && item.value).filter(Boolean)
                    : []
            };
        });
    },

    getLocalIssues(text) {
        const issues = [];
        const sentences = splitSentences(text);

        sentences.forEach((sentence) => {
            const trimmed = String(sentence || '').trim();
            if (!trimmed) return;

            if (!/[.!?…]["'”’)]*$/.test(trimmed)) {
                issues.push({
                    severity: 'warning',
                    category: 'punctuation',
                    message: 'This sentence may be missing ending punctuation.',
                    context: trimmed
                });
            }

            if (/\s[,.;!?]/.test(trimmed)) {
                issues.push({
                    severity: 'warning',
                    category: 'spacing',
                    message: 'There may be an extra space before punctuation.',
                    context: trimmed
                });
            }

            if (/[,.;:!?]{2,}/.test(trimmed) || /\.\.{4,}/.test(trimmed)) {
                issues.push({
                    severity: 'warning',
                    category: 'punctuation',
                    message: 'Repeated punctuation looks unusual.',
                    context: trimmed
                });
            }
        });

        const typoPatterns = [
            [/\bteh\b/gi, 'Possible typo: “teh”'],
            [/\brecieve\b/gi, 'Possible typo: “recieve”'],
            [/\bseperate\b/gi, 'Possible typo: “separate”'],
            [/\bdefinately\b/gi, 'Possible typo: “definitely”'],
            [/\boccured\b/gi, 'Possible typo: “occurred”']
        ];
        typoPatterns.forEach(([pattern, message]) => {
            const match = text.match(pattern);
            if (match) {
                issues.push({
                    severity: 'error',
                    category: 'spelling',
                    message,
                    context: match[0]
                });
            }
        });

        return issues;
    }
};

storageApp.services.sourceTextValidator = SourceTextValidator;
window.SourceTextValidator = SourceTextValidator;

const APP_STORAGE_KEYS = [
    'activeSession',
    'lastStatsReset',
    'practiceStats',
    'spacedSchedule',
    'textControls',
    'theme',
    'todayStats',
    'wordList',
    'writingProgress',
    'reviewDueCache'
];

const NativeWindowLocalStorage = window.localStorage;

const ExtensionStorage = {
    cache: {},
    ready: null,

    async init() {
        if (this.ready) {
            return this.ready;
        }

        this.ready = (async () => {
            let chromeData = {};

            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                try {
                    chromeData = await chrome.storage.local.get(APP_STORAGE_KEYS);
                } catch (error) {
                    console.warn('Unable to read chrome.storage.local. Falling back to in-memory cache.', error);
                }
            }

            const hasChromeData = APP_STORAGE_KEYS.some((key) => Object.prototype.hasOwnProperty.call(chromeData, key));
            const migratedData = {};

            if (!hasChromeData && NativeWindowLocalStorage) {
                APP_STORAGE_KEYS.forEach((key) => {
                    const value = NativeWindowLocalStorage.getItem(key);
                    if (value !== null) {
                        migratedData[key] = value;
                    }
                });

                if (Object.keys(migratedData).length && typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                    try {
                        await chrome.storage.local.set(migratedData);
                    } catch (error) {
                        console.warn('Unable to migrate saved data into chrome.storage.local.', error);
                    }
                }
            }

            const merged = { ...migratedData, ...chromeData };
            this.cache = {};

            APP_STORAGE_KEYS.forEach((key) => {
                if (!Object.prototype.hasOwnProperty.call(merged, key)) {
                    return;
                }

                const value = merged[key];
                this.cache[key] = typeof value === 'string' ? value : JSON.stringify(value);
            });
        })();

        return this.ready;
    },

    get length() {
        return this.entries().length;
    },

    entries() {
        return APP_STORAGE_KEYS
            .filter((key) => Object.prototype.hasOwnProperty.call(this.cache, key))
            .map((key) => [key, this.cache[key]]);
    },

    key(index) {
        const entry = this.entries()[index];
        return entry ? entry[0] : null;
    },

    getItem(key) {
        const normalizedKey = String(key);
        return Object.prototype.hasOwnProperty.call(this.cache, normalizedKey)
            ? this.cache[normalizedKey]
            : null;
    },

    setItem(key, value) {
        const normalizedKey = String(key);
        const stringValue = String(value);
        this.cache[normalizedKey] = stringValue;

        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ [normalizedKey]: stringValue }).catch((error) => {
                console.warn(`Unable to persist key "${normalizedKey}" in chrome.storage.local.`, error);
            });
        }

        if (NativeWindowLocalStorage) {
            try {
                NativeWindowLocalStorage.removeItem(normalizedKey);
            } catch (error) {
                console.warn(`Unable to clear legacy localStorage key "${normalizedKey}".`, error);
            }
        }
    },

    removeItem(key) {
        const normalizedKey = String(key);
        delete this.cache[normalizedKey];

        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.remove(normalizedKey).catch((error) => {
                console.warn(`Unable to remove key "${normalizedKey}" from chrome.storage.local.`, error);
            });
        }

        if (NativeWindowLocalStorage) {
            try {
                NativeWindowLocalStorage.removeItem(normalizedKey);
            } catch (error) {
                console.warn(`Unable to clear legacy localStorage key "${normalizedKey}".`, error);
            }
        }
    },

    clearOwnedKeys() {
        APP_STORAGE_KEYS.forEach((key) => {
            delete this.cache[key];
        });

        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.remove(APP_STORAGE_KEYS).catch((error) => {
                console.warn('Unable to clear saved extension data from chrome.storage.local.', error);
            });
        }

        if (NativeWindowLocalStorage) {
            APP_STORAGE_KEYS.forEach((key) => {
                try {
                    NativeWindowLocalStorage.removeItem(key);
                } catch (error) {
                    console.warn(`Unable to clear legacy localStorage key "${key}".`, error);
                }
            });
        }
    }
};

function getStoredJSON(key, fallback) {
    const raw = ExtensionStorage.getItem(key);

    if (typeof raw !== 'string') {
        return fallback;
    }

    try {
        const parsed = JSON.parse(raw);
        return parsed == null ? fallback : parsed;
    } catch (error) {
        console.warn(`Saved data for "${key}" is invalid and has been reset.`, error);
        ExtensionStorage.removeItem(key);
        return fallback;
    }
}

function normalizeWordKey(value) {
    return String(value ?? '')
        .replace(/[.,!?]/g, '')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
}

function escapeHTML(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/**
 * computeStorageUsage
 *
 * Computes an approximate chrome.storage.local usage in MB. Updates the UI
 * label and the storage bar fill width. Returns used MB.
 */
function computeStorageUsage() {
    let bytes = 0;

    try {
        ExtensionStorage.entries().forEach(([key, value]) => {
            bytes += ((key ? key.length : 0) + (value ? value.length : 0)) * 2;
        });
    } catch (e) {
        bytes = 0;
    }

    const storageLimitMB = 10;
    const usedMB = bytes / (1024 * 1024);

    const usageEl = document.getElementById('storage-usage');
    if (usageEl) {
        usageEl.textContent = `Used ${usedMB.toFixed(2)} MB of ${storageLimitMB} MB`;
    }

    const barFill = document.getElementById('storage-bar-fill');
    if (barFill) {
        const percent = Math.min(Math.max((usedMB / storageLimitMB) * 100, 0), 100);
        barFill.style.width = percent.toFixed(2) + '%';
        if (percent >= 90) {
            barFill.classList.add('storage-warning');
            if (usageEl) usageEl.textContent += ' – storage almost full!';
        } else {
            barFill.classList.remove('storage-warning');
        }
    }

    return usedMB;
}

Object.assign(storageApp.utils, { sanitizeArticleText, splitSentences, areSentencesEquivalent, escapeHTML, computeStorageUsage });
Object.assign(storageApp.storage, {
    APP_STORAGE_KEYS,
    NativeWindowLocalStorage,
    ExtensionStorage,
    getStoredJSON
});
storageApp.modules.storage = {
    sanitizeArticleText,
    splitSentences,
    areSentencesEquivalent,
    ExtensionStorage,
    getStoredJSON,
    normalizeWordKey,
    escapeHTML,
    computeStorageUsage
};
