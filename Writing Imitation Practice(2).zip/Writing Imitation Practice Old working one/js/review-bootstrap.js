
(function () {
  function parseMaybeJSON(value, fallback) {
    if (value == null) return fallback;
    if (typeof value !== 'string') return value;
    try {
      const parsed = JSON.parse(value);
      return parsed == null ? fallback : parsed;
    } catch (error) {
      return fallback;
    }
  }

  function getLaunchContextState() {
    try {
      const params = new URLSearchParams(window.location.search || '');
      const kind = String(params.get('reviewKind') || '').trim();
      const count = Number(params.get('reviewCount') || 0);
      if (!kind || !Number.isFinite(count) || count <= 0) {
        return null;
      }
      return { kind, count, source: 'launch-context' };
    } catch (error) {
      return null;
    }
  }

  function normalizeWordKey(value) {
    return String(value ?? '')
      .replace(/[.,!?]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function getWordListKeySet(wordListRaw) {
    const set = new Set();
    const list = Array.isArray(wordListRaw) ? wordListRaw : [];
    list.forEach((entry) => {
      if (typeof entry === 'string') {
        const key = normalizeWordKey(entry);
        if (key) set.add(key);
        return;
      }
      if (entry && typeof entry === 'object') {
        const key = normalizeWordKey(entry.word || entry.text || entry.value || entry.label || '');
        if (key) set.add(key);
      }
    });
    return set;
  }

  function getPendingInitialMistakes(todayStatsRaw) {
    const todayStats = todayStatsRaw && typeof todayStatsRaw === 'object' ? todayStatsRaw : {};
    const mistakes = Array.isArray(todayStats.mistakes) ? todayStats.mistakes : [];
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayStartMs = todayStart.getTime();

    return mistakes.filter((mistake) => {
      if (!mistake || mistake.type === 'wordList' || mistake.spaced) {
        return false;
      }
      const baseCorrect = normalizeWordKey(mistake.correct || mistake.incorrect || '');
      if (!baseCorrect) {
        return false;
      }
      const timestamp = mistake.timestamp ? new Date(mistake.timestamp).getTime() : Number.NaN;
      return Number.isNaN(timestamp) || timestamp < todayStartMs;
    });
  }

  function parseScheduleKey(scheduleKey, entry) {
    const raw = String(scheduleKey || '');
    if (raw.includes(':')) {
      const [prefix, ...rest] = raw.split(':');
      return {
        type: entry && entry.type ? entry.type : (prefix === 'wordList' ? 'wordList' : 'mistake'),
        word: rest.join(':')
      };
    }
    return {
      type: entry && entry.type === 'wordList' ? 'wordList' : 'mistake',
      word: raw
    };
  }

  function computeWarningState(raw) {
    const reviewDueCache = parseMaybeJSON(raw && raw.reviewDueCache, {}) || {};
    const wordList = parseMaybeJSON(raw && raw.wordList, []) || [];
    const todayStats = parseMaybeJSON(raw && raw.todayStats, {}) || {};

    const pendingMistakes = getPendingInitialMistakes(todayStats);
    if (pendingMistakes.length > 0) {
      return { kind: 'pendingMistakes', count: pendingMistakes.length };
    }

    const wordSet = getWordListKeySet(wordList);
    const blockedPendingWordSet = new Set(
      pendingMistakes.map((item) => normalizeWordKey(item && (item.correct || item.incorrect || ''))).filter(Boolean)
    );

    let dueMistakes = Array.isArray(reviewDueCache.dueMistakes) ? reviewDueCache.dueMistakes.length : 0;
    let dueVocab = Array.isArray(reviewDueCache.dueWordList) ? reviewDueCache.dueWordList.filter((word) => wordSet.has(normalizeWordKey(word))).length : 0;

    if (!dueMistakes && !dueVocab) {
      const schedule = parseMaybeJSON(raw && raw.spacedSchedule, {}) || {};
      const now = Date.now();
      Object.entries(schedule || {}).forEach(([scheduleKey, entry]) => {
        if (!entry || entry.mastered) return;
        const nextDue = Number(entry.nextDue);
        if (!Number.isFinite(nextDue) || nextDue > now) return;
        const parsed = parseScheduleKey(scheduleKey, entry);
        const word = normalizeWordKey(parsed.word);
        if (!word) return;
        if (parsed.type === 'wordList') {
          if (wordSet.has(word)) dueVocab += 1;
          return;
        }
        if (!blockedPendingWordSet.has(word)) {
          dueMistakes += 1;
        }
      });
    }

    if (dueMistakes > 0) return { kind: 'dueMistakes', count: dueMistakes };
    if (dueVocab > 0) return { kind: 'dueVocab', count: dueVocab };
    return { kind: 'none', count: 0 };
  }

  function applyState(state) {
    const warningBox = document.getElementById('practice-warning');
    const textEl = document.getElementById('practice-warning-text');
    const warningBtn = document.getElementById('practice-warning-btn');
    if (!warningBox || !textEl || !warningBtn) return;

    const articleInput = document.getElementById('article-input');
    const startBtn = document.getElementById('start-button');
    const kind = state && state.kind ? state.kind : 'none';
    const count = Number(state && state.count) || 0;
    const active = kind !== 'none' && count > 0;

    if (!active) {
      warningBox.style.display = 'none';
      warningBox.classList.remove('active');
      return;
    }

    if (kind === 'pendingMistakes') {
      textEl.textContent = `You have ${count} spelling mistake${count === 1 ? '' : 's'} from earlier practice to rewrite first.`;
      warningBtn.textContent = 'Rewrite Now';
    } else if (kind === 'dueMistakes') {
      textEl.textContent = `You have ${count} word${count === 1 ? '' : 's'} ready to review from previous sessions.`;
      warningBtn.textContent = 'Practice Now';
    } else if (kind === 'dueVocab') {
      textEl.textContent = `You have ${count} word${count === 1 ? '' : 's'} ready to review from your word list.`;
      warningBtn.textContent = 'Review Now';
    }

    warningBox.style.display = 'flex';
    warningBox.classList.add('active');
    if (articleInput) {
      articleInput.setAttribute('disabled', 'disabled');
      articleInput.setAttribute('readonly', 'true');
      articleInput.classList.add('disabled-input');
    }
    if (startBtn) {
      startBtn.setAttribute('disabled', 'disabled');
      startBtn.classList.add('disabled-input');
    }

    window.__tugadiBootWarningState = state;
  }

  function runBootWarning() {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
    chrome.storage.local.get(['reviewDueCache', 'todayStats', 'wordList', 'spacedSchedule']).then((raw) => {
      const state = computeWarningState(raw || {});
      applyState(state);
    }).catch(() => {});
  }

  const launchState = getLaunchContextState();
  if (launchState) {
    window.__tugadiBootWarningState = launchState;
    applyState(launchState);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runBootWarning, { once: true });
  } else {
    runBootWarning();
  }
})();
