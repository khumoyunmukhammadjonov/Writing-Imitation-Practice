const practiceApp = window.WritingImitationPractice || (window.WritingImitationPractice = {});
practiceApp.state = practiceApp.state || {};
practiceApp.services = practiceApp.services || {};
practiceApp.modules = practiceApp.modules || {};
practiceApp.utils = practiceApp.utils || {};
practiceApp.storage = practiceApp.storage || {};
practiceApp.dom = practiceApp.dom || {};


/*
 * Core sentence practice flow and state management.
 */

practiceApp.state.practice = practiceApp.state.practice || {
    sentences: [],
    currentSentenceIndex: 0,
    mistakeCount: 0,
    currentSentenceMistakeSet: new Set(),
    currentSentenceUsedAlt: false,
    isTransitioning: false,
    lastSubmissionAt: 0,
    lastSubmissionSignature: null
};

function resetPracticeSubmissionState() {
    const state = getPracticeState();
    state.isTransitioning = false;
    state.lastSubmissionAt = 0;
    state.lastSubmissionSignature = null;
}

function getPracticeState() {
    return practiceApp.state.practice;
}

function getStatisticsManager() {
    return practiceApp.getStatisticsManager ? practiceApp.getStatisticsManager() : window.statisticsManager;
}

function focusUserInputSoon() {
    const applyFocus = () => {
        const userInputField = document.getElementById('user-input');
        if (!userInputField || userInputField.style.display === 'none' || userInputField.disabled) {
            return;
        }

        try {
            userInputField.focus({ preventScroll: true });
        } catch (error) {
            try {
                userInputField.focus();
            } catch (focusError) {
                /* ignore */
            }
        }
    };

    if (typeof window !== 'undefined' && typeof window.requestAnimationFrame === 'function') {
        window.requestAnimationFrame(() => {
            window.requestAnimationFrame(applyFocus);
        });
        return;
    }

    setTimeout(applyFocus, 0);
}

// 5. Core Practice Functions
function processArticle() {
    const state = getPracticeState();
    const articleInputField = document.getElementById('article-input');
    const articleInput = sanitizeArticleText(articleInputField ? articleInputField.value : '');
    if (articleInputField) {
        articleInputField.value = articleInput;
    }

    clearProgress();
    restartPractice();
    state.sentences = splitSentences(articleInput);

    if (state.sentences && state.sentences.length > 0) {
        state.currentSentenceIndex = 0;
        state.mistakeCount = 0;
        updateProgressBar();
        showSentence();

        document.getElementById('practice-section').style.display = 'block';
        document.getElementById('start-button').classList.add('hidden');
        document.getElementById('article-input').classList.add('hidden');

        const manager = getStatisticsManager();
        if (manager && typeof manager.startPracticeSession === 'function') {
            manager.startPracticeSession();
        }

        saveProgress();
    } else {
        showTransientMessage('Please paste a valid article.');
    }
}

// 6. Text Processing Functions
function normalizeText(text) {
    return text
        .replace(/[\u2018\u2019\u201B\u2032\u2035\u0060]/g, "'")
        .replace(/[\u201C\u201D\u201F\u2033\u2036]/g, '"')
        .replace(/[\u2010\u2011\u2012\u2013\u2014\u2015\u2212]/g, '-')
        .replace(/\u2026/g, '...')
        .replace(/\.{2,}/g, '...')
        .replace(/[\u00A0\u2002-\u200B\u202F\u205F\u3000]/g, ' ')
        .replace(/\s+/g, ' ')
        .replace(/[\u2010\u2011]/g, '-')
        .replace(/[\u2012\u2013]/g, '-')
        .replace(/[\u2014\u2015]/g, '-')
        .trim();
}

// 10. Progress Bar Management
function updateProgressBar() {
    const state = getPracticeState();
    const progressBarFill = document.getElementById('progress-bar-fill');
    if (!progressBarFill) {
        return;
    }

    const total = state.sentences.length || 1;
    const progress = (state.currentSentenceIndex / total) * 100;
    progressBarFill.style.width = progress + '%';
    progressBarFill.innerText = Math.round(progress) + '%';
    progressBarFill.setAttribute('aria-valuenow', Math.round(progress));
}

// 12. Sentence Management
function showSentence() {
    const state = getPracticeState();

    if (state.currentSentenceIndex < state.sentences.length) {
        state.currentSentenceMistakeSet = new Set();
        state.currentSentenceUsedAlt = false;
        resetPracticeSubmissionState();
        const originalSentenceElement = document.getElementById('original-sentence');
        originalSentenceElement.innerText = state.sentences[state.currentSentenceIndex].trim();
        ColorManager.updateOriginalSentenceColor(true);

        document.getElementById('user-input').value = '';
        ResultManager.clearResult();
        updateProgressBar();
        saveProgress();
        focusUserInputSoon();
    } else {
        showCompletionMessage();
    }
}

function getCompletionSummaryData(session) {
    const sentenceCount = Math.max(0, Number(session && session.sentences) || 0);
    const durationMinutes = Math.max(0, Number(session && session.duration) || 0);
    const mistakeTotal = Math.max(0, Number(session && session.mistakes) || 0);
    const successRate = Math.max(0, Math.min(100, Number(session && session.successRate) || 0));
    const firstTrySuccessRate = Math.max(0, Math.min(100, Number(session && (session.firstTrySuccessRate ?? session.successRate)) || 0));
    const altUsageRate = Math.max(0, Math.min(100, Number(session && session.altUsageRate) || 0));

    return {
        title: 'You have completed the practice.',
        subtitle: 'Here is how this session went.',
        metrics: [
            {
                label: 'Sentences',
                value: sentenceCount,
                tone: ''
            },
            {
                label: 'Time',
                value: formatCompletionDuration(durationMinutes),
                tone: ''
            },
            {
                label: 'Mistakes',
                value: mistakeTotal,
                tone: mistakeTotal === 0 ? 'good' : 'bad'
            },
            {
                label: 'Success',
                value: `${successRate}%`,
                tone: successRate >= 80 ? 'good' : successRate >= 50 ? 'warn' : 'bad'
            },
            {
                label: 'Clean Pass',
                value: `${firstTrySuccessRate}%`,
                tone: firstTrySuccessRate >= 80 ? 'good' : firstTrySuccessRate >= 50 ? 'warn' : 'bad'
            },
            {
                label: 'Alt help',
                value: `${altUsageRate}%`,
                tone: altUsageRate === 0 ? 'good' : altUsageRate <= 35 ? 'warn' : 'bad'
            }
        ]
    };
}

function formatCompletionDuration(minutes) {
    const totalMinutes = Math.max(0, Number(minutes) || 0);
    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    return `${hours}h ${mins}m`;
}

function buildCompletionSummaryHTML(summaryData) {
    if (!summaryData || !Array.isArray(summaryData.metrics) || !summaryData.metrics.length) {
        return escapeHTML('You have completed the practice.');
    }

    const metricsHTML = summaryData.metrics
        .map((metric) => {
            const toneClass = metric && metric.tone ? ` ${escapeHTML(metric.tone)}` : '';
            return `
                <div class="history-stat${toneClass}">
                    <span class="history-stat-label">${escapeHTML(metric.label || '')}</span>
                    <span class="history-stat-value">${escapeHTML(metric.value || 0)}</span>
                </div>`;
        })
        .join('');

    return `
        <div class="practice-complete-summary">
            <div class="practice-complete-title">${escapeHTML(summaryData.title || 'You have completed the practice.')}</div>
            <div class="practice-complete-subtitle">${escapeHTML(summaryData.subtitle || '')}</div>
            <div class="history-stats practice-complete-stats">${metricsHTML}</div>
        </div>`;
}

function renderCompletionMessage(summaryData) {
    const originalSentenceElement = document.getElementById('original-sentence');
    if (!originalSentenceElement) {
        return;
    }

    originalSentenceElement.innerHTML = buildCompletionSummaryHTML(summaryData);
    originalSentenceElement.classList.add('completed-message');
    ColorManager.updateOriginalSentenceColor(true);
}

function showCompletionMessage() {
    const state = getPracticeState();
    const manager = getStatisticsManager();
    state.isTransitioning = true;

    document.getElementById('user-input').style.display = 'none';
    document.getElementById('check-button').style.display = 'none';
    ResultManager.clearResult();

    if (manager && typeof manager.endPracticeSession === 'function') {
        manager.endPracticeSession(state.currentSentenceIndex);
    }

    const latestSession = manager && manager.stats && Array.isArray(manager.stats.practiceHistory)
        ? manager.stats.practiceHistory[0]
        : null;
    renderCompletionMessage(getCompletionSummaryData(latestSession || {
        sentences: state.currentSentenceIndex,
        duration: manager && manager.todayStats ? manager.todayStats.practiceTime : 0,
        mistakes: manager && typeof manager.currentSessionMistakes === 'number' ? manager.currentSessionMistakes : 0,
        successRate: 0,
        firstTrySuccessRate: 0,
        altUsageRate: 0
    }));

    saveProgress();
}

// 13. Text Checking System
function resolveCurrentSentenceMistakes() {
    const state = getPracticeState();
    const manager = getStatisticsManager();

    try {
        if (!manager || !manager.todayStats) {
            return;
        }

        const set = state.currentSentenceMistakeSet;
        if (!set || set.size === 0) {
            return;
        }

        const list = manager.todayStats.mistakes || [];
        manager.todayStats.mistakes = list.filter((item) => {
            const baseCorrect = (item.correct || '').replace(/[.,!?]/g, '').toLowerCase();
            const isTracked = set.has(baseCorrect);
            return !(isTracked && !item.spaced);
        });
        manager.saveTodayStats();
        manager.updateUI();
        state.currentSentenceMistakeSet = new Set();
    } catch (error) {
        console.error('Failed to resolve current sentence mistakes:', error);
    }
}


const PUNCTUATION_REMINDER_REGEX = /[.,!?;:'"“”‘’()\[\]{}…-]/g;

function stripPunctuationForReminder(text) {
    return String(text || '')
        .replace(PUNCTUATION_REMINDER_REGEX, '')
        .replace(/\s+/g, ' ')
        .trim();
}

function escapeReminderHTML(value) {
    if (typeof escapeHTML === 'function') {
        return escapeHTML(String(value || ''));
    }
    return String(value || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function normalizePunctuationLabel(char) {
    const labels = {
        '.': 'period',
        ',': 'comma',
        '?': 'question mark',
        '!': 'exclamation mark',
        ':': 'colon',
        ';': 'semicolon',
        '...': 'ellipsis',
        '…': 'ellipsis',
        '"': 'quotation mark',
        "'": 'apostrophe',
        '(': 'parenthesis',
        ')': 'parenthesis',
        '[': 'bracket',
        ']': 'bracket',
        '{': 'brace',
        '}': 'brace',
        '-': 'hyphen'
    };
    return labels[char] || 'punctuation';
}

function collectPunctuationCounts(value) {
    const counts = new Map();
    const matches = String(value || '').match(PUNCTUATION_REMINDER_REGEX) || [];
    matches.forEach((char) => {
        const normalized = /[“”]/.test(char) ? '"' : /[‘’]/.test(char) ? "'" : char;
        counts.set(normalized, (counts.get(normalized) || 0) + 1);
    });
    return counts;
}

function buildHighlightedPunctuationToken(referenceToken, typedToken) {
    const reference = String(referenceToken || '');
    const typed = String(typedToken || '');
    if (!reference && !typed) {
        return null;
    }

    const referenceCounts = collectPunctuationCounts(reference);
    const typedCounts = collectPunctuationCounts(typed);
    const missingMarks = new Set();
    const extraMarks = new Set();
    const labels = [];

    const allMarks = new Set([...referenceCounts.keys(), ...typedCounts.keys()]);
    allMarks.forEach((mark) => {
        const refCount = referenceCounts.get(mark) || 0;
        const typedCount = typedCounts.get(mark) || 0;
        if (refCount > typedCount) {
            missingMarks.add(mark);
            labels.push(normalizePunctuationLabel(mark));
        } else if (typedCount > refCount) {
            extraMarks.add(mark);
            labels.push(normalizePunctuationLabel(mark));
        }
    });

    const source = missingMarks.size > 0 ? reference : typed || reference;
    const activeMarks = missingMarks.size > 0 ? missingMarks : extraMarks;
    if (!source || activeMarks.size === 0) {
        return null;
    }

    const markup = Array.from(source).map((char) => {
        const normalized = /[“”]/.test(char) ? '"' : /[‘’]/.test(char) ? "'" : char;
        if (activeMarks.has(normalized) && /[.,!?;:'"“”‘’()\[\]{}…-]/.test(char)) {
            return `<span class="punctuation-feedback-mark">${escapeReminderHTML(char)}</span>`;
        }
        return escapeReminderHTML(char);
    }).join('');

    return {
        markup: `<span class="punctuation-feedback-token ${missingMarks.size > 0 ? 'expected' : 'typed'}">${markup}</span>`,
        labels
    };
}

function getPunctuationReminderFeedback(userInput, originalSentence) {
    const originalNormalized = normalizeText(originalSentence || '');
    const userNormalized = normalizeText(userInput || '');

    if (!originalNormalized || !userNormalized || originalNormalized === userNormalized) {
        return null;
    }

    if (stripPunctuationForReminder(originalNormalized) !== stripPunctuationForReminder(userNormalized)) {
        return null;
    }

    const originalWords = originalNormalized.split(' ');
    const userWords = userNormalized.split(' ');
    const length = Math.max(originalWords.length, userWords.length);
    const fragments = [];
    const labels = [];

    for (let i = 0; i < length; i += 1) {
        const originalWord = originalWords[i] || '';
        const userWord = userWords[i] || '';
        if (originalWord === userWord) {
            continue;
        }
        if (stripPunctuationForReminder(originalWord) !== stripPunctuationForReminder(userWord)) {
            return null;
        }
        const highlighted = buildHighlightedPunctuationToken(originalWord, userWord);
        if (highlighted && highlighted.markup) {
            fragments.push(highlighted.markup);
            labels.push.apply(labels, highlighted.labels || []);
        }
    }

    if (!fragments.length) {
        return null;
    }

    const uniqueLabels = Array.from(new Set(labels.filter(Boolean)));
    let message = 'Almost correct — check the punctuation here.';
    if (uniqueLabels.length === 1) {
        message = `Almost correct — fix the ${uniqueLabels[0]}.`;
    } else if (uniqueLabels.length > 1) {
        message = `Almost correct — fix the ${uniqueLabels.join(', ')}.`;
    }

    return {
        message,
        fragments
    };
}

function isPunctuationOnlyDifference(referenceText, typedText) {
    const reference = normalizeText(referenceText || '');
    const typed = normalizeText(typedText || '');

    if (!reference || !typed || reference === typed) {
        return false;
    }

    return stripPunctuationForReminder(reference) === stripPunctuationForReminder(typed);
}

function checkText() {
    const state = getPracticeState();
    const manager = getStatisticsManager();
    const userInputField = document.getElementById('user-input');

    if (!userInputField || state.isTransitioning || state.currentSentenceIndex >= state.sentences.length) {
        return { status: 'ignored' };
    }

    if (userInputField.style.display === 'none') {
        return { status: 'ignored' };
    }

    const originalSentence = normalizeText((state.sentences[state.currentSentenceIndex] || '').trim());
    const rawUserInput = userInputField.value.trim();
    const submissionSignature = `${state.currentSentenceIndex}::${rawUserInput}`;
    const now = Date.now();

    if (!rawUserInput) {
        if (state.lastSubmissionSignature !== submissionSignature) {
            state.lastSubmissionSignature = submissionSignature;
            state.lastSubmissionAt = now;
            if (ResultManager && typeof ResultManager.showEmptyInput === 'function') {
                ResultManager.showEmptyInput();
            } else if (typeof showTransientMessage === 'function') {
                showTransientMessage('Write the sentence first.');
            }
        }
        try {
            userInputField.focus();
        } catch (error) {
            /* ignore */
        }
        return { status: 'ignored-empty' };
    }

    if (state.lastSubmissionSignature === submissionSignature && (now - (state.lastSubmissionAt || 0)) < 1200) {
        return { status: 'ignored-duplicate' };
    }

    state.lastSubmissionSignature = submissionSignature;
    state.lastSubmissionAt = now;

    if (/\s{2,}/.test(rawUserInput)) {
        userInputField.value = rawUserInput.replace(/\s+/g, ' ');
        ResultManager.showSpacingError();
        return { status: 'spacing' };
    }

    if (manager && typeof manager.updateStreak === 'function') {
        manager.updateStreak();
    }

    const userInput = normalizeText(rawUserInput);

    const originalWords = originalSentence.split(' ');
    const userWords = userInput.split(' ');
    let correctWords = '';
    let incorrectWordFound = false;
    let incorrectWord = '';
    let correctWord = '';

    for (let i = 0; i < userWords.length; i += 1) {
        if (userWords[i] === originalWords[i]) {
            correctWords += userWords[i] + ' ';
        } else {
            incorrectWordFound = true;
            incorrectWord = userWords[i];
            correctWord = originalWords[i];
            break;
        }
    }

    const punctuationReminder = getPunctuationReminderFeedback(userInput, originalSentence);
    const punctuationOnlySentenceMismatch = isPunctuationOnlyDifference(originalSentence, userInput);
    const punctuationOnlyWordMismatch = incorrectWordFound && isPunctuationOnlyDifference(correctWord, incorrectWord);

    if (punctuationReminder || punctuationOnlySentenceMismatch || punctuationOnlyWordMismatch) {
        ResultManager.showErrorMessage(incorrectWord || rawUserInput, correctWord || originalSentence);

        document.getElementById('user-input').value = correctWords;
        state.mistakeCount += 1;

        if (manager && typeof manager.recordMistake === 'function') {
            manager.recordMistake(incorrectWord || rawUserInput, correctWord || originalSentence, { skipReviewEntry: true });
        }

        document
            .getElementById('user-input')
            .addEventListener('input', ResultManager.clearResult, { once: true });
        updateProgressBar();
        saveProgress();
        return { status: 'punctuation-mismatch', incorrectWord, correctWord };
    }

    if (userInput === originalSentence) {
        state.isTransitioning = true;
        ResultManager.showSuccess();

        if (state.currentSentenceMistakeSet && state.currentSentenceMistakeSet.size > 0) {
            state.currentSentenceMistakeSet = new Set();
        }

        if (manager && typeof manager.recordSentenceCompletion === 'function') {
            manager.recordSentenceCompletion(state.mistakeCount === 0);
        } else if (state.mistakeCount === 0 && manager && typeof manager.recordFirstTrySuccess === 'function') {
            manager.recordFirstTrySuccess();
        }

        state.currentSentenceIndex += 1;
        saveProgress();

        setTimeout(() => {
            ResultManager.clearResult();
            resetPracticeSubmissionState();
            showSentence();
        }, 1000);

        if (state.mistakeCount >= 2) {
            ResultManager.showMistakeCount(state.mistakeCount);
            state.mistakeCount = 0;
            state.currentSentenceIndex -= 1;
        } else {
            state.mistakeCount = 0;
        }
    } else if (incorrectWordFound) {
        ResultManager.showErrorMessage(incorrectWord, correctWord);
        document.getElementById('user-input').value = correctWords;
        state.mistakeCount += 1;

        const punctuationOnlyWordError = isPunctuationOnlyDifference(correctWord, incorrectWord);
        const normalizedIncorrectWord = stripPunctuationForReminder(incorrectWord || '').toLowerCase();
        const normalizedCorrectWord = stripPunctuationForReminder(correctWord || '').toLowerCase();

        if (manager && typeof manager.recordMistake === 'function') {
            if (punctuationOnlyWordError) {
                manager.recordMistake(incorrectWord, correctWord, { skipReviewEntry: true });
            } else if (normalizedIncorrectWord !== normalizedCorrectWord) {
                manager.recordMistake(incorrectWord, correctWord);
                state.currentSentenceMistakeSet.add(normalizedCorrectWord);
            }
        } else if (!punctuationOnlyWordError && normalizedIncorrectWord !== normalizedCorrectWord) {
            state.currentSentenceMistakeSet.add(normalizedCorrectWord);
        }

        document
            .getElementById('user-input')
            .addEventListener('input', ResultManager.clearResult, { once: true });
        updateProgressBar();
        saveProgress();
        return { status: 'error', incorrectWord, correctWord };
    } else {
        ResultManager.showProgress();
        updateProgressBar();
        saveProgress();
        return { status: 'partial' };
    }

    updateProgressBar();
    saveProgress();
    return { status: 'success' };
}

// 15. Progress Management
function saveProgress() {
    const state = getPracticeState();
    const progressData = {
        currentSentenceIndex: state.currentSentenceIndex,
        mistakeCount: state.mistakeCount,
        sentences: state.sentences,
        articleInput: document.getElementById('article-input').value,
        userInput: document.getElementById('user-input').value,
        practiceVisible: document.getElementById('practice-section').style.display,
        startButtonHidden: document.getElementById('start-button').classList.contains('hidden'),
        articleInputHidden: document.getElementById('article-input').classList.contains('hidden'),
        isCompleted: state.currentSentenceIndex >= state.sentences.length && state.sentences.length > 0,
        userInputDisplay: document.getElementById('user-input').style.display,
        checkButtonDisplay: document.getElementById('check-button').style.display,
        completionMessage: document.getElementById('original-sentence').innerText,
        completionHTML: document.getElementById('original-sentence').innerHTML,
        currentSentenceUsedAlt: Boolean(state.currentSentenceUsedAlt)
    };

    ExtensionStorage.setItem('writingProgress', JSON.stringify(progressData));
}

function loadSavedProgress() {
    const state = getPracticeState();
    const progressData = getStoredJSON('writingProgress', null);

    if (!progressData) {
        return;
    }

    state.currentSentenceIndex = progressData.currentSentenceIndex || 0;
    state.mistakeCount = progressData.mistakeCount || 0;
    state.sentences = progressData.sentences || [];
    state.currentSentenceMistakeSet = new Set();
    state.currentSentenceUsedAlt = Boolean(progressData.currentSentenceUsedAlt);
    resetPracticeSubmissionState();

    document.getElementById('article-input').value = progressData.articleInput || '';
    document.getElementById('user-input').value = progressData.userInput || '';

    if (state.sentences.length > 0) {
        if (progressData.isCompleted) {
            const originalSentenceElement = document.getElementById('original-sentence');
            if (progressData.completionHTML) {
                originalSentenceElement.innerHTML = progressData.completionHTML;
            } else {
                originalSentenceElement.innerText = progressData.completionMessage || 'You have completed the practice.';
            }
            originalSentenceElement.classList.add('completed-message');
            ColorManager.updateOriginalSentenceColor(true);
            document.getElementById('user-input').style.display = progressData.userInputDisplay || 'none';
            document.getElementById('check-button').style.display = progressData.checkButtonDisplay || 'none';
        } else {
            showSentence();
        }

        document.getElementById('practice-section').style.display = progressData.practiceVisible || 'block';
        if (progressData.startButtonHidden) {
            document.getElementById('start-button').classList.add('hidden');
        }
        if (progressData.articleInputHidden) {
            document.getElementById('article-input').classList.add('hidden');
        }
        updateProgressBar();
    }
}

function clearProgress() {
    const state = getPracticeState();
    ExtensionStorage.removeItem('writingProgress');
    state.currentSentenceIndex = 0;
    state.mistakeCount = 0;
    state.sentences = [];
    state.currentSentenceMistakeSet = new Set();
    state.currentSentenceUsedAlt = false;
    resetPracticeSubmissionState();

    document.getElementById('article-input').value = '';
    document.getElementById('user-input').value = '';
    document.getElementById('original-sentence').innerText = '';
    document.getElementById('original-sentence').classList.remove('completed-message');
    resetPracticeSubmissionState();
    document.getElementById('user-input').style.display = 'block';
    document.getElementById('check-button').style.display = 'inline';
    ResultManager.clearResult();

    const progressBarFill = document.getElementById('progress-bar-fill');
    if (progressBarFill) {
        progressBarFill.style.width = '0%';
        progressBarFill.innerText = '0%';
        progressBarFill.setAttribute('aria-valuenow', '0');
    }
}

// 16. UI Event Handlers
function hideOriginalSentence() {
    ColorManager.updateOriginalSentenceColor(false);
    ResultManager.clearResult();
}

function showOriginalSentence() {
    ColorManager.updateOriginalSentenceColor(true);

    const state = getPracticeState();
    const manager = getStatisticsManager();
    const hasActiveSentence = Array.isArray(state.sentences) &&
        state.sentences.length > 0 &&
        state.currentSentenceIndex >= 0 &&
        state.currentSentenceIndex < state.sentences.length;

    if (!hasActiveSentence || state.currentSentenceUsedAlt) {
        return;
    }

    state.currentSentenceUsedAlt = true;

    if (manager && typeof manager.recordAltUsage === 'function') {
        manager.recordAltUsage(state.currentSentenceIndex);
    }

    saveProgress();
}

function handleKeyDown(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        if (event.repeat) {
            return;
        }
        checkText();
    } else if (event.key === 'Alt') {
        event.preventDefault();
        showOriginalSentence();
    } else if (!event.altKey) {
        hideOriginalSentence();
    }
}

// 17. Practice Reset
function restartPractice() {
    const manager = getStatisticsManager();

    clearProgress();
    document.getElementById('practice-section').style.display = 'none';
    document.getElementById('start-button').classList.remove('hidden');
    document.getElementById('article-input').classList.remove('hidden');
    document.getElementById('article-input').value = '';
    document.getElementById('user-input').value = '';
    document.getElementById('user-input').style.display = 'block';
    document.getElementById('check-button').style.display = 'inline';
    ResultManager.clearResult();
    document.getElementById('original-sentence').innerText = '';
    document.getElementById('original-sentence').classList.remove('completed-message');

    // Restart should behave like the older builds: fully reset the *session* UI
    // and also reset the "Practice Time" timer back to 0 for the next run.
    // (Users treat Restart as "start fresh" rather than "continue accumulating".)
    if (manager && typeof manager.resetDailyStats === 'function') {
        manager.resetDailyStats();
    } else if (manager && typeof manager.resetSessionStats === 'function') {
        manager.resetSessionStats();
        // Fallback: ensure practice time doesn't linger in the UI.
        try {
            if (manager.todayStats) {
                manager.todayStats.practiceTime = 0;
                if (typeof manager.saveTodayStats === 'function') {
                    manager.saveTodayStats();
                }
                if (typeof manager.updateUI === 'function') {
                    manager.updateUI();
                }
            }
        } catch (e) {
            /* ignore */
        }
    }

    if (typeof computeStorageUsage === 'function') {
        computeStorageUsage();
    }

    const progressBarFill = document.getElementById('progress-bar-fill');
    if (progressBarFill) {
        progressBarFill.style.width = '0%';
        progressBarFill.innerText = '0%';
        progressBarFill.setAttribute('aria-valuenow', '0');
    }
}

// 18. Utility Functions
function removeLineBreaks(text) {
    return text.replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim();
}

practiceApp.modules.practice = {
    processArticle,
    normalizeText,
    updateProgressBar,
    showSentence,
    showCompletionMessage,
    resolveCurrentSentenceMistakes,
    checkText,
    saveProgress,
    loadSavedProgress,
    clearProgress,
    hideOriginalSentence,
    showOriginalSentence,
    handleKeyDown,
    restartPractice,
    removeLineBreaks
};
