const wordListApp = window.WritingImitationPractice || (window.WritingImitationPractice = {});
wordListApp.state = wordListApp.state || {};
wordListApp.services = wordListApp.services || {};
wordListApp.modules = wordListApp.modules || {};
wordListApp.utils = wordListApp.utils || {};
wordListApp.storage = wordListApp.storage || {};
wordListApp.dom = wordListApp.dom || {};


/*
 * Word list rendering, review modal flow, and review warning state.
 */

function sanitizeWordList(rawList) {
    const list = Array.isArray(rawList) ? rawList : [];
    const seen = new Set();
    const cleaned = [];

    list.forEach((item) => {
        const rawWord = String(item ?? '').replace(/\s+/g, ' ').trim();
        const key = normalizeWordKey(rawWord);

        if (!key || seen.has(key)) {
            return;
        }

        seen.add(key);
        cleaned.push(rawWord);
    });

    return cleaned;
}

function getStoredWordList() {
    const stored = getStoredJSON('wordList', []);
    const cleaned = sanitizeWordList(stored);

    const changed = cleaned.length !== stored.length ||
        cleaned.some((word, index) => word !== stored[index]);

    if (changed) {
        ExtensionStorage.setItem('wordList', JSON.stringify(cleaned));
    }

    return cleaned;
}

function getWordListKeySet(wordList) {
    return new Set((wordList || []).map((word) => normalizeWordKey(word)).filter(Boolean));
}

// 7. Word List Management
function displayWordList() {
    const wordListRaw = getStoredWordList();
    const wordListElement = document.getElementById('word-list');
    const wordSet = getWordListKeySet(wordListRaw);

    if (!wordListElement) {
        return;
    }

    if (typeof SpacedRepetitionManager !== 'undefined' &&
        typeof SpacedRepetitionManager.pruneWordListEntries === 'function') {
        SpacedRepetitionManager.pruneWordListEntries(wordSet);
    }

    // If empty, show a simple message
    if (wordListRaw.length === 0) {
        wordListElement.innerHTML = '<li class="empty-state">Your word list is empty. Select text and use the context menu to add words.</li>';
        // Update notification status
        if (typeof updateWordListNotification === 'function') {
            updateWordListNotification();
        }
        return;
    }
    // Before building the list, ensure that every word in the user's personal
    // vocabulary has an entry in the spaced‑repetition schedule. Without
    // this, newly added words might not display a spacing label if the
    // schedule was not initialised correctly. We do not reset existing
    // intervals; instead we only add missing entries with the 'wordList'
    // type and leave existing ones untouched. This guarantees that every
    // vocabulary item always shows a "review in X days" label.
    if (typeof SpacedRepetitionManager !== 'undefined') {
        (wordListRaw || []).forEach(w => {
            const clean = normalizeWordKey(w);
            const existingEntry = typeof SpacedRepetitionManager.getEntry === 'function'
                ? SpacedRepetitionManager.getEntry(clean, 'wordList')
                : (SpacedRepetitionManager.schedule ? SpacedRepetitionManager.schedule[clean] : null);
            if (!existingEntry) {
                // Record the word into the spaced schedule without altering
                // current practice intervals. This schedules its first review
                // for tomorrow by default.
                SpacedRepetitionManager.recordWord(clean, 'wordList');
            }
        });
        // Persist any type updates back to ExtensionStorage
        SpacedRepetitionManager.saveSchedule();
    }

    // Build an array of objects with the word, its original index, and due status
    const now = Date.now();
    const words = wordListRaw.map((word, idx) => {
        const cleanLower = normalizeWordKey(word);
        let entry = null;
        let due = false;
        let mastered = false;
        let label = '';
        if (typeof SpacedRepetitionManager !== 'undefined') {
            entry = typeof SpacedRepetitionManager.getEntry === 'function'
                ? SpacedRepetitionManager.getEntry(cleanLower, 'wordList')
                : (SpacedRepetitionManager.schedule ? SpacedRepetitionManager.schedule[cleanLower] : null);
            if (entry && entry.type === 'wordList') {
                mastered = Boolean(entry.mastered);
                if (mastered) {
                    due = false;
                    label = 'Mastered';
                } else {
                    const diff = entry.nextDue - now;
                    if (diff <= 0) {
                        due = true;
                        label = ''; // Due items already show a big Review button
                    } else {
                        const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
                        label = `Review in ${days} day${days === 1 ? '' : 's'}`;
                    }
                }
            }
        }
        return { word, index: idx, due, mastered, label };
    });
    // Sort so that due vocabulary items appear first
    words.sort((a, b) => {
        if (a.mastered !== b.mastered) {
            return a.mastered ? 1 : -1;
        }
        const dueDiff = (b.due === true) - (a.due === true);
        if (dueDiff !== 0) return dueDiff;
        return a.index - b.index;
    });
    // Generate HTML for each word
    const listHtml = words.map(item => {
        // Build the spaced repetition label
        const statusClasses = ['spaced-info', 'review-status'];
        if (item.due) statusClasses.push('due');
        if (item.mastered) statusClasses.push('mastered');
        const spacedInfoDiv = item.label
            ? `<span class="${statusClasses.join(' ')}">${escapeHTML(item.label)}</span>`
            : '';
        let spacedClass = '';
        if (item.label) {
            spacedClass = ' spaced';
        }
        // Determine classes for due vocabulary
        const dueClass = item.due ? ' due-vocab' : '';
        const masteredClass = item.mastered ? ' mastered-vocab' : '';
        // Inline practice was removed in favor of the dedicated modal flow.
        const practiceSection = '';
        // Attach data attributes for later event binding. Because Chrome's
        // extension CSP disallows inline event handlers, we cannot rely on
        // onclick attributes. Instead, we add data attributes to identify
        // each clickable word and review button. After injecting the list
        // into the DOM we will attach event listeners programmatically.
        const dataset = `data-index="${item.index}" data-due="${item.due}"`;
        // Build the review button markup only for due words. The button
        // includes a data-index attribute for event handling.
        const reviewButton = item.due
            ? `<button class="word-review-btn" data-index="${item.index}" aria-label="Review word"><i class="fi fi-rr-refresh" aria-hidden="true"></i><span>Review</span></button>`
            : '';
        const actionsClass = item.due ? '' : ' no-review';
        return `
            <li class="word-list-item${spacedClass}${dueClass}${masteredClass}">
                <div class="word-row">
                    <div class="word-info">
                        <div class="word-topline">
                            <span class="clickable-word" ${dataset}>${escapeHTML(item.word)}</span>
                            ${spacedInfoDiv}
                        </div>
                    </div>
                    <div class="word-actions${actionsClass}">
                        ${reviewButton}
                        <button class="remove-word-btn" data-index="${item.index}" aria-label="Remove word" title="Remove word"><i class="fi fi-rr-trash" aria-hidden="true"></i></button>
                    </div>
                </div>
                ${practiceSection}
            </li>`;
    }).join('');
    // Inject into DOM
    wordListElement.innerHTML = listHtml;
    // Attach remove button handlers
    document.querySelectorAll('.remove-word-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const index = parseInt(this.dataset.index);
            const listItem = this.closest('li');
            const currentList = getStoredWordList();
            const targetWord = currentList[index] || 'this word';

            showConfirmation(`Remove "${targetWord}" from your word list?`, function(confirmed) {
                if (!confirmed) return;
                // Add animation class for fade out
                if (listItem) listItem.classList.add('deleting');
                // Wait for animation to complete before updating the list and schedule
                setTimeout(() => {
                    const refreshedList = getStoredWordList();
                    const removedWord = refreshedList.splice(index, 1)[0];
                    ExtensionStorage.setItem('wordList', JSON.stringify(refreshedList));
                    // Remove the word from spaced repetition schedule as well
                    if (removedWord && typeof SpacedRepetitionManager !== 'undefined') {
                        SpacedRepetitionManager.removeWord(normalizeWordKey(removedWord), 'wordList');
                    }
                    displayWordList();
                    // Update warnings and notifications when a word is removed
                    if (typeof showPracticeWarning === 'function') {
                        showPracticeWarning();
                    }
                }, 220);
            });
        });
    });
    // Attach click handlers for clickable words and review buttons. Inline
    // event attributes are not allowed by the extension's CSP, so we
    // register listeners here using the data attributes defined above.
    document.querySelectorAll('.clickable-word').forEach(span => {
        const idx = parseInt(span.dataset.index);
        // Always open the definition when clicking the word itself. Due
        // vocabulary items should not automatically trigger practice when
        // clicking the word; the refresh icon is used for practice. Remove
        // any previous handlers before adding the new one.
        span.onclick = null;
        span.addEventListener('click', function() {
            const word = wordListRaw[idx];
            if (!word) return;
            const url = 'https://duckduckgo.com/?q=definition+of+' + encodeURIComponent(word) + '&kad=en_US';
            window.open(url, '_blank');
        });
    });
    // Attach practice handlers for the refresh button on due words.
    // Due vocabulary is practised in the dedicated modal so the word list
    // stays compact and the definition link remains separate from review.
    document.querySelectorAll('.word-review-btn').forEach(btn => {
        const idx = parseInt(btn.dataset.index);
        // Remove any previously attached handlers
        btn.onclick = null;
        btn.addEventListener('click', function() {
            // Launch the dedicated modal practice interface for this word
            openWordPracticeModal(idx);
        });
    });
    // Update practice warnings after refreshing the word list. This ensures that
    // the unified practice warning reflects the latest due status and that
    // controls are enabled or disabled appropriately.
    if (typeof showPracticeWarning === 'function') {
        showPracticeWarning();
    }
}

// -----------------------------------------------------------------------------
// Word Practice Modal: Due vocabulary practice in a dedicated overlay
//
// To improve usability and avoid layout issues within the Word List, due
// vocabulary items are practised inside a separate modal overlay. The
// three‑step process mirrors the inline rewrite UI: copy, reconstruct, recall.
// These helpers open the modal, handle step progression and closing. When
// practice completes successfully the spaced repetition schedule is updated
// and the list refreshed. Failures reset the schedule and allow retry.

/**
 * Open the practice modal for a given word index. This function prepares the
 * modal UI by resetting steps, populating the displays with the word and
 * masked versions, and attaching keydown listeners. It then shows the
 * modal and focuses the first input.
 *
 * @param {number} index - The index of the word in the word list.
 */
function openWordPracticeModal(index) {
    const wordList = getStoredWordList();
    const word = wordList[index];
    if (!word) return;

    const clean = String(word || '').replace(/[.,!?]/g, '').replace(/\s+/g, ' ').trim();
    const correctLower = normalizeWordKey(word);
    const masked = '*'.repeat(clean.length);

    const openDefinition = () => {
        const url = 'https://duckduckgo.com/?q=definition+of+' + encodeURIComponent(clean) + '&kad=en_US';
        window.open(url, '_blank');
    };

    // Step indicator now includes Step 0 (Definition)
    const stepIndicator = document.getElementById('practice-modal-steps');
    if (stepIndicator) {
        const spans = stepIndicator.querySelectorAll('.step');
        spans.forEach((span, i) => {
            span.classList.remove('completed');
            span.classList.toggle('active', i === 0);
        });
    }

    // Populate the definition gate
    const defWord = document.getElementById('practice-modal-definition-word');
    if (defWord) defWord.textContent = clean;

    // Populate word displays for each rewrite step
    const display1 = document.getElementById('practice-modal-word-display-1');
    const display3 = document.getElementById('practice-modal-word-display-3');
    if (display1) display1.textContent = clean;
    if (display3) display3.textContent = masked;

    // Reset input fields and remove feedback classes
    for (let i = 1; i <= 3; i++) {
        const input = document.getElementById(`practice-modal-input-${i}`);
        if (input) {
            input.value = '';
            input.classList.remove('correct', 'incorrect');
            input.onkeydown = null;
            input.oninput = null;
            input.placeholder = i === 1 ? 'Copy the word' : (i === 2 ? 'Tap the letters in order' : 'Type from memory');
            input.readOnly = i === 2;
            if (i === 2) {
                input.setAttribute('aria-readonly', 'true');
            } else {
                input.removeAttribute('aria-readonly');
            }
        }
        const bank = document.getElementById(`practice-modal-letter-bank-${i}`);
        if (bank) {
            bank.innerHTML = '';
            bank.style.display = i === 2 ? 'block' : 'none';
        }
    }

    // Show only the definition step at first
    const step0 = document.getElementById('practice-modal-step-0');
    const step1 = document.getElementById('practice-modal-step-1');
    const step2 = document.getElementById('practice-modal-step-2');
    const step3 = document.getElementById('practice-modal-step-3');
    if (step0) step0.style.display = 'block';
    if (step1) step1.style.display = 'none';
    if (step2) step2.style.display = 'none';
    if (step3) step3.style.display = 'none';

    const input1 = document.getElementById('practice-modal-input-1');
    const input2 = document.getElementById('practice-modal-input-2');
    const input3 = document.getElementById('practice-modal-input-3');
    const bank2 = document.getElementById('practice-modal-letter-bank-2');

    const attachTypingHandler = (inputEl, step) => {
        if (!inputEl) return;
        inputEl.oninput = () => {
            inputEl.classList.remove('correct', 'incorrect');
        };
        inputEl.onkeydown = (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                if (inputEl.readOnly) return;
                handlePracticeModalStep(step, correctLower);
            }
        };
    };

    attachTypingHandler(input1, 1);
    attachTypingHandler(input3, 3);

    if (typeof setupLetterRebuild === 'function' && input2 && bank2) {
        setupLetterRebuild({
            target: clean,
            inputEl: input2,
            bankEl: bank2,
            instructionText: 'Tap the scrambled letters in order.',
            onComplete: () => handlePracticeModalStep(2, correctLower)
        });
    }

    // Wire up definition gate buttons
    const openBtn = document.getElementById('practice-modal-open-definition');
    const continueBtn = document.getElementById('practice-modal-continue');

    // Require an explicit click on "Open definition" before proceeding.
    // (No auto-opening on modal launch.)
    let definitionOpened = false;

    if (continueBtn) {
        continueBtn.disabled = true;
        continueBtn.setAttribute('aria-disabled', 'true');
    }

    if (openBtn) {
        openBtn.onclick = (e) => {
            e.preventDefault();
            openDefinition();
            definitionOpened = true;

            if (continueBtn) {
                continueBtn.disabled = false;
                continueBtn.removeAttribute('aria-disabled');
                // Make the next action obvious after they return.
                continueBtn.focus();
            }
        };
    }

    if (continueBtn) {
        continueBtn.onclick = (e) => {
            e.preventDefault();
            if (!definitionOpened) return;

            if (step0) step0.style.display = 'none';
            if (step1) step1.style.display = 'block';

            // Mark Definition done, Copy active
            if (stepIndicator) {
                const spans = stepIndicator.querySelectorAll('.step');
                if (spans[0]) {
                    spans[0].classList.remove('active');
                    spans[0].classList.add('completed');
                }
                if (spans[1]) {
                    spans[1].classList.add('active');
                }
            }

            if (input1) input1.focus();
        };
    }

    // Show the modal
    const modal = document.getElementById('word-practice-modal');
    if (modal) {
        modal.style.display = 'flex';
    }

    // Focus Continue so the user must intentionally proceed
    if (continueBtn) continueBtn.focus();

    window.currentPracticeModalIndex = index;
    window.currentPracticeModalWord = correctLower;
}

/**
 * Handle progression through the practice modal steps. Step 1 (Copy) and
 * Step 3 (Recall) validate typed input, while Step 2 (Reconstruct)
 * completes via the scrambled-letter helper. On completion it records
 * success with SpacedRepetitionManager, closes the modal and refreshes
 * the word list. On failure it records a failed review, resets the input
 * and allows retry.
 *
 * @param {number} step - The current step (1, 2 or 3).
 * @param {string} correctLower - The correct word in lowercase.
 */
function handlePracticeModalStep(step, correctLower) {
    const inputEl = document.getElementById(`practice-modal-input-${step}`);
    if (!inputEl) return;
    const user = inputEl.value.trim().toLowerCase();
    const steps = document.querySelectorAll('#practice-modal-steps .step');
    if (user === correctLower) {
        inputEl.classList.add('correct');
        inputEl.classList.remove('incorrect');
        if (steps[step]) {
            steps[step].classList.remove('active');
            steps[step].classList.add('completed');
        }
        if (step < 3 && steps[step + 1]) {
            steps[step + 1].classList.add('active');
        }
        setTimeout(() => {
            if (step < 3) {
                // Advance to the next panel
                document.getElementById(`practice-modal-step-${step}`).style.display = 'none';
                document.getElementById(`practice-modal-step-${step + 1}`).style.display = 'block';
                const nextInput = document.getElementById(`practice-modal-input-${step + 1}`);
                if (nextInput) {
                    nextInput.focus();
                    nextInput.classList.remove('correct', 'incorrect');
                }
            } else {
                // Completed all steps successfully. Advance spaced schedule
                if (typeof SpacedRepetitionManager !== 'undefined') {
                    SpacedRepetitionManager.recordReviewResult(correctLower, true, 'wordList');
                }
                closeWordPracticeModal();
                // Refresh list and warnings
                displayWordList();
                if (typeof showPracticeWarning === 'function') {
                    showPracticeWarning();
                }
            }
        }, 1000);
    } else {
        inputEl.classList.add('incorrect');
        inputEl.classList.remove('correct');
        // Record failure in spaced repetition
        if (typeof SpacedRepetitionManager !== 'undefined') {
            SpacedRepetitionManager.recordReviewResult(correctLower, false, 'wordList');
        }
        setTimeout(() => {
            inputEl.classList.remove('incorrect');
            inputEl.value = '';
            inputEl.focus();
        }, 500);
    }
}

/**
 * Close the practice modal without completing. This simply hides the modal.
 * If a word review is abandoned early, we do not mark it as a failure or
 * success; the next due time remains unchanged. The user may re‑open the
 * modal later to continue the review.
 */
function closeWordPracticeModal() {
    const modal = document.getElementById('word-practice-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Expose modal helpers globally so inline HTML or other scripts can call them
window.openWordPracticeModal = openWordPracticeModal;
window.handlePracticeModalStep = handlePracticeModalStep;
window.closeWordPracticeModal = closeWordPracticeModal;

/**
 * Show or hide the practice warning depending on the number of unpracticed
 * spelling mistakes from previous sessions. It checks the spaced repetition
 * schedule for due items of type 'mistake'. If there are any, the warning
 * box is displayed with the count; otherwise it is hidden.
 */

function applyPracticeWarningState(state) {
    const warningBox = document.getElementById('practice-warning');
    const textEl = document.getElementById('practice-warning-text');
    const warningBtn = document.getElementById('practice-warning-btn');
    const articleInput = document.getElementById('article-input');
    const startBtn = document.getElementById('start-button');

    if (!warningBox || !textEl || !warningBtn) {
        return;
    }

    const kind = state && state.kind ? state.kind : 'none';
    const count = Number(state && state.count) || 0;
    const active = kind !== 'none' && count > 0;

    if (!active) {
        warningBox.style.display = 'none';
        warningBox.classList.remove('active');
        warningBtn.onclick = null;
        if (articleInput) {
            articleInput.removeAttribute('disabled');
            articleInput.removeAttribute('readonly');
            articleInput.classList.remove('disabled-input');
        }
        if (startBtn) {
            startBtn.removeAttribute('disabled');
            startBtn.classList.remove('disabled-input');
        }
        return;
    }

    warningBox.style.display = 'flex';
    warningBox.classList.add('active');

    if (kind === 'pendingMistakes') {
        textEl.textContent = `You have ${count} spelling mistake${count === 1 ? '' : 's'} from earlier practice to rewrite first.`;
        warningBtn.textContent = 'Rewrite Now';
        warningBtn.onclick = function() {
            if (typeof openMistakesPanel === 'function') {
                openMistakesPanel({ focusSection: 'mistakes', highlightReview: false });
            }
        };
    } else if (kind === 'dueMistakes') {
        textEl.textContent = `You have ${count} word${count === 1 ? '' : 's'} ready to review from previous sessions.`;
        warningBtn.textContent = 'Practice Now';
        warningBtn.onclick = function() {
            if (typeof openMistakesPanel === 'function') {
                openMistakesPanel({ focusSection: 'mistakes', highlightReview: true });
            }
        };
    } else if (kind === 'dueVocab') {
        textEl.textContent = `You have ${count} word${count === 1 ? '' : 's'} ready to review from your word list.`;
        warningBtn.textContent = 'Review Now';
        warningBtn.onclick = function() {
            const wordListBtn = document.getElementById('view-word-list-btn');
            if (wordListBtn) {
                const section = document.getElementById('word-list-section');
                if (section && section.style.display !== 'flex') {
                    wordListBtn.click();
                } else if (section && typeof displayWordList === 'function') {
                    displayWordList();
                }
            }
        };
    }

    if (articleInput) {
        articleInput.setAttribute('disabled', 'disabled');
        articleInput.setAttribute('readonly', 'true');
        articleInput.classList.add('disabled-input');
    }
    if (startBtn) {
        startBtn.setAttribute('disabled', 'disabled');
        startBtn.classList.add('disabled-input');
    }
}

function primePracticeWarningFromDueCache(rawCache = null) {
    const applyFromCache = (cacheValue) => {
        let cache = cacheValue;
        if (typeof cache === 'string') {
            try {
                cache = JSON.parse(cache);
            } catch (error) {
                cache = null;
            }
        }

        if (!cache || typeof cache !== 'object') {
            return false;
        }

        const dueMistakes = Array.isArray(cache.dueMistakes) ? cache.dueMistakes : [];
        const dueWordList = Array.isArray(cache.dueWordList) ? cache.dueWordList : [];

        if (dueMistakes.length > 0) {
            applyPracticeWarningState({ kind: 'dueMistakes', count: dueMistakes.length });
            return true;
        }
        if (dueWordList.length > 0) {
            applyPracticeWarningState({ kind: 'dueVocab', count: dueWordList.length });
            return true;
        }
        return false;
    };

    if (applyFromCache(rawCache)) {
        return;
    }

    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        return;
    }

    chrome.storage.local.get(['reviewDueCache']).then((raw) => {
        applyFromCache(raw && raw.reviewDueCache);
    }).catch(() => {});
}

function showPracticeWarning() {
    // Display a warning box when there are carry-over spelling mistakes to rewrite
    // or scheduled reviews that are due. Fresh mistakes should be rewritten once
    // before they enter spaced repetition.
    const warningBox = document.getElementById('practice-warning');
    const textEl = document.getElementById('practice-warning-text');
    const warningBtn = document.getElementById('practice-warning-btn');

    if (!warningBox || !textEl || !warningBtn || typeof SpacedRepetitionManager === 'undefined') {
        return;
    }

    const wordListRaw = getStoredWordList();
    const wordSet = getWordListKeySet(wordListRaw);

    if (typeof SpacedRepetitionManager.pruneWordListEntries === 'function') {
        SpacedRepetitionManager.pruneWordListEntries(wordSet);
    }
    if (typeof SpacedRepetitionManager.cleanupMasteredWordListReviews === 'function') {
        SpacedRepetitionManager.cleanupMasteredWordListReviews();
    }

    const statsManager = window.statisticsManager;
    const pendingCarryoverMistakes = statsManager && typeof statsManager.getPendingInitialMistakes === 'function'
        ? statsManager.getPendingInitialMistakes()
        : [];

    if (statsManager && typeof statsManager.cleanupPendingInitialMistakeSchedules === 'function') {
        statsManager.cleanupPendingInitialMistakeSchedules();
    }

    const blockedPendingWordSet = new Set(
        pendingCarryoverMistakes.map((item) => normalizeWordKey(item && (item.correct || item.incorrect || ''))).filter(Boolean)
    );

    const dueWords = SpacedRepetitionManager.getDueWords();
    const articleInput = document.getElementById('article-input');
    const startBtn = document.getElementById('start-button');
    const dueMistakes = dueWords.filter((item) => item.type === 'mistake' && !blockedPendingWordSet.has(normalizeWordKey(item.word)));
    const dueVocab = dueWords.filter((item) => item.type === 'wordList' && wordSet.has(item.word));

    if (pendingCarryoverMistakes.length > 0) {
        applyPracticeWarningState({ kind: 'pendingMistakes', count: pendingCarryoverMistakes.length });
    } else if (dueMistakes.length > 0) {
        applyPracticeWarningState({ kind: 'dueMistakes', count: dueMistakes.length });
    } else if (dueVocab.length > 0) {
        applyPracticeWarningState({ kind: 'dueVocab', count: dueVocab.length });
    } else {
        applyPracticeWarningState({ kind: 'none', count: 0 });
    }

    if (typeof updateWordListNotification === 'function') {
        updateWordListNotification();
    }
}

/**
 * Update the word list notification icon based on due vocabulary items.
 * When there are words in the spaced repetition schedule of type 'wordList'
 * that are due for review, highlight the Word List button so the user
 * knows there are upcoming vocabulary reviews. Otherwise remove any
 * highlight. This function does not disable the main practice controls.
 */
function updateWordListNotification() {
    const wordListBtn = document.getElementById('view-word-list-btn');

    if (!wordListBtn || typeof SpacedRepetitionManager === 'undefined') {
        return;
    }

    const wordListRaw = getStoredWordList();
    const wordSet = getWordListKeySet(wordListRaw);

    if (typeof SpacedRepetitionManager.pruneWordListEntries === 'function') {
        SpacedRepetitionManager.pruneWordListEntries(wordSet);
    }
    if (typeof SpacedRepetitionManager.cleanupMasteredWordListReviews === 'function') {
        SpacedRepetitionManager.cleanupMasteredWordListReviews();
    }

    const dueVocab = SpacedRepetitionManager.getDueWords()
        .filter((item) => item.type === 'wordList' && wordSet.has(item.word));

    if (dueVocab.length > 0) {
        wordListBtn.classList.add('due-notice');
    } else {
        wordListBtn.classList.remove('due-notice');
    }
}

if (window.__tugadiBootWarningState && window.__tugadiBootWarningState.kind && window.__tugadiBootWarningState.kind !== 'none') {
    applyPracticeWarningState(window.__tugadiBootWarningState);
}

primePracticeWarningFromDueCache();

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== 'local') return;
        if (changes.reviewDueCache) {
            const nextValue = changes.reviewDueCache && Object.prototype.hasOwnProperty.call(changes.reviewDueCache, 'newValue')
                ? changes.reviewDueCache.newValue
                : null;
            primePracticeWarningFromDueCache(nextValue);
        }
    });
}

wordListApp.modules.wordList = {
    displayWordList,
    openWordPracticeModal,
    handlePracticeModalStep,
    closeWordPracticeModal,
    showPracticeWarning,
    updateWordListNotification
};
