const uiApp = window.WritingImitationPractice || (window.WritingImitationPractice = {});
uiApp.state = uiApp.state || {};
uiApp.services = uiApp.services || {};
uiApp.modules = uiApp.modules || {};
uiApp.utils = uiApp.utils || {};
uiApp.storage = uiApp.storage || {};
uiApp.dom = uiApp.dom || {};


/*
 * UI systems, notifications, modal controls, and application bootstrap.
 */


/**
 * showConfirmation
 *
 * Custom, in-app confirmation modal (avoids the browser's native confirm
 * dialog which can look inconsistent/ugly across OSes).
 *
 * @param {string} message
 * @param {(confirmed: boolean) => void} callback
 * @param {{title?: string, confirmText?: string, cancelText?: string}} [options]
 */
function showConfirmation(message, callback, options = {}) {
    const title = options.title || 'Confirm';
    const confirmText = options.confirmText || 'Confirm';
    const cancelText = options.cancelText || 'Cancel';

    // Remove any existing confirmation overlay
    const existing = document.getElementById('confirmation-overlay');
    if (existing) {
        existing.remove();
    }

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.id = 'confirmation-overlay';

    // Build dialog
    const dialog = document.createElement('div');
    dialog.className = 'confirm-dialog';
    dialog.setAttribute('role', 'dialog');
    dialog.setAttribute('aria-modal', 'true');
    dialog.setAttribute('aria-label', title);

    const header = document.createElement('div');
    header.className = 'confirm-header';
    const icon = document.createElement('div');
    icon.className = 'confirm-icon';
    icon.innerHTML = '<i class="fi fi-rr-exclamation"></i>';
    const h = document.createElement('h3');
    h.className = 'confirm-title';
    h.textContent = title;
    header.appendChild(icon);
    header.appendChild(h);

    const msg = document.createElement('p');
    msg.className = 'confirm-message';
    msg.textContent = message;

    const actions = document.createElement('div');
    actions.className = 'confirm-actions';

    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'storage-btn cancel';
    cancelBtn.type = 'button';
    cancelBtn.textContent = cancelText;

    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'storage-btn confirm';
    confirmBtn.type = 'button';
    confirmBtn.textContent = confirmText;

    actions.appendChild(cancelBtn);
    actions.appendChild(confirmBtn);

    dialog.appendChild(header);
    dialog.appendChild(msg);
    dialog.appendChild(actions);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    // Focus the confirm button by default
    setTimeout(() => {
        try {
            confirmBtn.focus();
        } catch (e) {
            /* ignore */
        }
    }, 0);

    const cleanup = () => {
        document.removeEventListener('keydown', onKeyDown);
        overlay.remove();
    };

    const finish = (value) => {
        cleanup();
        if (typeof callback === 'function') {
            callback(Boolean(value));
        }
    };

    const onKeyDown = (e) => {
        if (e.key === 'Escape') {
            e.preventDefault();
            finish(false);
        }
    };

    // Click handling:
    //  - Clicking the dimmed backdrop cancels
    //  - Clicks inside the confirmation should NOT bubble to document handlers
    //    (e.g. the stats dashboard auto-close listener).
    overlay.addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.target === overlay) {
            finish(false);
        }
    });
    dialog.addEventListener('click', (e) => e.stopPropagation());
    cancelBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        finish(false);
    });
    confirmBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        finish(true);
    });

    document.addEventListener('keydown', onKeyDown);
}

/**
 * showTransientMessage
 *
 * Lightweight in-app toast used for non-destructive warnings and status
 * messages. Unlike alerts, this keeps the extension responsive and matches
 * the rest of the UI.
 *
 * @param {string} message
 * @param {{duration?: number}} [options]
 */
function showTransientMessage(message, options = {}) {
    if (!message) return;
    const duration = Number(options.duration) > 0 ? Number(options.duration) : 2400;

    const existing = document.getElementById('app-toast');
    if (existing) {
        existing.remove();
    }

    const toast = document.createElement('div');
    toast.id = 'app-toast';
    toast.className = 'app-toast';
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    toast.textContent = message;

    document.body.appendChild(toast);

    requestAnimationFrame(() => {
        toast.classList.add('visible');
    });

    window.setTimeout(() => {
        toast.classList.remove('visible');
        window.setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 180);
    }, duration);
}






const SourceValidationUI = {
    debounceTimer: null,
    latestRunToken: 0,

    getValidator() {
        return window.SourceTextValidator || (window.WritingImitationPractice && window.WritingImitationPractice.services && window.WritingImitationPractice.services.sourceTextValidator) || null;
    },

    getElements() {
        return {
            panel: document.getElementById('source-validation-panel'),
            summary: document.getElementById('source-validation-summary'),
            badge: document.getElementById('source-validation-badge'),
            list: document.getElementById('source-validation-list'),
            note: document.getElementById('source-validation-note'),
            approve: document.getElementById('source-validation-approve'),
            recheck: document.getElementById('source-validation-recheck'),
            start: document.getElementById('start-button'),
            input: document.getElementById('article-input')
        };
    },

    updateStartButton() {
        const validator = this.getValidator();
        const { start, input } = this.getElements();
        if (!start || !validator || !input) return;

        const state = validator.getState();
        const hasText = Boolean(sanitizeArticleText(input.value));
        start.disabled = !hasText || state.status === 'checking' || (state.status === 'issues' && !state.approved);
        start.title = state.status === 'checking'
            ? 'Wait until the local offline LanguageTool check finishes.'
            : state.status === 'issues' && !state.approved
                ? 'Review the source-text issues first, or choose “Use text anyway”.'
                : '';
    },

    render(state) {
        const { panel, summary, badge, list, note, approve } = this.getElements();
        if (!panel || !summary || !badge || !list || !note || !approve) {
            return;
        }

        const safeState = state || { status: 'idle', issues: [], approved: false, note: '' };
        const issueCount = Array.isArray(safeState.issues) ? safeState.issues.length : 0;
        panel.style.display = safeState.status === 'idle' ? 'none' : 'block';
        panel.dataset.state = safeState.status || 'idle';
        badge.textContent = safeState.status === 'checking'
            ? 'Checking…'
            : safeState.status === 'clean'
                ? 'Looks good'
                : safeState.status === 'issues'
                    ? `${issueCount} issue${issueCount === 1 ? '' : 's'}`
                    : 'Idle';

        if (safeState.status === 'checking') {
            summary.textContent = 'Checking with your local offline LanguageTool server…';
        } else if (safeState.status === 'clean') {
            summary.textContent = 'No likely issues were found by your local offline LanguageTool setup.';
        } else if (safeState.status === 'issues') {
            summary.textContent = `${issueCount} possible issue${issueCount === 1 ? '' : 's'} found. The original text was not changed.`;
        } else {
            summary.textContent = 'Paste text to check it with your local offline LanguageTool server.';
        }

        list.innerHTML = '';
        if (issueCount) {
            safeState.issues.slice(0, 6).forEach((issue) => {
                const item = document.createElement('li');
                item.className = `source-validation-item severity-${issue.severity || 'warning'}`;
                const suggestions = Array.isArray(issue.suggestions) && issue.suggestions.length
                    ? `<div class="source-validation-suggestions">Try: ${issue.suggestions.map((entry) => escapeHTML(entry)).join(', ')}</div>`
                    : '';
                item.innerHTML = `
                    <div class="source-validation-item-top">
                        <span class="source-validation-kind">${escapeHTML(issue.category || 'Issue')}</span>
                        <span class="source-validation-severity">${escapeHTML(issue.severity || 'warning')}</span>
                    </div>
                    <div class="source-validation-message">${escapeHTML(issue.message || 'Possible issue found.')}</div>
                    ${issue.context ? `<div class="source-validation-context">${escapeHTML(issue.context)}</div>` : ''}
                    ${suggestions}
                `;
                list.appendChild(item);
            });
        }

        note.textContent = safeState.note || '';
        approve.style.display = safeState.status === 'issues' && !safeState.approved ? 'inline-flex' : 'none';
        if (safeState.status === 'issues' && safeState.approved) {
            note.textContent = safeState.note || 'You approved this text as-is. The original text stays unchanged.';
        }
        this.updateStartButton();
    },

    async runValidationNow(text, options = {}) {
        const validator = this.getValidator();
        if (!validator) return null;
        const cleaned = sanitizeArticleText(text);
        if (!cleaned) {
            const resetState = validator.reset();
            this.render(resetState);
            return resetState;
        }

        const runToken = ++this.latestRunToken;
        this.render({ status: 'checking', issues: [], approved: false, note: 'Checking with your local offline LanguageTool server…' });
        const state = await validator.validate(cleaned);
        if (runToken !== this.latestRunToken) {
            return state;
        }
        this.render(state);
        if (options.toastOnIssues && state.status === 'issues' && !state.approved) {
            showTransientMessage('Review the possible source-text issues before starting practice.', { duration: 3200 });
        }
        return state;
    },

    scheduleValidation(text, options = {}) {
        window.clearTimeout(this.debounceTimer);
        const delay = Number(options.delay) >= 0 ? Number(options.delay) : 600;
        this.debounceTimer = window.setTimeout(() => {
            this.runValidationNow(text, options);
        }, delay);
    },

    bind() {
        const { input, approve, recheck } = this.getElements();
        const validator = this.getValidator();
        if (!input || !validator) {
            return;
        }

        this.render(validator.getState());

        input.addEventListener('input', () => {
            this.scheduleValidation(input.value, { delay: 700 });
        });

        input.addEventListener('blur', () => {
            if (sanitizeArticleText(input.value)) {
                this.runValidationNow(input.value);
            }
        });

        if (approve) {
            approve.addEventListener('click', () => {
                const state = validator.approveCurrentText();
                this.render(state);
                showTransientMessage('Using the original text exactly as pasted.', { duration: 2400 });
            });
        }

        if (recheck) {
            recheck.addEventListener('click', () => {
                this.runValidationNow(input.value, { toastOnIssues: true });
            });
        }
    }
};

window.SourceValidationUI = SourceValidationUI;

const GifFeedbackSystem = {
    registry: {
        'no-copy-paste': {
            src: 'gifs/no-copy-paste.gif',
            alt: 'Humorous reaction GIF for blocked paste attempts.',
            duration: 3500
        }
    },
    state: {
        hideTimer: null
    },
    registerGif(id, config) {
        if (!id || !config || !config.src) {
            return;
        }
        this.registry[id] = {
            ...this.registry[id],
            ...config
        };
    },
    normalizeText(text) {
        return String(text || '')
            .replace(/\s+/g, ' ')
            .trim();
    },
    isNodeWithin(node, element) {
        if (!node || !element) {
            return false;
        }
        const normalizedNode = node.nodeType === Node.TEXT_NODE ? node.parentNode : node;
        return !!(normalizedNode && element.contains(normalizedNode));
    },
    selectionTouchesElement(element) {
        if (!element || typeof window.getSelection !== 'function') {
            return false;
        }

        const selection = window.getSelection();
        if (!selection || selection.rangeCount === 0) {
            return false;
        }

        if (this.isNodeWithin(selection.anchorNode, element) || this.isNodeWithin(selection.focusNode, element)) {
            return true;
        }

        for (let index = 0; index < selection.rangeCount; index += 1) {
            const range = selection.getRangeAt(index);
            if (this.isNodeWithin(range.commonAncestorContainer, element)) {
                return true;
            }
        }

        return false;
    },
    ensureModal() {
        let modal = document.getElementById('clipboard-gif-modal');
        if (modal) {
            return modal;
        }

        modal = document.createElement('div');
        modal.id = 'clipboard-gif-modal';
        modal.className = 'clipboard-gif-modal';
        modal.setAttribute('aria-hidden', 'true');
        modal.innerHTML = `
            <div class="clipboard-gif-card" role="dialog" aria-modal="true" aria-labelledby="clipboard-gif-title">
                <img class="clipboard-gif-image" alt="">
                <div class="clipboard-gif-copy">
                    <h3 id="clipboard-gif-title" class="clipboard-gif-title"></h3>
                    <p class="clipboard-gif-message"></p>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        return modal;
    },
    show(id, options = {}) {
        const config = this.registry[id];
        if (!config) {
            return;
        }

        const modal = this.ensureModal();
        const image = modal.querySelector('.clipboard-gif-image');
        const title = modal.querySelector('.clipboard-gif-title');
        const message = modal.querySelector('.clipboard-gif-message');
        const copyWrap = modal.querySelector('.clipboard-gif-copy');

        image.src = '';
        image.src = config.src;
        image.alt = options.alt || config.alt || 'Feedback GIF';

        const titleText = typeof options.title === 'string' ? options.title : '';
        const messageText = typeof options.message === 'string' ? options.message : '';
        title.textContent = titleText;
        message.textContent = messageText;
        copyWrap.style.display = titleText || messageText ? 'block' : 'none';

        modal.classList.add('visible');
        modal.setAttribute('aria-hidden', 'false');

        if (this.state.hideTimer) {
            window.clearTimeout(this.state.hideTimer);
        }
        const duration = Number(options.duration) > 0
            ? Number(options.duration)
            : (Number(config.duration) > 0 ? Number(config.duration) : 3500);
        this.state.hideTimer = window.setTimeout(() => {
            this.hide();
        }, duration);
    },
    hide() {
        const modal = document.getElementById('clipboard-gif-modal');
        if (!modal) {
            return;
        }

        if (this.state.hideTimer) {
            window.clearTimeout(this.state.hideTimer);
            this.state.hideTimer = null;
        }

        modal.classList.remove('visible');
        modal.setAttribute('aria-hidden', 'true');
    }
};

function setShortcutPanelCollapsed(collapsed) {
    const grid = document.getElementById('shortcut-grid');
    const toggleBtn = document.getElementById('shortcut-toggle-btn');
    const shortcutSection = document.getElementById('keyboard-shortcuts');
    const revealBtn = document.getElementById('shortcut-reveal-btn');
    if (!grid || !toggleBtn || !shortcutSection) {
        return;
    }

    const isCollapsed = Boolean(collapsed);
    shortcutSection.classList.toggle('collapsed', isCollapsed);
    shortcutSection.setAttribute('aria-hidden', isCollapsed ? 'true' : 'false');
    grid.classList.toggle('is-collapsed', isCollapsed);
    toggleBtn.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
    toggleBtn.setAttribute('aria-label', isCollapsed ? 'Show shortcuts' : 'Hide shortcuts');
    toggleBtn.title = isCollapsed ? 'Show shortcuts (Ctrl+/)' : 'Hide shortcuts (Ctrl+/)';

    if (revealBtn) {
        revealBtn.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
        revealBtn.title = isCollapsed ? 'Show shortcuts (Ctrl+/)' : 'Hide shortcuts (Ctrl+/)';
    }
}

function toggleShortcutPanel(forceState) {
    const shortcutSection = document.getElementById('keyboard-shortcuts');
    if (!shortcutSection) {
        return;
    }

    const nextState = typeof forceState === 'boolean'
        ? forceState
        : !shortcutSection.classList.contains('collapsed');

    setShortcutPanelCollapsed(nextState);
}

function getLaunchContextFromURL() {
    try {
        const params = new URLSearchParams(window.location.search || '');
        const reviewKind = String(params.get('reviewKind') || '').trim();
        const reviewCount = Number(params.get('reviewCount') || 0);
        const openReview = params.get('openReview') === '1';

        if (!openReview || !reviewKind || !Number.isFinite(reviewCount) || reviewCount <= 0) {
            return null;
        }

        return {
            reviewKind,
            reviewCount
        };
    } catch (error) {
        return null;
    }
}

function clearLaunchContextFromURL() {
    try {
        const url = new URL(window.location.href);
        ['reviewKind', 'reviewCount', 'openReview'].forEach((key) => url.searchParams.delete(key));
        const nextURL = `${url.pathname}${url.search}${url.hash}`;
        window.history.replaceState({}, document.title, nextURL);
    } catch (error) {
        // Ignore history update failures.
    }
}

function handleLaunchReviewContext() {
    const context = getLaunchContextFromURL();
    if (!context) {
        return;
    }

    const { reviewKind } = context;

    if (reviewKind === 'dueVocab') {
        const section = document.getElementById('word-list-section');
        const isOpen = section && section.style.display === 'flex';
        if (!isOpen && typeof toggleWordListVisibility === 'function') {
            toggleWordListVisibility();
        } else if (typeof displayWordList === 'function') {
            displayWordList();
        }
    } else if (typeof openMistakesPanel === 'function') {
        openMistakesPanel({
            focusSection: 'mistakes',
            highlightReview: reviewKind === 'dueMistakes'
        });
    }

    clearLaunchContextFromURL();
}

function bindShortcutPanel() {
    const toggleBtn = document.getElementById('shortcut-toggle-btn');
    const revealBtn = document.getElementById('shortcut-reveal-btn');
    if (!toggleBtn || toggleBtn.dataset.bound === '1') {
        return;
    }

    toggleBtn.addEventListener('click', () => toggleShortcutPanel());
    if (revealBtn) {
        revealBtn.addEventListener('click', () => toggleShortcutPanel(false));
    }
    toggleBtn.dataset.bound = '1';
    setShortcutPanelCollapsed(true);
}

function toggleStatisticsDashboardVisibility() {
    const dashboard = document.getElementById('statistics-dashboard');
    const statsBtn = document.getElementById('stats-dashboard-btn');
    if (!dashboard || !statsBtn) {
        return;
    }

    dashboard.classList.toggle('open');
    statsBtn.classList.toggle('active');
    if (dashboard.classList.contains('open') && typeof statisticsManager !== 'undefined' && statisticsManager && typeof statisticsManager.updateUI === 'function') {
        statisticsManager.updateUI();
    }
}

function closeStatisticsDashboardVisibility() {
    const dashboard = document.getElementById('statistics-dashboard');
    const statsBtn = document.getElementById('stats-dashboard-btn');
    if (!dashboard || !statsBtn || !dashboard.classList.contains('open')) {
        return false;
    }

    dashboard.classList.remove('open');
    statsBtn.classList.remove('active');
    return true;
}

function toggleWordListVisibility() {
    const wordListSection = document.getElementById('word-list-section');
    if (!wordListSection) {
        return;
    }

    const shouldOpen = wordListSection.style.display === 'none' || !wordListSection.style.display;
    wordListSection.style.display = shouldOpen ? 'flex' : 'none';
    if (shouldOpen && typeof displayWordList === 'function') {
        displayWordList();
    }
}

function closeOpenPanels() {
    let closedAny = false;

    if (typeof closeStatisticsDashboardVisibility === 'function' && closeStatisticsDashboardVisibility()) {
        closedAny = true;
    }

    const wordListSection = document.getElementById('word-list-section');
    if (wordListSection && wordListSection.style.display !== 'none' && wordListSection.style.display !== '') {
        wordListSection.style.display = 'none';
        closedAny = true;
    }

    const textControlsModal = document.getElementById('text-controls-modal');
    if (textControlsModal && textControlsModal.style.display === 'flex') {
        ModalSystem.closeTextControlsModal();
        closedAny = true;
    }

    const wordPracticeModal = document.getElementById('word-practice-modal');
    if (wordPracticeModal && wordPracticeModal.style.display !== 'none' && typeof closeWordPracticeModal === 'function') {
        closeWordPracticeModal();
        closedAny = true;
    }

    const clipboardGifModal = document.getElementById('clipboard-gif-modal');
    if (clipboardGifModal && clipboardGifModal.classList.contains('visible')) {
        GifFeedbackSystem.hide();
        closedAny = true;
    }

    return closedAny;
}

function handleGlobalShortcut(event) {
    if (event.ctrlKey && (event.key === '/' || event.key === '?')) {
        event.preventDefault();
        toggleShortcutPanel();
        return;
    }

    if (event.key === 'Escape') {
        if (closeOpenPanels()) {
            event.preventDefault();
        }
        return;
    }

    if (!event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) {
        return;
    }

    const lowerKey = String(event.key || '').toLowerCase();
    if (lowerKey === 's') {
        event.preventDefault();
        toggleStatisticsDashboardVisibility();
    } else if (lowerKey === 'w') {
        event.preventDefault();
        toggleWordListVisibility();
    } else if (lowerKey === 't') {
        event.preventDefault();
        const themeToggleBtn = document.getElementById('theme-toggle-btn');
        if (themeToggleBtn) {
            themeToggleBtn.click();
        }
    } else if (lowerKey === 'r') {
        event.preventDefault();
        const reloadBtn = document.getElementById('reload-button');
        if (reloadBtn && reloadBtn.offsetParent !== null) {
            reloadBtn.click();
        }
    }
}

/**
 * Apply the saved theme preference and keep the toggle icon in sync.
 */
function applySavedThemePreference() {
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    const themeIcon = themeToggleBtn ? themeToggleBtn.querySelector('i') : null;
    const savedTheme = ExtensionStorage.getItem('theme');

    if (savedTheme === 'true') {
        document.body.classList.add('low-light-mode');
        if (themeIcon) {
            themeIcon.className = 'fi fi-rr-sun';
        }
        ColorManager.updateOriginalSentenceColor(true);
        ColorManager.updateErrorMessageColors();
    } else if (themeIcon) {
        themeIcon.className = 'fi fi-rr-moon';
    }
}

/**
 * Bind the practice modal close control once.
 */
function bindPracticeModalCloseButton() {
    const practiceModalCloseBtn = document.getElementById('practice-modal-close-btn');
    if (practiceModalCloseBtn) {
        practiceModalCloseBtn.addEventListener('click', closeWordPracticeModal);
    }
}

// 1. Core Management Systems
const ColorManager = {
    getTextColor(isLowLight) {
        return isLowLight ? "#E0E0E0" : "#333";
    },
    getHiddenColor(isLowLight) {
        return isLowLight ? "#2D2D2D" : "#f0f0f0";
    },
    updateOriginalSentenceColor(isVisible = true) {
        const originalSentenceElement = document.getElementById("original-sentence");
        const isLowLight = document.body.classList.contains('low-light-mode');
        originalSentenceElement.style.color = isVisible ?
            this.getTextColor(isLowLight) :
            this.getHiddenColor(isLowLight);
    },
    updateErrorMessageColors() {
        const result = document.getElementById("result");
        if (result.innerHTML.includes("Incorrect:")) {
            const incorrectWord = result.querySelector("span:nth-of-type(2)").textContent;
            const correctWord = result.querySelector("span:nth-of-type(4)").textContent;
            const isLowLight = document.body.classList.contains('low-light-mode');
            const textColor = this.getTextColor(isLowLight);
            result.innerHTML = `<span style="color: red;">Incorrect:</span> <span style="color: ${textColor};">${escapeHTML(incorrectWord)}</span> | <span style="color: green;">Correct:</span> <span style="color: ${textColor};">${escapeHTML(correctWord)}</span>`;
        }
    }
};

// 2. Result Management System
const ResultManager = {
    _setResultHTML(html, color = "") {
        const result = document.getElementById("result");
        if (!result) {
            return;
        }
        result.innerHTML = html || "";
        result.style.color = color || "";
    },
    clearResult() {
        const result = document.getElementById("result");
        // Only clear if it's not a mistake count message
        if (result && !result.innerHTML.includes("You made")) {
            ResultManager._setResultHTML("");
        }
    },
    showErrorMessage(incorrectWord, correctWord) {
        const result = document.getElementById("result");
        const textColor = ColorManager.getTextColor(document.body.classList.contains('low-light-mode'));

        // Preserve existing mistake count if it exists
        const existingMistakeCount = result && result.innerHTML.match(/You made \d+ mistakes/);
        const mistakeMessage = existingMistakeCount
            ? `<span class="result-message" style="color: ${document.body.classList.contains('low-light-mode') ? '#FF6B6B' : 'red'};">${existingMistakeCount[0]}. Please rewrite it again.</span>`
            : '';

        ResultManager._setResultHTML(
            `<span class="result-line"><span style="color: red;">Incorrect:</span> <span style="color: ${textColor};">${escapeHTML(incorrectWord)}</span> | <span style="color: green;">Correct:</span> <span style="color: ${textColor};">${escapeHTML(correctWord)}</span></span>${mistakeMessage}`
        );
    },
    showMistakeCount(count) {
        const result = document.getElementById("result");
        const errorColor = document.body.classList.contains('low-light-mode') ? '#FF6B6B' : 'red';

        // Preserve any existing error message
        const existingMessage = result && result.innerHTML.includes("Incorrect:")
            ? result.innerHTML.replace(/<span class="result-message"[^>]*>.*?<\/span>/, '')
            : '';
        const mistakeMessage = `<span class="result-message" style="color: ${errorColor};">You made ${count} mistakes. Please rewrite it again.</span>`;

        ResultManager._setResultHTML(existingMessage + mistakeMessage);
    },
    showSuccess() {
        ResultManager._setResultHTML("Correct", "green");
    },
    showSpacingError() {
        ResultManager._setResultHTML("Check your spacing after punctuation.", "orange");
    },
    showEmptyInput() {
        ResultManager._setResultHTML("Write the sentence first.", "orange");
    },
    showPunctuationReminder(reminder) {
        const message = reminder && reminder.message ? reminder.message : "Incorrect punctuation. Rewrite it again.";
        ResultManager._setResultHTML(message, "orange");
    },
    showProgress() {
        ResultManager._setResultHTML("Keep going, you're getting closer!", "green");
    }
};

function handleUserInputTyping() {
    const inputEl = document.getElementById("user-input");
    const result = document.getElementById("result");

    if (!inputEl || !result) {
        return;
    }

    const resultText = result.innerHTML;

    if (resultText.includes("You made") && !resultText.includes("Incorrect:")) {
        result.textContent = "";
    }

    if (inputEl.value.includes('  ')) {
        inputEl.value = inputEl.value.replace(/\s+/g, ' ');
    }

    hideOriginalSentence();
    ResultManager.clearResult();
    if (window.WritingImitationPractice && window.WritingImitationPractice.state && window.WritingImitationPractice.state.practice) {
        window.WritingImitationPractice.state.practice.lastSubmissionSignature = null;
        window.WritingImitationPractice.state.practice.lastSubmissionAt = 0;
    }
    saveProgress();
}

// 3. Text Control System
const TextControlSystem = {
    defaults: {
        fontSize: 18,
        fontFamily: 'Arial, sans-serif'
    },
    settings: {},
    init() {
        this.loadSavedSettings();
        this.setupEventListeners();
    },
    loadSavedSettings() {
        const saved = getStoredJSON('textControls', null);
        this.settings = saved ? { ...this.defaults, ...saved } : { ...this.defaults };
        this.applySettings();
    },
    setupEventListeners() {
        document.querySelectorAll('.size-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.updateFontSize(parseInt(btn.dataset.size));
            });
        });
        document.getElementById('font-family-select').addEventListener('change', (e) => {
            this.updateFontFamily(e.target.value);
        });
    },
    updateFontSize(size) {
        this.settings.fontSize = size;
        this.applySettings();
        this.updateUI();
        this.saveSettings();
    },
    updateFontFamily(family) {
        this.settings.fontFamily = family;
        this.applySettings();
        this.saveSettings();
    },
    applySettings() {
        const elements = ['original-sentence', 'user-input'].map(id =>
            document.getElementById(id));
        elements.forEach(el => {
            if (el) {
                el.style.fontSize = `${this.settings.fontSize}px`;
                el.style.fontFamily = this.settings.fontFamily;
            }
        });
    },
    updateUI() {
        document.querySelectorAll('.size-btn').forEach(btn => {
            btn.classList.toggle('active',
                parseInt(btn.dataset.size) === this.settings.fontSize);
        });
        document.getElementById('font-family-select').value = this.settings.fontFamily;
    },
    resetDefaults() {
        this.settings = { ...this.defaults };
        this.applySettings();
        this.updateUI();
        this.saveSettings();
    },
    saveSettings() {
        ExtensionStorage.setItem('textControls', JSON.stringify(this.settings));
    }
};

// 4. Practice State Management

// Attach global event listeners that replace inline HTML handlers.
function attachGlobalEventListeners() {
    // Prevent copy/paste/cut in rewrite inputs (Word List practice + Spelling Mistakes).
    // This keeps the rewrite steps honest (typed recall only) while still allowing
    // normal copy/paste everywhere else (like the article input).
    const blockClipboardForRewrite = (event) => {
        const target = event.target;
        if (target && target.classList && target.classList.contains('rewrite-input')) {
            event.preventDefault();
            event.stopPropagation();
            if (typeof event.stopImmediatePropagation === 'function') {
                event.stopImmediatePropagation();
            }
        }
    };

    const isPracticeInputTarget = (event) => {
        const userInput = document.getElementById('user-input');
        if (!userInput) {
            return false;
        }

        const target = event.target;
        return target === userInput || (target instanceof Node && userInput.contains(target));
    };

    const showBlockedPasteGif = () => {
        GifFeedbackSystem.show('no-copy-paste');
    };

    const blockPracticePasteAttempt = (event) => {
        if (!isPracticeInputTarget(event)) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === 'function') {
            event.stopImmediatePropagation();
        }

        showBlockedPasteGif();
    };

    const blockPracticePasteShortcut = (event) => {
        if (!isPracticeInputTarget(event)) {
            return;
        }

        const key = String(event.key || '').toLowerCase();
        const isPasteShortcut = (event.ctrlKey || event.metaKey) && key === 'v';
        const isInsertShortcut = event.shiftKey && key === 'insert';
        if (!isPasteShortcut && !isInsertShortcut) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === 'function') {
            event.stopImmediatePropagation();
        }

        showBlockedPasteGif();
    };

    const blockPracticeBeforeInputPaste = (event) => {
        if (!isPracticeInputTarget(event) || event.inputType !== 'insertFromPaste') {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === 'function') {
            event.stopImmediatePropagation();
        }

        showBlockedPasteGif();
    };

    document.addEventListener('paste', blockClipboardForRewrite, true);
    document.addEventListener('copy', blockClipboardForRewrite, true);
    document.addEventListener('cut', blockClipboardForRewrite, true);
    document.addEventListener('paste', blockPracticePasteAttempt, true);
    document.addEventListener('keydown', blockPracticePasteShortcut, true);
    document.addEventListener('beforeinput', blockPracticeBeforeInputPaste, true);

    const startBtn = document.getElementById('start-button');
    if (startBtn) {
        startBtn.addEventListener('click', processArticle);
    }

    bindShortcutPanel();

    if (document.body && document.body.dataset.globalShortcutsBound !== '1') {
        document.addEventListener('keydown', handleGlobalShortcut);
        document.body.dataset.globalShortcutsBound = '1';
    }

    const articleInput = document.getElementById('article-input');
    if (articleInput) {
        articleInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                processArticle();
            }
        });

        articleInput.addEventListener('paste', function(event) {
            event.preventDefault();
            const pastedText = (event.clipboardData || window.clipboardData).getData('text');
            this.value = sanitizeArticleText(pastedText);
        });
    }

    const userInput = document.getElementById('user-input');
    if (userInput) {
        userInput.addEventListener('keydown', handleKeyDown);
        userInput.addEventListener('input', handleUserInputTyping);
    }

    const checkBtn = document.getElementById('check-button');
    if (checkBtn) {
        checkBtn.addEventListener('click', checkText);
    }

    const reloadBtn = document.getElementById('reload-button');
    if (reloadBtn) {
        reloadBtn.addEventListener('click', restartPractice);
    }

    const originalSentence = document.getElementById('original-sentence');
    if (originalSentence) {
        originalSentence.addEventListener('dragstart', function(event) {
            event.preventDefault();
        });
    }

    const resetDefaultsBtn = document.getElementById('reset-defaults-btn');
    if (resetDefaultsBtn) {
        resetDefaultsBtn.addEventListener('click', () => {
            TextControlSystem.resetDefaults();
        });
    }

    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', function() {
            document.body.classList.toggle('low-light-mode');
            const icon = this.querySelector('i');
            if (icon) {
                icon.className = document.body.classList.contains('low-light-mode')
                    ? 'fi fi-rr-sun'
                    : 'fi fi-rr-moon';
            }
            ExtensionStorage.setItem('theme', document.body.classList.contains('low-light-mode'));

            const currentUserInput = document.getElementById('user-input').value;
            if (!currentUserInput || document.getElementById('original-sentence').style.color !== ColorManager.getHiddenColor(document.body.classList.contains('low-light-mode'))) {
                ColorManager.updateOriginalSentenceColor(true);
            }
            ColorManager.updateErrorMessageColors();
        });
    }

    const textControlsBtn = document.getElementById('text-controls-btn');
    if (textControlsBtn) {
        textControlsBtn.addEventListener('click', function(event) {
            event.stopPropagation();
            ModalSystem.toggleTextControlsModal(this);
        });
    }

    const viewWordListBtn = document.getElementById('view-word-list-btn');
    if (viewWordListBtn) {
        viewWordListBtn.addEventListener('click', function() {
            toggleWordListVisibility();
        });
    }

    const closeWordListBtn = document.getElementById('close-word-list-btn');
    if (closeWordListBtn) {
        closeWordListBtn.addEventListener('click', function() {
            document.getElementById('word-list-section').style.display = 'none';
        });
    }

    const clearWordListBtn = document.getElementById('clear-word-list-btn');
    if (clearWordListBtn) {
        clearWordListBtn.addEventListener('click', function() {
            showConfirmation('Are you sure you want to clear the word list?', function(confirmed) {
                if (!confirmed) return;
                try {
                    ExtensionStorage.setItem('wordList', JSON.stringify([]));

                    if (typeof SpacedRepetitionManager !== 'undefined' &&
                        typeof SpacedRepetitionManager.pruneWordListEntries === 'function') {
                        SpacedRepetitionManager.pruneWordListEntries(new Set());
                    }
                } catch (e) {
                    /* ignore */
                }

                displayWordList();
                showPracticeWarning();
            });
        });
    }

    document.addEventListener('click', function(event) {
        const textControlsModal = document.getElementById('text-controls-modal');
        const textControlsTrigger = document.getElementById('text-controls-btn');
        if (
            textControlsModal &&
            textControlsModal.style.display === 'flex' &&
            !textControlsModal.contains(event.target) &&
            textControlsTrigger &&
            !textControlsTrigger.contains(event.target)
        ) {
            ModalSystem.closeTextControlsModal();
        }
    });
}

// 22. Context Menu System
const ContextMenu = {
    menu: document.getElementById('context-menu'),
    selectedWord: '',
    
    init() {
        this.setupEventListeners();
        this.setupDefinitionButton();
        this.setupAddToListButton();
    },
    
    show(x, y) {
        this.menu.style.display = 'block';
        
        // Ensure menu stays within viewport
        const menuRect = this.menu.getBoundingClientRect();
        const maxX = window.innerWidth - menuRect.width;
        const maxY = window.innerHeight - menuRect.height;
        
        this.menu.style.left = `${Math.min(x, maxX)}px`;
        this.menu.style.top = `${Math.min(y, maxY)}px`;
        
        // Reset add to list button
        const addToListBtn = document.getElementById('add-to-list-btn');
        addToListBtn.classList.remove('success');
        addToListBtn.innerHTML = '<i class="fi fi-rr-book-alt"></i>Add to Word List';
    },
    
    hide() {
        this.menu.style.display = 'none';
    },
    
    setupEventListeners() {
        document.addEventListener('mouseup', (event) => {
            const selection = window.getSelection().toString().trim();
            if (selection) {
                this.selectedWord = selection;
                if (event.button === 2) {
                    event.preventDefault();
                    this.show(event.pageX, event.pageY);
                }
            } else {
                this.hide();
            }
        });
        document.addEventListener('click', (event) => {
            if (!this.menu.contains(event.target)) {
                this.hide();
            }
        });
    },
    
    setupDefinitionButton() {
        document.getElementById('definition-btn').addEventListener('click', () => {
            if (this.selectedWord) {
                const searchQuery = `https://duckduckgo.com/?q=definition+of+${encodeURIComponent(this.selectedWord)}&kad=en_US`;
                window.open(searchQuery, '_blank');
                this.hide();
            }
        });
    },
    
    setupAddToListButton() {
        // Handle adding a selected word to the user's personal word list.
        // When a new word is saved, record it in the spaced repetition
        // schedule under the 'wordList' type but do *not* inject it into the
        // spelling mistakes queue. Instead, vocabulary practice occurs
        // directly within the Word List section. This avoids confusing
        // unfamiliar vocabulary with actual spelling errors and ensures
        // users practise unknown words separately.
        document.getElementById('add-to-list-btn').addEventListener('click', () => {
            const currentWordList = getStoredJSON('wordList', []);
            const selectedRaw = String(this.selectedWord || '').replace(/\s+/g, ' ').trim();
            const selectedKey = normalizeWordKey(selectedRaw);

            if (!selectedKey) {
                this.hide();
                return;
            }

            const alreadyExists = currentWordList.some((word) => normalizeWordKey(word) === selectedKey);

            if (!alreadyExists) {
                currentWordList.push(selectedRaw);
                ExtensionStorage.setItem('wordList', JSON.stringify(currentWordList));

                if (typeof SpacedRepetitionManager !== 'undefined') {
                    SpacedRepetitionManager.recordWord(selectedKey, 'wordList');
                }

                displayWordList();

                const addToListBtn = document.getElementById('add-to-list-btn');
                addToListBtn.classList.add('success');
                addToListBtn.textContent = 'Added to Word List';
                setTimeout(() => this.hide(), 1500);
            } else {
                showTransientMessage(`"${selectedRaw}" is already in your word list.`);
                this.hide();
            }
        });
    }
};

// 23. Modal Management
const ModalSystem = {
    init() {
        this.setupTextControlsModal();
    },
    openTextControlsModal(anchor) {
        const modal = document.getElementById('text-controls-modal');
        if (!modal) {
            return;
        }

        const modalContent = modal.querySelector('.modal-content');
        const trigger = anchor || document.getElementById('text-controls-btn');

        modal.style.display = 'flex';

        if (trigger && modalContent) {
            const buttonRect = trigger.getBoundingClientRect();
            modalContent.style.top = (buttonRect.bottom + 10) + 'px';
        }

        const currentSize = TextControlSystem.settings.fontSize || TextControlSystem.defaults.fontSize;
        document.querySelectorAll('.size-btn').forEach((btn) => {
            btn.classList.toggle('active', parseInt(btn.dataset.size, 10) === currentSize);
        });

        const fontSelect = document.getElementById('font-family-select');
        if (fontSelect) {
            fontSelect.value = TextControlSystem.settings.fontFamily || TextControlSystem.defaults.fontFamily;
        }
    },
    closeTextControlsModal() {
        const modal = document.getElementById('text-controls-modal');
        if (modal) {
            modal.style.display = 'none';
        }
    },
    toggleTextControlsModal(anchor) {
        const modal = document.getElementById('text-controls-modal');
        if (!modal) {
            return;
        }

        if (modal.style.display === 'flex') {
            this.closeTextControlsModal();
        } else {
            this.openTextControlsModal(anchor);
        }
    },
    setupTextControlsModal() {
        const closeBtn = document.getElementById('close-text-controls-btn');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeTextControlsModal());
        }
    }
};

// 24. Application Initialization
async function initializeApplication() {
    if (typeof primePracticeWarningFromDueCache === 'function') {
        primePracticeWarningFromDueCache();
    }

    await ExtensionStorage.init();

    const spacedRepetitionManager = uiApp.getSpacedRepetitionManager ? uiApp.getSpacedRepetitionManager() : window.SpacedRepetitionManager;
    if (spacedRepetitionManager && typeof spacedRepetitionManager.loadSchedule === 'function') {
        spacedRepetitionManager.loadSchedule();
    }

    if (!statisticsManager) {
        statisticsManager = new StatisticsManager();
        window.statisticsManager = statisticsManager;
    }

    if (uiApp.setService) {
        uiApp.setService('statisticsManager', statisticsManager);
    }

    // Resolve the due-review warning before the heavier dashboard/list rendering
    // work begins, then yield once so the browser can actually paint it.
    if (typeof showPracticeWarning === 'function') {
        showPracticeWarning();
    }

    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
        try {
            chrome.runtime.sendMessage({ type: 'tugadi-sync-review-check', reason: 'popup-open' }).catch(() => {});
        } catch (error) {
            // Ignore messaging failures.
        }
    }

    await new Promise((resolve) => window.requestAnimationFrame(() => resolve()));

    // Initialize all systems
    TextControlSystem.init();
    ContextMenu.init();
    ModalSystem.init();

    // Load saved data and restore UI state
    loadSavedProgress();
    displayWordList();
    applySavedThemePreference();
    bindPracticeModalCloseButton();
    initializeStatisticsDashboardUI();
    handleLaunchReviewContext();

    // Refresh once more after the dashboard has injected due-review items and
    // repaired any imported state.
    if (typeof showPracticeWarning === 'function') {
        showPracticeWarning();
    }

    // Note: We only block clipboard actions inside rewrite inputs (Word List + Spelling Mistakes)
    // via attachGlobalEventListeners(). Copying normal UI text (like the original sentence)
    // should remain available.

    // Prevent default context menu
    document.addEventListener('contextmenu', event => event.preventDefault());

    // Attach event listeners to interactive elements now that DOM is ready
    attachGlobalEventListeners();

    // Show onboarding if this is the first run. This must be invoked
    // after the DOM has been fully initialised and controls are ready.
}

// Initialize the application when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    initializeApplication().catch((error) => {
        console.error('Failed to initialize the application.', error);
        showTransientMessage('Saved data could not be loaded. Starting with defaults.');
    });
});

uiApp.modules.ui = {
    showConfirmation,
    showTransientMessage,
    applySavedThemePreference,
    bindPracticeModalCloseButton,
    ColorManager,
    ResultManager,
    TextControlSystem,
    attachGlobalEventListeners,
    ContextMenu,
    ModalSystem,
    GifFeedbackSystem,
    initializeApplication
};
