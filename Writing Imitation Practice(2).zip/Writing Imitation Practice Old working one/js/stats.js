const statsApp = window.WritingImitationPractice || (window.WritingImitationPractice = {});
statsApp.state = statsApp.state || {};
statsApp.services = statsApp.services || {};
statsApp.modules = statsApp.modules || {};
statsApp.utils = statsApp.utils || {};
statsApp.storage = statsApp.storage || {};
statsApp.dom = statsApp.dom || {};


/*
 * Statistics dashboard controls and spaced repetition/statistics engines.
 */

/**
 * Wire up statistics dashboard shortcuts and controls after the DOM is ready.
 */
function initializeStatisticsDashboardUI() {
    statisticsManager.updateUI();

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            const dashboard = document.getElementById('statistics-dashboard');
            const statsBtn = document.getElementById('stats-dashboard-btn');
            if (dashboard.classList.contains('open')) {
                dashboard.classList.remove('open');
                statsBtn.classList.remove('active');
            }
        }
    });

    document.addEventListener('click', (event) => {
        // If a confirmation dialog is open, don't auto-close the dashboard.
        // This prevents accidental closes when the user is confirming deletes.
        if (document.getElementById('confirmation-overlay')) {
            return;
        }
        const dashboard = document.getElementById('statistics-dashboard');
        const statsBtn = document.getElementById('stats-dashboard-btn');
        if (dashboard.classList.contains('open') &&
            !dashboard.contains(event.target) &&
            !statsBtn.contains(event.target)) {
            dashboard.classList.remove('open');
            statsBtn.classList.remove('active');
        }
    });

    if (typeof computeStorageUsage === 'function') {
        computeStorageUsage();
    }

    const clearMistakesBtn = document.getElementById('clear-mistakes-btn');
    if (clearMistakesBtn) {
        clearMistakesBtn.addEventListener('click', clearMistakesAndReviews);
    }

    const resetAllBtn = document.getElementById('reset-all-btn');
    if (resetAllBtn) {
        resetAllBtn.addEventListener('click', resetAllData);
    }

    const statResetButtons = document.querySelectorAll('.stat-reset-btn');
    statResetButtons.forEach(btn => {
        btn.addEventListener('click', (evt) => {
            evt.stopPropagation();
            const key = btn.getAttribute('data-stat');
            if (key) {
                clearIndividualStat(key);
            }
        });
    });
}


/**
 * Remove all practice data, settings, word lists and spaced repetition
 * schedules associated with this extension. This function clears every
 * entry in ExtensionStorage and resets the in‑memory statistics and spaced
 * repetition manager. It prompts the user for confirmation before
 * proceeding and updates the UI afterwards. This does not reload the page
 * so any runtime state (e.g. timers) is also stopped.
 */
function resetAllData() {
    showConfirmation('Are you sure you want to reset all data? This will erase your practice days, practice history, word lists, mistakes and reviews.', function(confirmed) {
        if (!confirmed) {
            return;
        }
        try {
            ExtensionStorage.clearOwnedKeys();
        } catch (e) {
            // Ignore errors if storage cannot be cleared
        }
        // Reset statistics manager if available
        if (typeof statisticsManager !== 'undefined' && statisticsManager) {
            // Stop any running timer
            if (typeof statisticsManager.stopTimer === 'function') {
                statisticsManager.stopTimer();
            }
            statisticsManager.stats = {
                streak: 0,
                practiceDays: 0,
                totalPractices: 0,
                lastPracticeDate: null,
                lastPracticeDateKey: null,
                practiceHistory: []
            };
            const today = new Date().toDateString();
            statisticsManager.todayStats = {
                date: today,
                practiceTime: 0,
                mistakes: [],
                sentences: 0,
                completedSentences: 0,
                firstTrySuccesses: 0
            };
            // Persist the blank stats
            if (typeof statisticsManager.saveStats === 'function') {
                statisticsManager.saveStats();
            }
            if (typeof statisticsManager.saveTodayStats === 'function') {
                statisticsManager.saveTodayStats();
            }
        }
        // Reset spaced repetition schedule
        if (typeof SpacedRepetitionManager !== 'undefined' && SpacedRepetitionManager) {
            SpacedRepetitionManager.schedule = {};
            if (typeof SpacedRepetitionManager.saveSchedule === 'function') {
                SpacedRepetitionManager.saveSchedule();
            }
        }
        // Update UI and storage usage
        if (typeof statisticsManager !== 'undefined' && statisticsManager && typeof statisticsManager.updateUI === 'function') {
            statisticsManager.updateUI();
        }
        computeStorageUsage();
    });
}

/**
 * Clear only the spelling mistakes recorded in today’s statistics and
 * remove any spaced repetition entries that originated from mistakes.
 * Vocabulary items saved in the user’s word list are preserved. This
 * function prompts the user for confirmation and then updates the UI.
 */
function clearMistakesAndReviews() {
    showConfirmation('Are you sure you want to clear all mistakes and review items? This will remove today’s mistakes and scheduled review words, but keep your word list and other statistics intact.', function(confirmed) {
        if (!confirmed) {
            return;
        }
        // Remove current mistakes
        if (typeof statisticsManager !== 'undefined' && statisticsManager) {
            statisticsManager.todayStats.mistakes = [];
            if (typeof statisticsManager.saveTodayStats === 'function') {
                statisticsManager.saveTodayStats();
            }
        }
        // Remove spaced repetition entries that are not from the word list
        if (typeof SpacedRepetitionManager !== 'undefined' && SpacedRepetitionManager) {
            const schedule = SpacedRepetitionManager.schedule || {};
            for (const key in schedule) {
                if (Object.prototype.hasOwnProperty.call(schedule, key)) {
                    const entry = schedule[key];
                    // Preserve entries of type 'wordList'
                    if (!entry || entry.type !== 'wordList') {
                        delete schedule[key];
                    }
                }
            }
            if (typeof SpacedRepetitionManager.saveSchedule === 'function') {
                SpacedRepetitionManager.saveSchedule();
            }
        }
        // Refresh UI and storage usage indicator
        if (typeof statisticsManager !== 'undefined' && statisticsManager && typeof statisticsManager.updateUI === 'function') {
            statisticsManager.updateUI();
        }
        computeStorageUsage();
    });
}

/**
 * Reset only the user’s basic statistics. This clears the practice day count,
 * today’s practice duration, total practice count and the first‑try
 * success rate without touching the practice history or mistake/review
 * lists. It prompts for confirmation before proceeding. After resetting
 * the values, the UI and storage indicators are refreshed.
 */
function resetStatisticsOnly() {
    showConfirmation('Are you sure you want to reset your statistics? This will reset your practice day count, today\'s practice time, total practices, and Clean Pass rate. Your practice history and mistakes will remain.', function(confirmed) {
        if (!confirmed) {
            return;
        }
        // Ensure the statisticsManager exists before attempting to modify it
        if (typeof statisticsManager !== 'undefined' && statisticsManager) {
            // Reset overall streak and total practice count
            statisticsManager.stats.streak = 0;
            statisticsManager.stats.practiceDays = 0;
            statisticsManager.stats.totalPractices = 0;
            statisticsManager.stats.lastPracticeDate = null;
                statisticsManager.stats.lastPracticeDateKey = null;
            // Persist the updated overall stats
            if (typeof statisticsManager.saveStats === 'function') {
                statisticsManager.saveStats();
            }
            // Reset the daily counters (practice time, sentences and first‑try successes)
            // while preserving the current mistakes array. Use the existing
            // resetDailyStats() method if available, because it resets the timer
            // and clears session‑tracking variables without wiping mistakes.
            if (typeof statisticsManager.resetDailyStats === 'function') {
                statisticsManager.resetDailyStats();
            } else {
                // Fallback manual reset if the method is missing
                statisticsManager.stopTimer && statisticsManager.stopTimer();
                statisticsManager.todayStats.practiceTime = 0;
                statisticsManager.todayStats.sentences = 0;
                statisticsManager.todayStats.completedSentences = 0;
                statisticsManager.todayStats.firstTrySuccesses = 0;
                // Do not modify the mistakes array
                if (typeof statisticsManager.saveTodayStats === 'function') {
                    statisticsManager.saveTodayStats();
                }
                // Also update lastSavedTime and activeSession
                statisticsManager.lastSavedTime = 0;
                ExtensionStorage.removeItem('activeSession');
            }
            // Finally update the user interface
            if (statisticsManager && typeof statisticsManager.updateUI === 'function') {
                statisticsManager.updateUI();
            }
        }
        // Refresh the storage bar and usage indicator after modifications
        if (typeof computeStorageUsage === 'function') {
            computeStorageUsage();
        }
    });
}

/**
 * Clear a single statistic based on the provided key. Each stat corresponds
 * to a field within either the persistent `stats` object or the daily
 * `todayStats` object on the statisticsManager. After resetting, the
 * function saves the modified data, updates the UI and refreshes the
 * storage usage indicator.  Confirmation is requested to prevent
 * accidental data loss.
 *
 * @param {string} key - The statistic key to reset. Supported values:
 *   'streak' – resets the practice day counter (stats.streak).
 *   'practiceTime' – resets today’s accumulated practice time and stops any active timer.
 *   'totalPractices' – resets the total number of practice sessions.
 *   'successRate' – resets today’s sentences and first‑try success counts.
 */
function clearIndividualStat(key) {
    let message = 'Are you sure you want to reset this statistic?';
    let title = 'Reset statistic';
    // Provide more specific copy for the UI buttons on the dashboard.
    if (key === 'streak') {
        message = 'Are you sure you want to reset practice days?';
        title = 'Reset Practice Days';
    } else if (key === 'totalPractices') {
        message = 'Are you sure you want to reset total practices?';
        title = 'Reset Total Practices';
    } else if (key === 'practiceTime') {
        message = "Are you sure you want to reset Practice Time?";
        title = "Reset Practice Time";
    } else if (key === 'successRate') {
        message = 'Are you sure you want to reset Clean Pass?';
        title = 'Reset Clean Pass';
    }

    showConfirmation(message, function(confirmed) {
        if (!confirmed) {
            return;
        }
        if (typeof statisticsManager === 'undefined' || !statisticsManager) {
            return;
        }
        switch (key) {
            case 'streak':
                statisticsManager.stats.streak = 0;
                statisticsManager.stats.practiceDays = 0;
                statisticsManager.stats.lastPracticeDate = null;
                statisticsManager.stats.lastPracticeDateKey = null;
                if (typeof statisticsManager.saveStats === 'function') {
                    statisticsManager.saveStats();
                }
                break;
            case 'practiceTime':
                // Stop any running timer and reset the accumulated practice time
                if (typeof statisticsManager.stopTimer === 'function') {
                    statisticsManager.stopTimer();
                }
                statisticsManager.todayStats.practiceTime = 0;
                // Clear the saved session state
                statisticsManager.lastSavedTime = 0;
                try {
                    ExtensionStorage.removeItem('activeSession');
                } catch (e) {
                    /* ignore */
                }
                if (typeof statisticsManager.saveTodayStats === 'function') {
                    statisticsManager.saveTodayStats();
                }
                break;
            case 'totalPractices':
                statisticsManager.stats.totalPractices = 0;
                if (typeof statisticsManager.saveStats === 'function') {
                    statisticsManager.saveStats();
                }
                break;
            case 'successRate':
                statisticsManager.todayStats.sentences = 0;
                statisticsManager.todayStats.completedSentences = 0;
                statisticsManager.todayStats.firstTrySuccesses = 0;
                if (typeof statisticsManager.saveTodayStats === 'function') {
                    statisticsManager.saveTodayStats();
                }
                break;
            default:
                return;
        }
        // Update the interface and storage usage bar
        if (statisticsManager && typeof statisticsManager.updateUI === 'function') {
            statisticsManager.updateUI();
        }
        if (typeof computeStorageUsage === 'function') {
            computeStorageUsage();
        }
    }, { title, confirmText: 'Reset', cancelText: 'Cancel' });
}


//  -------- Statistics Manager Class Implementation --------

// Statistics Manager Class
class StatisticsManager {
    constructor() {
        this.sessionStartTime = null;
        const activeSession = this.loadActiveSession();
        this.lastSavedTime = activeSession.savedTime;
        this.currentSessionAltSentences = activeSession.altSentences;
        this.currentSessionAltPeeks = activeSession.altPeeks;
        this.timerInterval = null;
        this.stats = this.loadStats();
        this.todayStats = this.loadTodayStats();
        // Before binding events or updating the UI, inject any words due for
        // practice from the spaced repetition schedule into today's mistake list.
        // This ensures that previously scheduled vocabulary and past mistakes
        // surface for review alongside new errors.  Injecting here allows the
        // items to be shuffled and displayed when the UI first renders.
        this.injectDueWords();
        if (typeof SpacedRepetitionManager !== 'undefined' && SpacedRepetitionManager && typeof SpacedRepetitionManager.cleanupMasteredWordListReviews === 'function') {
            SpacedRepetitionManager.cleanupMasteredWordListReviews();
        }
        this.currentSessionMistakes = 0;
        
        // Initialize immediately
        this.bindEvents();
        this.checkDayReset();
        this.updateUI();
        
        // Resume timer if there was an active session
        if (this.lastSavedTime > 0) {
            this.todayStats.practiceTime = this.lastSavedTime;
            this.startTimer();
        }
    }

    getLocalDayKey(value = new Date()) {
        const date = value instanceof Date ? new Date(value.getTime()) : new Date(value || Date.now());
        if (Number.isNaN(date.getTime())) {
            return null;
        }
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    dayKeyToDate(dayKey) {
        const match = String(dayKey || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (!match) {
            return null;
        }
        return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 12, 0, 0, 0);
    }
    normalizeStoredDayKey(value) {
        if (!value) {
            return null;
        }
        if (/^\d{4}-\d{2}-\d{2}$/.test(String(value))) {
            return String(value);
        }
        const parsed = new Date(value);
        if (Number.isNaN(parsed.getTime())) {
            return null;
        }
        return this.getLocalDayKey(parsed);
    }
    getDayDifference(fromDayKey, toDayKey) {
        const from = this.dayKeyToDate(fromDayKey);
        const to = this.dayKeyToDate(toDayKey);
        if (!from || !to) {
            return null;
        }
        return Math.round((to.getTime() - from.getTime()) / (24 * 60 * 60 * 1000));
    }
    getSessionDayKey(session) {
        if (!session || typeof session !== 'object') {
            return null;
        }
        return this.normalizeStoredDayKey(session.dayKey || session.dateKey || session.date);
    }
    getAttemptDayKey(entry) {
        if (!entry || typeof entry !== 'object') {
            return null;
        }
        return this.normalizeStoredDayKey(entry.dayKey || entry.dateKey || entry.timestamp || entry.date);
    }
    getLatestPracticeDayKeyFromHistory(history = this.stats && this.stats.practiceHistory) {
        const list = Array.isArray(history) ? history : [];
        let latestKey = null;

        list.forEach((session) => {
            const key = this.getSessionDayKey(session);
            if (!key) {
                return;
            }
            if (!latestKey || this.getDayDifference(latestKey, key) > 0) {
                latestKey = key;
            }
        });

        return latestKey;
    }
    getAllActivityDayKeys(stats = this.stats) {
        const unique = new Set();
        const history = Array.isArray(stats && stats.practiceHistory) ? stats.practiceHistory : [];
        const attempts = Array.isArray(stats && stats.attemptLog) ? stats.attemptLog : [];

        history.forEach((session) => {
            const key = this.getSessionDayKey(session);
            if (key) {
                unique.add(key);
            }
        });

        attempts.forEach((entry) => {
            const key = this.getAttemptDayKey(entry);
            if (key) {
                unique.add(key);
            }
        });

        return Array.from(unique).sort();
    }
    getLatestActivityDayKey(stats = this.stats) {
        const keys = this.getAllActivityDayKeys(stats);
        return keys.length ? keys[keys.length - 1] : null;
    }
    getConsecutiveStreakFromDayKeys(dayKeys, endDayKey = null) {
        const keys = Array.isArray(dayKeys) ? dayKeys.filter(Boolean).slice().sort() : [];
        if (!keys.length) {
            return 0;
        }

        let index = keys.length - 1;
        if (endDayKey) {
            index = keys.lastIndexOf(endDayKey);
            if (index === -1) {
                return 0;
            }
        }

        let streak = 1;
        let cursor = keys[index];
        for (let i = index - 1; i >= 0; i -= 1) {
            const diff = this.getDayDifference(keys[i], cursor);
            if (diff === 1) {
                streak += 1;
                cursor = keys[i];
                continue;
            }
            if (diff === 0) {
                continue;
            }
            break;
        }
        return streak;
    }
    getPracticeDayCount(stats = this.stats) {
        const unique = new Set(this.getAllActivityDayKeys(stats));
        const storedKey = this.normalizeStoredDayKey(stats && (stats.lastPracticeDateKey || stats.lastPracticeDate));
        if (storedKey) {
            unique.add(storedKey);
        }
        return unique.size;
    }
    getResolvedPracticeDayCount(stats = this.stats) {
        const computed = this.getPracticeDayCount(stats);
        const stored = Math.max(0, Number(stats && (stats.practiceDays ?? stats.streak)) || 0);
        return Math.max(stored, computed);
    }
    getMostRecentActivityDate(stats = this.stats) {
        const candidates = [];
        const pushCandidate = (value) => {
            if (!value) {
                return;
            }
            const parsed = value instanceof Date ? new Date(value.getTime()) : new Date(value);
            if (!Number.isNaN(parsed.getTime())) {
                candidates.push(parsed);
            }
        };

        const history = Array.isArray(stats && stats.practiceHistory) ? stats.practiceHistory : [];
        const attempts = Array.isArray(stats && stats.attemptLog) ? stats.attemptLog : [];

        pushCandidate(stats && (stats.lastPracticeDate || stats.lastPracticeDateKey));
        history.forEach((session) => pushCandidate(session && (session.date || session.timestamp || session.dayKey || session.dateKey)));
        attempts.forEach((entry) => pushCandidate(entry && (entry.timestamp || entry.date || entry.dayKey || entry.dateKey)));

        if (!candidates.length) {
            return null;
        }

        return candidates.reduce((latest, candidate) => {
            if (!latest || candidate.getTime() > latest.getTime()) {
                return candidate;
            }
            return latest;
        }, null);
    }
    getHoursDifference(fromValue, toValue = new Date()) {
        const from = fromValue instanceof Date ? new Date(fromValue.getTime()) : new Date(fromValue || Date.now());
        const to = toValue instanceof Date ? new Date(toValue.getTime()) : new Date(toValue || Date.now());
        if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) {
            return null;
        }
        return (to.getTime() - from.getTime()) / (60 * 60 * 1000);
    }
    clampPercent(value) {
        const numeric = Number(value);
        if (!Number.isFinite(numeric)) {
            return 0;
        }
        return Math.max(0, Math.min(100, Math.round(numeric)));
    }
    computeFirstTrySuccessRate(completedSentences, firstTrySuccesses) {
        const total = Math.max(0, Number(completedSentences) || 0);
        const firstTry = Math.max(0, Number(firstTrySuccesses) || 0);
        if (total <= 0) {
            return 0;
        }
        return this.clampPercent((firstTry / total) * 100);
    }
    computeSessionSuccessRate({ completedSentences = 0, mistakes = 0, altUsageRate = 0, firstTrySuccessRate = 0 } = {}) {
        const total = Math.max(0, Number(completedSentences) || 0);
        const firstTryScore = this.clampPercent(firstTrySuccessRate);
        const safeMistakes = Math.max(0, Number(mistakes) || 0);
        const safeAltUsageRate = this.clampPercent(altUsageRate);

        // Success is broader than first-try accuracy. It stays high when the
        // learner solves sentences with few retries and little Alt reliance,
        // even if first-try accuracy is not perfect.
        const mistakesPerSentence = total > 0 ? (safeMistakes / total) : safeMistakes;
        const mistakeScore = this.clampPercent(100 - (mistakesPerSentence * 50));
        const altScore = this.clampPercent(100 - safeAltUsageRate);

        return this.clampPercent((firstTryScore * 0.5) + (mistakeScore * 0.35) + (altScore * 0.15));
    }
    repairStatsForConsistency(stats) {
        const nextStats = stats && typeof stats === 'object' ? stats : {};

        nextStats.practiceHistory = Array.isArray(nextStats.practiceHistory) ? nextStats.practiceHistory : [];
        nextStats.attemptLog = Array.isArray(nextStats.attemptLog) ? nextStats.attemptLog : [];

        nextStats.practiceHistory = nextStats.practiceHistory
            .filter((session) => session && typeof session === 'object')
            .map((session) => {
                const dayKey = this.getSessionDayKey(session);
                const sentences = Math.max(0, Number(session.completedSentences ?? session.sentences) || 0);
                const mistakes = Math.max(0, Number(session.mistakes) || 0);
                const altUsageCount = Math.max(0, Number(session.altUsageCount) || 0);
                const derivedAltUsageRate = sentences > 0 ? Math.round((altUsageCount / sentences) * 100) : 0;
                const altUsageRate = this.clampPercent(
                    session.altUsageRate != null
                        ? session.altUsageRate
                        : derivedAltUsageRate
                );
                const firstTrySuccessRate = this.clampPercent(
                    session.firstTrySuccessRate != null
                        ? session.firstTrySuccessRate
                        : session.successRate
                );
                const successRate = this.computeSessionSuccessRate({
                    completedSentences: sentences,
                    mistakes,
                    altUsageRate,
                    firstTrySuccessRate
                });
                const normalizedSession = {
                    ...session,
                    sentences,
                    completedSentences: sentences,
                    mistakes,
                    altUsageCount,
                    altUsageRate,
                    firstTrySuccessRate,
                    successRate
                };
                return dayKey ? { ...normalizedSession, dayKey } : normalizedSession;
            });

        nextStats.attemptLog = nextStats.attemptLog
            .filter((entry) => entry && typeof entry === 'object')
            .map((entry) => {
                const dayKey = this.getAttemptDayKey(entry);
                return dayKey ? { ...entry, dayKey } : { ...entry };
            });

        if (typeof nextStats.streak !== 'number' || !Number.isFinite(nextStats.streak) || nextStats.streak < 0) {
            nextStats.streak = 0;
        }
        if (typeof nextStats.practiceDays !== 'number' || !Number.isFinite(nextStats.practiceDays) || nextStats.practiceDays < 0) {
            nextStats.practiceDays = 0;
        }
        if (typeof nextStats.totalPractices !== 'number' || !Number.isFinite(nextStats.totalPractices) || nextStats.totalPractices < 0) {
            nextStats.totalPractices = 0;
        }

        const storedPracticeKey = this.normalizeStoredDayKey(nextStats.lastPracticeDateKey || nextStats.lastPracticeDate);
        const latestActivityKey = this.getLatestActivityDayKey(nextStats);

        if (storedPracticeKey && latestActivityKey) {
            nextStats.lastPracticeDateKey = this.getDayDifference(storedPracticeKey, latestActivityKey) > 0
                ? latestActivityKey
                : storedPracticeKey;
        } else {
            nextStats.lastPracticeDateKey = storedPracticeKey || latestActivityKey || null;
        }

        if (nextStats.lastPracticeDateKey) {
            const derivedDate = this.dayKeyToDate(nextStats.lastPracticeDateKey);
            nextStats.lastPracticeDate = derivedDate ? derivedDate.toISOString() : null;
        } else {
            nextStats.lastPracticeDate = null;
        }

        const computedPracticeDays = this.getPracticeDayCount(nextStats);

        if (computedPracticeDays > 0) {
            nextStats.practiceDays = Math.max(nextStats.practiceDays, computedPracticeDays, nextStats.streak);
            nextStats.streak = Math.max(nextStats.streak, nextStats.practiceDays);
        } else {
            nextStats.practiceDays = Math.max(nextStats.practiceDays, nextStats.streak);
        }

        return nextStats;
    }
    // Data Loading Methods
    loadStats() {
        const savedStats = getStoredJSON('practiceStats', null);
        const stats = savedStats ? savedStats : {
            streak: 0,
            practiceDays: 0,
            totalPractices: 0,
            lastPracticeDate: null,
            lastPracticeDateKey: null,
            practiceHistory: []
        };

        return this.repairStatsForConsistency(stats);
    }
    loadActiveSession() {
        const session = getStoredJSON('activeSession', null);
        if (session) {
            const today = new Date().toDateString();
            if (session.date === today) {
                return {
                    savedTime: Number(session.savedTime) || 0,
                    altSentences: session.altSentences && typeof session.altSentences === 'object' ? session.altSentences : {},
                    altPeeks: Number(session.altPeeks) || 0
                };
            }
            ExtensionStorage.removeItem('activeSession');
        }
        return {
            savedTime: 0,
            altSentences: {},
            altPeeks: 0
        };
    }
    loadTodayStats() {
        const today = new Date().toDateString();
        const savedStats = getStoredJSON('todayStats', {});
        if (savedStats.date !== today) {
            return {
                date: today,
                practiceTime: 0,
                mistakes: savedStats.mistakes || [], // Preserve existing mistakes
                sentences: 0,
                completedSentences: 0,
                firstTrySuccesses: 0
            };
        }
        return {
            ...savedStats,
            practiceTime: Number(savedStats.practiceTime) || 0,
            mistakes: Array.isArray(savedStats.mistakes) ? savedStats.mistakes : [],
            sentences: Math.max(0, Number(savedStats.completedSentences ?? savedStats.sentences) || 0),
            completedSentences: Math.max(0, Number(savedStats.completedSentences ?? savedStats.sentences) || 0),
            firstTrySuccesses: Math.max(0, Number(savedStats.firstTrySuccesses) || 0)
        };
    }
    // Event Binding
    bindEvents() {
        const dashboard = document.getElementById('statistics-dashboard');
        const statsBtn = document.getElementById('stats-dashboard-btn');
        const closeBtn = document.getElementById('close-stats-btn');
        if (statsBtn) {
            statsBtn.addEventListener('click', () => {
                const isOpen = dashboard.classList.contains('open');
                dashboard.classList.toggle('open', !isOpen);
                statsBtn.classList.toggle('active', !isOpen);
                if (!isOpen) this.updateUI();
            });
        }
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                dashboard.classList.remove('open');
                if (statsBtn) statsBtn.classList.remove('active');
            });
        }
        window.addEventListener('focus', () => this.checkDayReset());
        window.addEventListener('resize', () => this.queueMistakeActionAlignment());
    }
    // Data Saving Methods
    saveTodayStats() {
        ExtensionStorage.setItem('todayStats', JSON.stringify(this.todayStats));
    }
    saveStats() {
        this.stats = this.repairStatsForConsistency(this.stats);
        ExtensionStorage.setItem('practiceStats', JSON.stringify(this.stats));
    }
    saveSessionTime() {
        ExtensionStorage.setItem('activeSession', JSON.stringify({
            savedTime: this.todayStats.practiceTime,
            date: new Date().toDateString(),
            altSentences: this.currentSessionAltSentences || {},
            altPeeks: Number(this.currentSessionAltPeeks) || 0
        }));
    }
    // Timer Management
    startTimer() {
        if (this.timerInterval) return;
        this.sessionStartTime = Date.now();
        this.timerInterval = setInterval(() => {
            if (this.sessionStartTime) {
                const elapsedMinutes = Math.floor((Date.now() - this.sessionStartTime) / 60000);
                this.todayStats.practiceTime = this.lastSavedTime + elapsedMinutes;
                this.saveTodayStats();
                this.saveSessionTime();
                this.updateBasicStats();
            }
        }, 30000);
    }
    stopTimer(options = {}) {
        const persistElapsed = options.persistElapsed !== false;

        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }

        if (this.sessionStartTime && persistElapsed) {
            const elapsedMinutes = Math.floor((Date.now() - this.sessionStartTime) / 60000);
            this.todayStats.practiceTime = this.lastSavedTime + elapsedMinutes;
            this.saveTodayStats();
        }

        this.sessionStartTime = null;
        this.lastSavedTime = 0;
        ExtensionStorage.removeItem('activeSession');
    }
    // Day Reset Check
    checkDayReset() {
        const today = new Date().toDateString();
        const lastReset = ExtensionStorage.getItem('lastStatsReset');

        if (lastReset !== today) {
            const hasRestoredTodayState = this.todayStats &&
                this.todayStats.date === today &&
                !this.timerInterval &&
                !this.sessionStartTime;

            if (hasRestoredTodayState) {
                ExtensionStorage.setItem('lastStatsReset', today);
                return;
            }

            // Stop the active timer before resetting counters so elapsed time
            // from the previous day does not leak into the new day.
            this.stopTimer({ persistElapsed: false });

            const existingMistakes = this.todayStats.mistakes || [];
            this.todayStats = {
                date: today,
                practiceTime: 0,
                mistakes: existingMistakes,
                sentences: 0,
                completedSentences: 0,
                firstTrySuccesses: 0
            };
            this.saveTodayStats();
            ExtensionStorage.setItem('lastStatsReset', today);
            this.updateUI();
        }
    }

    getPendingInitialMistakes(options = {}) {
        const includeToday = Boolean(options.includeToday);
        const todayStart = new Date();
        todayStart.setHours(0, 0, 0, 0);
        const todayStartMs = todayStart.getTime();

        return (this.todayStats && Array.isArray(this.todayStats.mistakes) ? this.todayStats.mistakes : [])
            .filter((mistake) => {
                if (!mistake || mistake.type === 'wordList' || mistake.spaced) {
                    return false;
                }

                const baseCorrect = normalizeWordKey(mistake.correct || mistake.incorrect || '');
                if (!baseCorrect) {
                    return false;
                }

                if (includeToday) {
                    return true;
                }

                const timestamp = mistake.timestamp ? new Date(mistake.timestamp).getTime() : Number.NaN;
                return Number.isNaN(timestamp) || timestamp < todayStartMs;
            });
    }

    getPendingInitialMistakeWordSet(options = {}) {
        const set = new Set();
        this.getPendingInitialMistakes(options).forEach((mistake) => {
            const key = normalizeWordKey(mistake.correct || mistake.incorrect || '');
            if (key) {
                set.add(key);
            }
        });
        return set;
    }

    cleanupPendingInitialMistakeSchedules() {
        if (typeof SpacedRepetitionManager === 'undefined' || !SpacedRepetitionManager || typeof SpacedRepetitionManager.removeWord !== 'function') {
            return false;
        }

        const pendingMistakes = this.getPendingInitialMistakes({ includeToday: true });
        if (!pendingMistakes.length) {
            return false;
        }

        const preserveWords = new Set();
        const pendingWords = new Set();
        pendingMistakes.forEach((mistake) => {
            const word = normalizeWordKey((mistake && (mistake.correct || mistake.incorrect)) || '');
            if (!word) return;
            pendingWords.add(word);
            if (mistake && mistake.preserveSchedule) {
                preserveWords.add(word);
            }
        });

        if (!pendingWords.size) {
            return false;
        }

        let changed = false;
        pendingWords.forEach((word) => {
            if (preserveWords.has(word)) {
                return;
            }

            const entry = typeof SpacedRepetitionManager.getEntry === 'function'
                ? SpacedRepetitionManager.getEntry(word, 'mistake')
                : null;

            if (entry) {
                SpacedRepetitionManager.removeWord(word, 'mistake');
                changed = true;
            }
        });

        return changed;
    }
    // UI Update Methods
    updateUI() {
        // Fresh spelling mistakes must stay in the normal rewrite queue until the
        // user rewrites them once. If an older build already scheduled one too
        // early, drop that stale schedule entry before surfacing due reviews.
        this.cleanupPendingInitialMistakeSchedules();

        // Before updating the interface, pull any items that are due from the spaced
        // repetition schedule into the mistakes list. This ensures that review
        // sessions are surfaced whenever the UI refreshes and promotes spaced
        // retrieval throughout the day. Duplicate words are ignored within
        // injectDueWords.
        this.injectDueWords();
        this.updateBasicStats();
        this.updateMistakesList();
        this.updatePracticeHistory();
        // After updating lists, refresh the practice warning display. This
        // ensures that the warning accurately reflects any changes to the
        // spaced repetition schedule (e.g., when mistakes are practiced).
        if (typeof showPracticeWarning === 'function') {
            showPracticeWarning();
        }
        // Update storage usage indicator whenever the statistics dashboard UI refreshes.
        if (typeof computeStorageUsage === 'function') {
            computeStorageUsage();
        }
    }
    updateBasicStats() {
        const elements = {
            streakCount: document.getElementById('streak-count'),
            practiceTime: document.getElementById('practice-time'),
            totalPractices: document.getElementById('total-practices'),
            successRate: document.getElementById('success-rate')
        };
        if (elements.streakCount) {
            const practiceDays = this.getResolvedPracticeDayCount(this.stats);
            elements.streakCount.textContent = `${practiceDays} days`;
        }
        if (elements.practiceTime) {
            elements.practiceTime.textContent = this.formatTime(this.todayStats.practiceTime);
        }
        if (elements.totalPractices) {
            elements.totalPractices.textContent = this.stats.totalPractices;
        }
        if (elements.successRate) {
            const completedSentences = Math.max(0, Number(this.todayStats.completedSentences ?? this.todayStats.sentences) || 0);
            const rate = completedSentences > 0
                ? Math.round((this.todayStats.firstTrySuccesses / completedSentences) * 100)
                : 0;
            elements.successRate.textContent = `${rate}%`;
        }
    }
    updateMistakesList() {
        const mistakesList = document.getElementById('recent-mistakes');
        const clearMistakesBtn = document.getElementById('clear-mistakes-btn');
        if (!mistakesList) return;
        let htmlSections = [];
        // ------------------
        // 1. Render today's mistakes
        // ------------------
        const todayMistakes = this.todayStats.mistakes || [];
        // Remove vocabulary entries that have identical incorrect/correct words and are
        // marked as type 'wordList' in the spaced schedule. These words are meant
        // for the Word List overlay and should not clutter the spelling mistakes
        // section.
        const filtered = todayMistakes.filter(m => {
            const baseIncorrect = m && m.incorrect ? m.incorrect.replace(/[.,!?]/g, '').trim().toLowerCase() : '';
            const baseCorrect = m && m.correct ? m.correct.replace(/[.,!?]/g, '').trim().toLowerCase() : '';
            const hasUsableWord = Boolean(baseCorrect || baseIncorrect);
            if (!hasUsableWord) {
                return false;
            }
            // Word List practice words are injected into today's list with incorrect===correct.
            // Hide only items that actually belong to the Word List flow.
            // Spelling-mistake reviews may have the same surface word as a word-list
            // entry, and those must stay visible in Spelling Mistakes.
            if (baseIncorrect && baseCorrect && baseIncorrect === baseCorrect && m.type === 'wordList') {
                return false;
            }
            return true;
        });
        // If entries were removed, update the stored stats to avoid drift
        if (filtered.length !== todayMistakes.length) {
            this.todayStats.mistakes = filtered;
            this.saveTodayStats();
        }
        if (clearMistakesBtn) {
            clearMistakesBtn.hidden = filtered.length === 0;
            clearMistakesBtn.style.display = filtered.length > 0 ? 'flex' : 'none';
        }
        if (filtered.length > 0) {
            const itemsHTML = filtered
                .map((mistake, index) => this.createMistakeItemHTML(mistake, index))
                .join('');
            htmlSections.push(itemsHTML);
        } else {
            htmlSections.push('<p class="empty-state">No mistakes recorded today</p>');
        }

        // No scheduled items are shown. Due words will be injected into
        // todayStats.mistakes via injectDueWords() and therefore appear above
        // when they are ready for review.
        // Set the combined HTML
        mistakesList.innerHTML = htmlSections.join('');
        // Attach event listeners to rewrite buttons for today's mistakes
        const rewriteButtons = mistakesList.querySelectorAll('.rewrite-btn');
        rewriteButtons.forEach(btn => {
            const idx = parseInt(btn.getAttribute('data-index'), 10);
            if (!isNaN(idx)) {
                btn.addEventListener('click', this.startRewrite.bind(this, idx));
            }
        });

        // Attach event listeners to delete buttons
        const deleteButtons = mistakesList.querySelectorAll('.delete-mistake-btn');
        deleteButtons.forEach(btn => {
            const idx = parseInt(btn.getAttribute('data-index'), 10);
            if (!isNaN(idx)) {
                btn.addEventListener('click', (event) => {
                    event.stopPropagation();
                    this.deleteMistake(idx);
                });
            }
        });

        this.queueMistakeActionAlignment();
    }
    queueMistakeActionAlignment() {
        if (this._mistakeActionAlignFrame) {
            cancelAnimationFrame(this._mistakeActionAlignFrame);
        }
        this._mistakeActionAlignFrame = requestAnimationFrame(() => {
            this._mistakeActionAlignFrame = null;
            this.alignMistakeActionButtons();
        });
    }
    alignMistakeActionButtons() {
        const items = document.querySelectorAll('#recent-mistakes .mistake-item');
        items.forEach(item => {
            if (item.classList.contains('rewriting')) {
                return;
            }

            const actions = item.querySelector('.mistake-corner-actions');
            if (!actions) {
                return;
            }

            const buttons = actions.querySelectorAll('.history-corner-btn');
            if (!buttons.length) {
                return;
            }

            const itemRect = item.getBoundingClientRect();
            if (!itemRect.height) {
                return;
            }

            const isSpacedItem = item.classList.contains('spaced');
            const wrongChip = item.querySelector('.mistake-chip.wrong');
            const correctChips = item.querySelectorAll('.mistake-chip.correct');
            const primaryChip = item.querySelector('.mistake-chip');
            const correctChip = correctChips.length
                ? correctChips[correctChips.length - 1]
                : primaryChip;
            const reviewTarget = item.querySelector('.mistake-review-row .review-status')
                || item.querySelector('.mistake-review-row')
                || item.querySelector('.review-status');

            let firstTarget = wrongChip || correctChip || primaryChip || reviewTarget;
            let secondTarget = null;

            if (isSpacedItem) {
                firstTarget = correctChip || primaryChip || reviewTarget;
                secondTarget = reviewTarget || correctChip || primaryChip || firstTarget;
            } else if (wrongChip && correctChip && wrongChip !== correctChip) {
                secondTarget = correctChip;
            } else {
                secondTarget = reviewTarget || correctChip || primaryChip || firstTarget;
            }

            const clampTop = (value, button) => {
                const buttonHeight = button.offsetHeight || 34;
                const maxTop = Math.max(8, item.clientHeight - buttonHeight - 8);
                return Math.max(8, Math.min(value, maxTop));
            };

            const targetCenterTop = (target, button, fallbackTop) => {
                if (!target) {
                    return clampTop(fallbackTop, button);
                }
                const targetRect = target.getBoundingClientRect();
                const buttonHeight = button.offsetHeight || 34;
                const centered = (targetRect.top - itemRect.top) + ((targetRect.height - buttonHeight) / 2);
                return clampTop(centered, button);
            };

            const firstButton = buttons[0];
            const firstTop = targetCenterTop(firstTarget, firstButton, 8);
            firstButton.style.top = `${Math.round(firstTop)}px`;

            if (buttons[1]) {
                const secondButton = buttons[1];
                const secondFallback = isSpacedItem ? firstTop + 44 : firstTop + 40;
                const minSeparation = isSpacedItem
                    ? Math.max((firstButton.offsetHeight || 34) + 10, 44)
                    : 40;
                let secondTop = targetCenterTop(secondTarget, secondButton, secondFallback);
                if (secondTarget === firstTarget || secondTop < firstTop + minSeparation) {
                    secondTop = clampTop(firstTop + minSeparation, secondButton);
                }
                secondButton.style.top = `${Math.round(secondTop)}px`;
            }
        });
    }
    updatePracticeHistory() {
        const historyList = document.getElementById('practice-history');
        if (!historyList) return;
        if (this.stats.practiceHistory && this.stats.practiceHistory.length > 0) {
            historyList.innerHTML = `
                ${this.stats.practiceHistory
                    .map((session, index) => this.createHistoryItemHTML(session, index))
                    .join('')}
                <div class="history-actions-row">
                    <button class="history-action-btn progress-history-btn" id="download-progress-report-btn" type="button">Progress Report</button>
                    <button class="history-action-btn delete-history-btn" id="clear-history-btn" type="button">Delete All</button>
                </div>`;
            // Attach click listener to clear history button
            const clearBtn = document.getElementById('clear-history-btn');
            if (clearBtn) {
                clearBtn.addEventListener('click', () => this.clearPracticeHistory());
            }

            const progressBtn = document.getElementById('download-progress-report-btn');
            if (progressBtn) {
                progressBtn.addEventListener('click', () => this.downloadProgressReport());
            }

            // Attach per-item delete listeners
            const itemDeleteButtons = historyList.querySelectorAll('.delete-history-item-btn');
            itemDeleteButtons.forEach(btn => {
                const idx = parseInt(btn.getAttribute('data-index'), 10);
                if (!isNaN(idx)) {
                    btn.addEventListener('click', (event) => {
                        event.stopPropagation();
                        this.deleteHistoryItem(idx);
                    });
                }
            });
        } else {
            historyList.innerHTML = '<p class="empty-state">No practice history available</p>';
        }
    }

    hasProgressExportData() {
        const history = Array.isArray(this.stats && this.stats.practiceHistory) ? this.stats.practiceHistory : [];
        const attempts = Array.isArray(this.stats && this.stats.attemptLog) ? this.stats.attemptLog : [];
        return history.length > 0 || attempts.length > 0;
    }

    downloadProgressReport() {
        const history = Array.isArray(this.stats && this.stats.practiceHistory) ? this.stats.practiceHistory.slice() : [];
        if (!history.length) {
            if (typeof showTransientMessage === 'function') {
                showTransientMessage('Complete a little more practice first so there is progress to export.');
            }
            return;
        }

        const now = new Date();
        const DAY = 24 * 60 * 60 * 1000;

        const safeNumber = (value) => {
            const n = Number(value);
            return Number.isFinite(n) ? n : 0;
        };
        const roundTo = (value, digits = 1) => {
            const factor = Math.pow(10, digits);
            return Math.round(safeNumber(value) * factor) / factor;
        };
        const escape = (value) => {
            const stringValue = value == null ? '' : String(value);
            if (typeof escapeHTML === 'function') {
                return escapeHTML(stringValue);
            }
            return stringValue
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        };
        const makeDateKey = (value) => {
            const date = value instanceof Date ? new Date(value.getTime()) : new Date(value || Date.now());
            if (Number.isNaN(date.getTime())) {
                return null;
            }
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        };
        const parseDayKey = (key) => {
            const raw = String(key || '');
            if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
                return null;
            }
            const [year, month, day] = raw.split('-').map(Number);
            const date = new Date(year, month - 1, day, 12, 0, 0, 0);
            return Number.isNaN(date.getTime()) ? null : date;
        };
        const formatDate = (value, options = {}) => {
            const date = value instanceof Date ? value : new Date(value || Date.now());
            if (Number.isNaN(date.getTime())) {
                return 'Unknown';
            }
            return date.toLocaleDateString(undefined, Object.keys(options).length ? options : { month: 'short', day: 'numeric' });
        };
        const formatDateTime = (value) => {
            const date = value instanceof Date ? value : new Date(value || Date.now());
            if (Number.isNaN(date.getTime())) {
                return 'Unknown';
            }
            return date.toLocaleString(undefined, {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit'
            });
        };
        const summarizeRows = (rows) => {
            const summary = {
                sessions: 0,
                sentences: 0,
                minutes: 0,
                mistakes: 0,
                successWeighted: 0,
                firstTryWeighted: 0,
                altWeighted: 0,
                weight: 0,
                avgSuccess: 0,
                avgFirstTrySuccess: 0,
                avgAltUsage: 0,
                avgMistakesPerSession: 0
            };
            (Array.isArray(rows) ? rows : []).forEach((row) => {
                summary.sessions += safeNumber(row && row.sessions);
                summary.sentences += safeNumber(row && row.sentences);
                summary.minutes += safeNumber(row && row.minutes);
                summary.mistakes += safeNumber(row && row.mistakes);
                summary.successWeighted += safeNumber(row && row.successWeighted);
                summary.firstTryWeighted += safeNumber(row && row.firstTryWeighted);
                summary.altWeighted += safeNumber(row && row.altWeighted);
                summary.weight += safeNumber(row && row.weight);
            });
            summary.avgSuccess = summary.weight ? Math.round(summary.successWeighted / summary.weight) : 0;
            summary.avgFirstTrySuccess = summary.weight ? Math.round(summary.firstTryWeighted / summary.weight) : 0;
            summary.avgAltUsage = summary.weight ? Math.round(summary.altWeighted / summary.weight) : 0;
            summary.avgMistakesPerSession = summary.sessions ? roundTo(summary.mistakes / summary.sessions, 1) : 0;
            return summary;
        };
        const formatDelta = (current, previous, options = {}) => {
            if (options.available === false) {
                return { tone: 'neutral', text: 'Need more history' };
            }
            const delta = safeNumber(current) - safeNumber(previous);
            if (Math.abs(delta) < 0.05) {
                return { tone: 'neutral', text: 'No real change' };
            }
            const digits = options.digits || 0;
            const suffix = options.suffix || '';
            const reverse = Boolean(options.reverse);
            const improved = reverse ? delta < 0 : delta > 0;
            const amount = digits === 0 ? Math.round(Math.abs(delta)) : roundTo(Math.abs(delta), digits);
            const signed = `${delta > 0 ? '+' : '-'}${amount}${suffix}`;
            return {
                tone: improved ? 'good' : 'warn',
                text: signed
            };
        };
        const buildStatus = (currentSummary, previousSummary, previousAvailable) => {
            if (!previousAvailable) {
                return {
                    tone: 'neutral',
                    title: 'Building baseline',
                    detail: 'One more full week unlocks a direct comparison.'
                };
            }

            const checks = [
                {
                    label: 'Success',
                    delta: safeNumber(currentSummary.avgSuccess) - safeNumber(previousSummary.avgSuccess),
                    threshold: 3,
                    reverse: false,
                    format: (value) => `${Math.round(Math.abs(value))} pts`
                },
                {
                    label: 'Mistakes',
                    delta: safeNumber(currentSummary.avgMistakesPerSession) - safeNumber(previousSummary.avgMistakesPerSession),
                    threshold: 0.2,
                    reverse: true,
                    format: (value) => String(roundTo(Math.abs(value), 1))
                },
                {
                    label: 'Alt help',
                    delta: safeNumber(currentSummary.avgAltUsage) - safeNumber(previousSummary.avgAltUsage),
                    threshold: 3,
                    reverse: true,
                    format: (value) => `${Math.round(Math.abs(value))} pts`
                }
            ];

            const improved = [];
            const slipped = [];
            checks.forEach((item) => {
                if (Math.abs(item.delta) < item.threshold) return;
                const isBetter = item.reverse ? item.delta < 0 : item.delta > 0;
                const phrase = `${item.label} ${item.delta > 0 ? 'up' : 'down'} ${item.format(item.delta)}`;
                if (isBetter) improved.push(phrase);
                else slipped.push(phrase);
            });

            if (improved.length >= 2 && slipped.length === 0) {
                return { tone: 'good', title: 'Improving', detail: improved.join(' · ') };
            }
            if (slipped.length >= 2 && improved.length === 0) {
                return { tone: 'warn', title: 'Needs attention', detail: slipped.join(' · ') };
            }
            if (!improved.length && !slipped.length) {
                return { tone: 'neutral', title: 'Steady', detail: 'The last two 7-day blocks are close.' };
            }
            return { tone: 'neutral', title: 'Mixed', detail: improved.concat(slipped).join(' · ') };
        };
        const renderMetricCard = (metric) => `
            <div class="metric-card">
                <div class="metric-top">
                    <span class="metric-label">${escape(metric.label)}</span>
                    <span class="delta-pill ${escape(metric.delta.tone)}">${escape(metric.delta.text)}</span>
                </div>
                <div class="metric-value">${escape(metric.current)}</div>
                <div class="metric-meta">
                    <span>Previous <strong>${escape(metric.previous)}</strong></span>
                    <span>Best <strong>${escape(metric.best)}</strong></span>
                </div>
                <div class="metric-note">${escape(metric.note)}</div>
            </div>`;
        const renderLineChart = (points, valueKey, options = {}) => {
            const width = 760;
            const height = 220;
            const paddingX = 24;
            const paddingTop = 20;
            const paddingBottom = 30;
            const values = points.map((point) => safeNumber(point && point[valueKey]));
            const bestValue = options.bestValue == null ? null : safeNumber(options.bestValue);
            const max = Math.max(...(bestValue == null ? values : values.concat([bestValue])), 1);
            const min = Math.min(...values, 0, bestValue == null ? 0 : bestValue);
            const range = max - min || 1;
            const xFor = (index) => {
                if (values.length <= 1) return width / 2;
                return paddingX + ((width - (paddingX * 2)) * (index / (values.length - 1)));
            };
            const yFor = (value) => paddingTop + ((height - paddingTop - paddingBottom) * (1 - ((value - min) / range)));
            const pointsString = values.map((value, index) => `${xFor(index)},${yFor(value)}`).join(' ');
            const lastIndex = Math.max(0, values.length - 1);
            const formatValue = typeof options.formatter === 'function' ? options.formatter : ((value) => String(value));
            const latestText = values.length ? formatValue(values[lastIndex]) : '0';
            const bestText = bestValue == null ? '—' : formatValue(bestValue);
            return `
                <div class="trend-card">
                    <div class="trend-head">
                        <div>
                            <h3>${escape(options.label || '')}</h3>
                            <p>${escape(options.note || '')}</p>
                        </div>
                        <div class="trend-stats">
                            <span><strong>${escape(latestText)}</strong> latest</span>
                            <span><strong>${escape(bestText)}</strong> best</span>
                        </div>
                    </div>
                    <svg viewBox="0 0 ${width} ${height}" class="trend-svg" aria-hidden="true">
                        <line x1="${paddingX}" y1="${height - paddingBottom}" x2="${width - paddingX}" y2="${height - paddingBottom}" class="trend-axis"></line>
                        ${bestValue == null ? '' : `<line x1="${paddingX}" y1="${yFor(bestValue)}" x2="${width - paddingX}" y2="${yFor(bestValue)}" class="trend-best"></line>`}
                        <polyline points="${pointsString}" class="trend-line"></polyline>
                        ${values.map((value, index) => `<circle cx="${xFor(index)}" cy="${yFor(value)}" r="${index === lastIndex ? 4.5 : 3.5}" class="trend-dot${index === lastIndex ? ' active' : ''}"></circle>`).join('')}
                    </svg>
                    <div class="trend-foot">
                        <span>${escape(points[0] ? points[0].label : 'Earlier')}</span>
                        <span>${escape(points[lastIndex] ? points[lastIndex].label : 'Now')}</span>
                    </div>
                </div>`;
        };

        const normalizedHistory = history
            .map((session) => {
                const date = new Date(session && session.date ? session.date : Date.now());
                if (Number.isNaN(date.getTime())) {
                    return null;
                }
                return {
                    date,
                    dateKey: makeDateKey(date),
                    sentences: Math.max(0, safeNumber(session && session.sentences)),
                    duration: Math.max(0, safeNumber(session && session.duration)),
                    mistakes: Math.max(0, safeNumber(session && session.mistakes)),
                    successRate: Math.max(0, Math.min(100, safeNumber(session && session.successRate))),
                    firstTrySuccessRate: Math.max(0, Math.min(100, safeNumber(session && (session.firstTrySuccessRate ?? session.successRate)))),
                    altUsageRate: Math.max(0, Math.min(100, safeNumber(session && session.altUsageRate)))
                };
            })
            .filter(Boolean)
            .sort((a, b) => a.date - b.date);

        if (!normalizedHistory.length) {
            if (typeof showTransientMessage === 'function') {
                showTransientMessage('Complete a little more practice first so there is progress to export.');
            }
            return;
        }

        const dailyMap = new Map();
        normalizedHistory.forEach((session) => {
            const existing = dailyMap.get(session.dateKey) || {
                date: parseDayKey(session.dateKey) || session.date,
                dateKey: session.dateKey,
                sessions: 0,
                sentences: 0,
                minutes: 0,
                mistakes: 0,
                successWeighted: 0,
                firstTryWeighted: 0,
                altWeighted: 0,
                weight: 0
            };
            const weight = Math.max(1, session.sentences || 0);
            existing.sessions += 1;
            existing.sentences += session.sentences;
            existing.minutes += session.duration;
            existing.mistakes += session.mistakes;
            existing.successWeighted += session.successRate * weight;
            existing.firstTryWeighted += session.firstTrySuccessRate * weight;
            existing.altWeighted += session.altUsageRate * weight;
            existing.weight += weight;
            dailyMap.set(session.dateKey, existing);
        });

        const today = parseDayKey(makeDateKey(now)) || now;
        const latestHistoryEntry = normalizedHistory[normalizedHistory.length - 1] || null;
        const latestHistoryDate = latestHistoryEntry ? (parseDayKey(latestHistoryEntry.dateKey) || latestHistoryEntry.date) : null;
        const anchorDate = latestHistoryDate && latestHistoryDate.getTime() < today.getTime() ? latestHistoryDate : today;
        const buildWindow = (endDate, days) => {
            const end = new Date(endDate instanceof Date ? endDate.getTime() : endDate);
            end.setHours(12, 0, 0, 0);
            const rows = [];
            for (let i = days - 1; i >= 0; i -= 1) {
                const date = new Date(end.getTime() - (i * DAY));
                const key = makeDateKey(date);
                rows.push(dailyMap.get(key) || {
                    date,
                    dateKey: key,
                    sessions: 0,
                    sentences: 0,
                    minutes: 0,
                    mistakes: 0,
                    successWeighted: 0,
                    altWeighted: 0,
                    weight: 0
                });
            }
            return rows;
        };

        const currentRows = buildWindow(anchorDate, 7);
        const previousRows = buildWindow(new Date(anchorDate.getTime() - (7 * DAY)), 7);
        const currentSummary = summarizeRows(currentRows);
        const previousSummary = summarizeRows(previousRows);
        const previousAvailable = previousSummary.sessions > 0 || previousSummary.sentences > 0 || previousSummary.weight > 0;
        const currentRange = `${formatDate(currentRows[0].date)} – ${formatDate(currentRows[currentRows.length - 1].date)}`;
        const previousRange = `${formatDate(previousRows[0].date)} – ${formatDate(previousRows[previousRows.length - 1].date)}`;

        const blockSeries = [];
        for (let offset = 7; offset >= 0; offset -= 1) {
            const end = new Date(anchorDate.getTime() - (offset * 7 * DAY));
            const rows = buildWindow(end, 7);
            blockSeries.push({
                label: offset === 0 ? 'Now' : `${offset}w ago`,
                ...summarizeRows(rows)
            });
        }

        const windows = [];
        let cursor = parseDayKey(normalizedHistory[0].dateKey) || normalizedHistory[0].date;
        cursor = new Date(cursor.getTime());
        cursor.setHours(12, 0, 0, 0);
        while (cursor <= anchorDate) {
            const rows = buildWindow(cursor, 7);
            const summary = summarizeRows(rows);
            if (summary.sessions > 0 || summary.sentences > 0 || summary.weight > 0) {
                windows.push({ rows, summary });
            }
            cursor = new Date(cursor.getTime() + DAY);
        }

        const bestFor = (key, mode) => {
            if (!windows.length) return null;
            return windows.reduce((best, item) => {
                if (!best) return item;
                const currentValue = safeNumber(item.summary[key]);
                const bestValue = safeNumber(best.summary[key]);
                if (mode === 'min') {
                    return currentValue < bestValue ? item : best;
                }
                return currentValue > bestValue ? item : best;
            }, null);
        };

        const bestSuccess = bestFor('avgSuccess', 'max');
        const bestFirstTry = bestFor('avgFirstTrySuccess', 'max');
        const bestMistakes = bestFor('avgMistakesPerSession', 'min');
        const bestAlt = bestFor('avgAltUsage', 'min');
        const status = buildStatus(currentSummary, previousSummary, previousAvailable);

        const metrics = [
            {
                label: 'Success',
                current: `${currentSummary.avgSuccess}%`,
                previous: previousAvailable ? `${previousSummary.avgSuccess}%` : '—',
                best: bestSuccess ? `${bestSuccess.summary.avgSuccess}%` : '—',
                delta: formatDelta(currentSummary.avgSuccess, previousSummary.avgSuccess, { available: previousAvailable, digits: 0, suffix: ' pts' }),
                note: currentRange
            },
            {
                label: 'Clean Pass',
                current: `${currentSummary.avgFirstTrySuccess}%`,
                previous: previousAvailable ? `${previousSummary.avgFirstTrySuccess}%` : '—',
                best: bestFirstTry ? `${bestFirstTry.summary.avgFirstTrySuccess}%` : '—',
                delta: formatDelta(currentSummary.avgFirstTrySuccess, previousSummary.avgFirstTrySuccess, { available: previousAvailable, digits: 0, suffix: ' pts' }),
                note: `${currentSummary.sentences} sentences`
            },
            {
                label: 'Mistakes / session',
                current: String(currentSummary.avgMistakesPerSession),
                previous: previousAvailable ? String(previousSummary.avgMistakesPerSession) : '—',
                best: bestMistakes ? String(bestMistakes.summary.avgMistakesPerSession) : '—',
                delta: formatDelta(currentSummary.avgMistakesPerSession, previousSummary.avgMistakesPerSession, { available: previousAvailable, digits: 1, reverse: true }),
                note: currentRange
            },
            {
                label: 'Alt help',
                current: `${currentSummary.avgAltUsage}%`,
                previous: previousAvailable ? `${previousSummary.avgAltUsage}%` : '—',
                best: bestAlt ? `${bestAlt.summary.avgAltUsage}%` : '—',
                delta: formatDelta(currentSummary.avgAltUsage, previousSummary.avgAltUsage, { available: previousAvailable, digits: 0, suffix: ' pts', reverse: true }),
                note: currentRange
            }
        ];

        const activityNote = currentSummary.sessions < 2
            ? 'Low activity in the latest 7 days can make the comparison swing faster.'
            : `${currentSummary.sessions} sessions and ${currentSummary.sentences} sentences in the latest 7 days.`;

        const reportHtml = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Progress Report</title>
<style>
:root {
    --bg: #f6f8fc;
    --card: rgba(255,255,255,0.94);
    --border: rgba(148,163,184,0.18);
    --text: #0f172a;
    --muted: #64748b;
    --blue: #2563eb;
    --green: #15803d;
    --amber: #b45309;
    --shadow: 0 18px 44px rgba(15,23,42,0.08);
}
* { box-sizing: border-box; }
body {
    margin: 0;
    font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    background: linear-gradient(180deg, #eef4ff 0%, var(--bg) 240px, var(--bg) 100%);
    color: var(--text);
}
.page {
    width: min(1120px, calc(100% - 28px));
    margin: 0 auto;
    padding: 28px 0 40px;
}
.hero,
.metric-card,
.trend-card,
.note-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 24px;
    box-shadow: var(--shadow);
}
.hero {
    padding: 26px;
}
.hero-top {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
    color: var(--muted);
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}
.hero h1 {
    margin: 12px 0 0;
    font-size: clamp(30px, 4.6vw, 48px);
    line-height: 1.02;
}
.range-grid,
.metric-grid,
.trend-grid,
.note-grid {
    display: grid;
    gap: 14px;
}
.range-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    margin-top: 18px;
}
.range-card {
    padding: 14px 16px;
    border-radius: 18px;
    background: rgba(15,23,42,0.03);
    border: 1px solid rgba(148,163,184,0.14);
}
.range-card span,
.metric-label,
.metric-note,
.trend-head p,
.trend-foot,
.note-card p,
.legend,
.range-card small,
.trend-stats span {
    color: var(--muted);
}
.range-card strong {
    display: block;
    margin-top: 6px;
    font-size: 18px;
    color: var(--text);
}
.status-row {
    display: flex;
    justify-content: space-between;
    gap: 14px;
    align-items: flex-start;
    margin-top: 18px;
    flex-wrap: wrap;
}
.status-pill {
    display: inline-flex;
    align-items: center;
    padding: 8px 14px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 700;
    background: rgba(15,23,42,0.06);
}
.status-pill.good { color: var(--green); background: rgba(22,163,74,0.1); }
.status-pill.warn { color: var(--amber); background: rgba(245,158,11,0.12); }
.status-pill.neutral { color: var(--muted); }
.status-copy {
    margin: 12px 0 0;
    font-size: 18px;
    line-height: 1.45;
    max-width: 760px;
}
.metric-grid {
    grid-template-columns: repeat(4, minmax(0, 1fr));
    margin-top: 16px;
}
.metric-card {
    padding: 18px;
}
.metric-top,
.trend-head {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    align-items: flex-start;
}
.metric-label {
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}
.delta-pill {
    display: inline-flex;
    padding: 6px 10px;
    border-radius: 999px;
    background: rgba(15,23,42,0.05);
    font-size: 12px;
    font-weight: 700;
}
.delta-pill.good { color: var(--green); }
.delta-pill.warn { color: var(--amber); }
.delta-pill.neutral { color: var(--muted); }
.metric-value {
    margin-top: 14px;
    font-size: 34px;
    font-weight: 700;
    line-height: 1;
}
.metric-meta {
    display: grid;
    gap: 8px;
    margin-top: 14px;
}
.metric-meta span {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    font-size: 13px;
    color: var(--muted);
}
.metric-meta strong,
.trend-stats strong {
    color: var(--text);
}
.metric-note {
    margin-top: 12px;
    font-size: 12px;
}
.section-head {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    align-items: flex-end;
    margin: 22px 2px 0;
    flex-wrap: wrap;
}
.section-head h2 {
    margin: 0;
    font-size: 24px;
}
.legend {
    font-size: 13px;
}
.trend-grid {
    grid-template-columns: 1fr;
    margin-top: 14px;
}
.trend-card {
    padding: 18px;
}
.trend-head h3 {
    margin: 0 0 4px;
    font-size: 18px;
}
.trend-stats {
    display: grid;
    gap: 6px;
    text-align: right;
    font-size: 12px;
    white-space: nowrap;
}
.trend-svg {
    width: 100%;
    height: auto;
    margin-top: 14px;
}
.trend-axis {
    stroke: rgba(148,163,184,0.38);
    stroke-width: 1;
}
.trend-best {
    stroke: rgba(37,99,235,0.34);
    stroke-width: 1.6;
    stroke-dasharray: 6 5;
}
.trend-line {
    fill: none;
    stroke: var(--blue);
    stroke-width: 4;
    stroke-linecap: round;
    stroke-linejoin: round;
}
.trend-dot {
    fill: rgba(37,99,235,0.24);
}
.trend-dot.active {
    fill: var(--blue);
}
.trend-foot {
    display: flex;
    justify-content: space-between;
    gap: 8px;
    margin-top: 8px;
    font-size: 12px;
}
.note-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    margin-top: 16px;
}
.note-card {
    padding: 18px;
}
.note-card h3 {
    margin: 0 0 10px;
    font-size: 17px;
}
.note-card p {
    margin: 0;
    line-height: 1.6;
}
@media (max-width: 980px) {
    .metric-grid,
    .note-grid,
    .range-grid {
        grid-template-columns: 1fr 1fr;
    }
}
@media (max-width: 720px) {
    .page { width: min(100% - 18px, 1120px); }
    .metric-grid,
    .note-grid,
    .range-grid {
        grid-template-columns: 1fr;
    }
    .metric-top,
    .trend-head,
    .status-row {
        flex-direction: column;
    }
    .trend-stats {
        text-align: left;
        white-space: normal;
    }
}
</style>
</head>
<body>
<div class="page">
    <section class="hero">
        <div class="hero-top">
            <span>Exported ${escape(formatDateTime(now))}</span>
        </div>
        <h1>Progress Report</h1>
        <div class="range-grid">
            <div class="range-card">
                <small>Latest 7 days</small>
                <strong>${escape(currentRange)}</strong>
            </div>
            <div class="range-card">
                <small>Previous 7 days</small>
                <strong>${escape(previousAvailable ? previousRange : 'Need more history')}</strong>
            </div>
        </div>
        <div class="status-row">
            <div>
                <span class="status-pill ${escape(status.tone)}">${escape(status.title)}</span>
                <p class="status-copy">${escape(status.detail)}</p>
            </div>
        </div>
    </section>

    <section class="metric-grid">
        ${metrics.map(renderMetricCard).join('')}
    </section>

    <div class="section-head">
        <h2>Trend lines</h2>
        <div class="legend">Each point = one 7-day block · Dashed line = best 7-day result</div>
    </div>

    <section class="trend-grid">
        ${renderLineChart(blockSeries, 'avgSuccess', { label: 'Success trend', note: 'Higher is better', formatter: (value) => `${Math.round(value)}%`, bestValue: bestSuccess ? bestSuccess.summary.avgSuccess : null })}
        ${renderLineChart(blockSeries, 'avgFirstTrySuccess', { label: 'Clean Pass trend', note: 'Higher is better', formatter: (value) => `${Math.round(value)}%`, bestValue: bestFirstTry ? bestFirstTry.summary.avgFirstTrySuccess : null })}
        ${renderLineChart(blockSeries, 'avgMistakesPerSession', { label: 'Mistakes trend', note: 'Lower is better', formatter: (value) => String(roundTo(value, 1)), bestValue: bestMistakes ? bestMistakes.summary.avgMistakesPerSession : null })}
        ${renderLineChart(blockSeries, 'avgAltUsage', { label: 'Alt help trend', note: 'Lower is better', formatter: (value) => `${Math.round(value)}%`, bestValue: bestAlt ? bestAlt.summary.avgAltUsage : null })}
    </section>

    <section class="note-grid">
        <div class="note-card">
            <h3>Latest block activity</h3>
            <p>${escape(activityNote)}</p>
        </div>
        <div class="note-card">
            <h3>How best is calculated</h3>
            <p>Best is measured across your recorded 7-day windows: highest success, highest first try success, lowest mistakes, and lowest alt help.</p>
        </div>
    </section>
</div>
</body>
</html>`;

        const filename = `tugadi-progress-${makeDateKey(now) || 'export'}.html`;
        const blob = new Blob([reportHtml], { type: 'text/html;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 1500);

        if (typeof showTransientMessage === 'function') {
            showTransientMessage('Progress downloaded.');
        }
    }

    // HTML Generation Methods
    createMistakeItemHTML(mistake, index) {
        // Normalize words for display + internal comparisons
        const baseIncorrectWord = (mistake.incorrect || '').replace(/[.,!?]/g, '').trim();
        const baseCorrectWord = (mistake.correct || '').replace(/[.,!?]/g, '').trim();

        // Highlight spaced-repetition items (subtle accent).
        const spacedClass = mistake.spaced ? ' spaced' : '';

        const showIncorrect = baseIncorrectWord &&
            baseCorrectWord &&
            baseIncorrectWord.toLowerCase() !== baseCorrectWord.toLowerCase();

        // Target word is always what we want the user to rewrite from memory.
        const targetWord = baseCorrectWord || baseIncorrectWord || '';
        const wrongWord = baseIncorrectWord || '';

        const reviewPill = mistake.spaced
            ? '<span class="review-status" aria-label="Scheduled review">Review</span>'
            : '';

        const compareRow = showIncorrect
            ? `
                <div class="mistake-compare" aria-label="Spelling correction">
                    <span class="mistake-chip wrong" aria-label="Incorrect">${escapeHTML(wrongWord)}</span>
                    <span class="mistake-chip correct" aria-label="Correct">${escapeHTML(targetWord)}</span>
                </div>`
            : `
                <div class="mistake-compare single" aria-label="Word">
                    <span class="mistake-chip correct" aria-label="Word">${escapeHTML(targetWord)}</span>
                </div>`;

        const reviewRow = reviewPill
            ? `
                <div class="mistake-review-row">${reviewPill}</div>`
            : '';

        return `
            <div class="mistake-item${spacedClass}">
                <div class="mistake-corner-actions" aria-hidden="false">
                    <button class="icon-action-btn delete-mistake-btn history-corner-btn" data-index="${index}" aria-label="Delete mistake" title="Delete">
                        <i class="fi fi-rr-trash"></i>
                    </button>
                    <button class="icon-action-btn rewrite-btn rewrite-mistake-icon-btn history-corner-btn" data-index="${index}" type="button" aria-label="Rewrite" title="Rewrite">
                        <i class="fi fi-rr-refresh"></i>
                    </button>
                </div>

                <div class="mistake-preview">
                    ${compareRow}
                </div>
                ${reviewRow}

                <div class="rewrite-section" id="rewrite-section-${index}" style="display: none;">
                    <div class="step-indicator">
                        <span class="step active">Step 1: Copy</span>
                        <span class="step">Step 2: Reconstruct</span>
                        <span class="step">Step 3: Recall</span>
                    </div>
                    <!-- Step 1 -->
                    <div class="rewrite-step" id="step-1-${index}">
                        <div class="word-display">${escapeHTML(targetWord)}</div>
                        <input type="text"
                            class="rewrite-input"
                            id="rewrite-1-${index}"
                            placeholder="Copy the word"
                            autocomplete="off"
                            autocorrect="off"
                            autocapitalize="off"
                            spellcheck="false">
                    </div>
                    <!-- Step 2 -->
                    <div class="rewrite-step" id="step-2-${index}" style="display: none;">
                        <input type="text"
                            class="rewrite-input"
                            id="rewrite-2-${index}"
                            placeholder="Tap the letters in order"
                            autocomplete="off"
                            autocorrect="off"
                            autocapitalize="off"
                            spellcheck="false"
                            readonly>
                        <div class="letter-bank" id="letter-bank-2-${index}"></div>
                    </div>
                    <!-- Step 3 -->
                    <div class="rewrite-step" id="step-3-${index}" style="display: none;">
                        <div class="word-display" id="word-3-${index}">
                            ${'*'.repeat(targetWord.length)}
                        </div>
                        <input type="text"
                            class="rewrite-input"
                            id="rewrite-3-${index}"
                            placeholder="Type from memory"
                            autocomplete="off"
                            autocorrect="off"
                            autocapitalize="off"
                            spellcheck="false">
                    </div>
                    <div class="rewrite-feedback" id="feedback-${index}"></div>
                </div>
            </div>
        
        `;
    }

    deleteMistake(index) {
        const mistake = this.todayStats.mistakes[index];
        if (!mistake) return;
        const correctWord = (mistake.correct || '').replace(/[.,!?]/g, '').trim();
        const warning = `Delete “${correctWord || 'this item'}” from Spelling Mistakes? This cannot be undone.`;
        showConfirmation(warning, (confirmed) => {
            if (!confirmed) return;

            const preserveExistingSchedule = Boolean(mistake && mistake.preserveSchedule && !mistake.spaced);

            // Remove from today's mistakes list
            this.todayStats.mistakes.splice(index, 1);

            // Also remove from the spaced schedule if present (keeps the review queue consistent).
            if (!preserveExistingSchedule && typeof SpacedRepetitionManager !== 'undefined' && SpacedRepetitionManager && correctWord) {
                const scheduleType = mistake.type === 'wordList' ? 'wordList' : 'mistake';

                try {
                    // If this mistake came from the spaced schedule, prefer deleting by scheduleKey.
                    if (mistake.scheduleKey && SpacedRepetitionManager.schedule && SpacedRepetitionManager.schedule[mistake.scheduleKey]) {
                        delete SpacedRepetitionManager.schedule[mistake.scheduleKey];
                        if (typeof SpacedRepetitionManager.saveSchedule === 'function') {
                            SpacedRepetitionManager.saveSchedule();
                        } else {
                            try { ExtensionStorage.setItem('spacedSchedule', JSON.stringify(SpacedRepetitionManager.schedule)); } catch (e) {}
                        }
                    } else if (typeof SpacedRepetitionManager.removeWord === 'function') {
                        SpacedRepetitionManager.removeWord(correctWord, scheduleType);
                    } else if (SpacedRepetitionManager.schedule) {
                        // Fallback for legacy manager shape (pre-namespace keys)
                        const key = normalizeWordKey(correctWord);
                        delete SpacedRepetitionManager.schedule[key];
                        try { ExtensionStorage.setItem('spacedSchedule', JSON.stringify(SpacedRepetitionManager.schedule)); } catch (e) {}
                    }
                } catch (e) {
                    /* ignore */
                }
            }

            this.saveTodayStats();
            this.updateUI();
        }, { title: 'Delete mistake', confirmText: 'Delete' });
    }
    // Methods used by rewrite functionality
    startRewrite(index) {
        const mistake = this.todayStats.mistakes[index];
        if (!mistake) return;
        const rewriteSection = document.getElementById(`rewrite-section-${index}`);
        if (rewriteSection) {
            const isHidden = rewriteSection.style.display === 'none';
            if (isHidden) {
                // Show the rewrite section and reset steps and inputs
                rewriteSection.style.display = 'block';
                for (let i = 1; i <= 3; i++) {
                    const input = document.getElementById(`rewrite-${i}-${index}`);
                    if (input) {
                        input.value = '';
                        input.classList.remove('correct', 'incorrect');
                    }
                    const step = document.getElementById(`step-${i}-${index}`);
                    if (step) {
                        step.style.display = i === 1 ? 'block' : 'none';
                    }
                }
                // Reset step indicators
                const indicators = rewriteSection.querySelectorAll('.step');
                indicators.forEach((indicator, i) => {
                    indicator.classList.toggle('active', i === 0);
                    indicator.classList.remove('completed');
                });
                // While rewriting, hide the preview row and corner actions so the user focuses
                // on the steps (Copy → Reconstruct → Recall) rather than re-reading the answer.
                const item = document.querySelectorAll('.mistake-item')[index];
                if (item) {
                    const preview = item.querySelector('.mistake-preview');
                    const reviewRow = item.querySelector('.mistake-review-row');
                    const cornerActions = item.querySelector('.mistake-corner-actions');
                    if (preview) preview.style.display = 'none';
                    if (reviewRow) reviewRow.style.display = 'none';
                    if (cornerActions) cornerActions.style.display = 'none';
                    item.classList.add('rewriting');
                    this.queueMistakeActionAlignment();
                }
                // Attach a single Enter handler per field without stacking listeners
                const input1 = document.getElementById(`rewrite-1-${index}`);
                const input2 = document.getElementById(`rewrite-2-${index}`);
                const input3 = document.getElementById(`rewrite-3-${index}`);
                const attachInputHandler = (inputEl, step) => {
                    if (!inputEl) return;

                    inputEl.onkeydown = (event) => {
                        if (event.key === 'Enter') {
                            event.preventDefault();
                            if (inputEl.readOnly) {
                                return;
                            }
                            this.checkStep(index, step);
                        }
                    };
                };
                attachInputHandler(input1, 1);
                attachInputHandler(input2, 2);
                attachInputHandler(input3, 3);
                // Step 2 now uses scrambled letters that must be tapped in order.
                const correctWord = mistake.correct.replace(/[.,!?]/g, '');
                const step2Input = document.getElementById(`rewrite-2-${index}`);
                const step2Bank = document.getElementById(`letter-bank-2-${index}`);
                if (typeof setupLetterRebuild === 'function' && step2Input && step2Bank) {
                    setupLetterRebuild({
                        target: correctWord,
                        inputEl: step2Input,
                        bankEl: step2Bank,
                        instructionText: 'Tap the scrambled letters in order.',
                        onComplete: () => this.checkStep(index, 2)
                    });
                }
                // Focus the first input
                if (input1) {
                    input1.focus();
                }
            } else {
                // Hide the section if already open
                rewriteSection.style.display = 'none';
                // Restore the preview + actions when closing rewrite
                const item = document.querySelectorAll('.mistake-item')[index];
                if (item) {
                    const preview = item.querySelector('.mistake-preview');
                    const reviewRow = item.querySelector('.mistake-review-row');
                    const cornerActions = item.querySelector('.mistake-corner-actions');
                    if (preview) preview.style.display = '';
                    if (reviewRow) reviewRow.style.display = '';
                    if (cornerActions) cornerActions.style.display = '';
                    item.classList.remove('rewriting');
                    this.queueMistakeActionAlignment();
                }
            }
        }
    }
    showWord(index, step) {
        const wordDisplay = document.getElementById(`word-${step}-${index}`);
        if (wordDisplay) {
            const word = this.todayStats.mistakes[index].correct.replace(/[.,!?]/g, '');
            wordDisplay.innerHTML = `${escapeHTML(word)}<button class="show-word-btn">Show Word</button>`;
        }
    }
    hideWord(index, step) {
        const wordDisplay = document.getElementById(`word-${step}-${index}`);
        if (wordDisplay) {
            const word = this.todayStats.mistakes[index].correct.replace(/[.,!?]/g, '');
            wordDisplay.innerHTML = '*'.repeat(word.length) + 
                '<button class="show-word-btn">Show Word</button>';
        }
    }
    checkStep(index, step) {
        const mistake = this.todayStats.mistakes[index];
        if (!mistake) return;
        const correctWord = mistake.correct.replace(/[.,!?]/g, '').toLowerCase();
        const input = document.getElementById(`rewrite-${step}-${index}`);
        const userInput = input.value.trim().toLowerCase();
        if (userInput === correctWord) {
            input.classList.add('correct');
            input.classList.remove('incorrect');
            const indicators = document.querySelectorAll(`#rewrite-section-${index} .step`);
            indicators[step - 1].classList.add('completed');
            if (step < 3) indicators[step].classList.add('active');
            setTimeout(() => {
                if (step < 3) {
                    document.getElementById(`step-${step}-${index}`).style.display = 'none';
                    const nextStep = document.getElementById(`step-${step + 1}-${index}`);
                    nextStep.style.display = 'block';
                    const nextInput = document.getElementById(`rewrite-${step + 1}-${index}`);
                    if (nextInput) {
                        nextInput.focus();
                        nextInput.classList.remove('correct', 'incorrect');
                    }
                } else {
                    // The user has successfully completed the final rewrite step.
                    // Fresh mistakes only enter spaced repetition AFTER this first
                    // successful rewrite. Existing spaced-review items keep using
                    // the normal review-result progression.
                    const wordForSchedule = correctWord;
                    if (typeof SpacedRepetitionManager !== 'undefined') {
                        if (mistake.spaced) {
                            SpacedRepetitionManager.recordReviewResult(wordForSchedule, true, mistake.type);
                        } else if (!mistake.preserveSchedule) {
                            SpacedRepetitionManager.recordWord(wordForSchedule, mistake.type);
                        }
                    }
                    this.todayStats.mistakes.splice(index, 1);
                    this.saveTodayStats();
                    this.updateUI();
                }
            }, 1000);
        } else {
            // The user entered an incorrect word. Mark the input accordingly
            // and reset it. Only reset spaced repetition when this is already a
            // scheduled review; a first-time rewrite should remain an unscheduled
            // normal mistake until eventually completed.
            input.classList.add('incorrect');
            input.classList.remove('correct');
            if (mistake.spaced && typeof SpacedRepetitionManager !== 'undefined') {
                SpacedRepetitionManager.recordReviewResult(correctWord, false, mistake.type);
            }
            setTimeout(() => {
                input.classList.remove('incorrect');
                input.value = '';
                input.focus();
            }, 500);
        }
    }
    createHistoryItemHTML(session, index) {
        const sessionDate = new Date(session.date);
        const dateLabel = Number.isNaN(sessionDate.getTime())
            ? 'Unknown date'
            : sessionDate.toLocaleDateString();
        const sentenceCount = Number(session.sentences) || 0;
        const durationMinutes = Number(session.duration) || 0;
        const mistakeTotal = Number(session.mistakes) || 0;
        const successRate = Number(session.successRate) || 0;
        const firstTrySuccessRate = Math.max(0, Math.min(100, Number(session.firstTrySuccessRate ?? session.successRate) || 0));
        const altUsageRate = Math.max(0, Math.min(100, Number(session.altUsageRate) || 0));
        const altUsageCount = Math.max(0, Number(session.altUsageCount) || 0);

        const mistakesTone = mistakeTotal === 0 ? 'good' : 'bad';
        const successTone = successRate >= 80 ? 'good' : successRate >= 50 ? 'warn' : 'bad';
        const altTone = altUsageRate === 0 ? 'good' : altUsageRate <= 35 ? 'warn' : 'bad';

        return `
            <div class="history-item">
                <button class="icon-action-btn delete-history-item-btn history-corner-btn" data-index="${index}" aria-label="Delete history item" title="Delete">
                    <i class="fi fi-rr-trash"></i>
                </button>

                <div class="history-title">
                    <div class="history-date">${escapeHTML(dateLabel)}</div>
                    <div class="history-meta">Practice summary</div>
                </div>

                <div class="history-stats">
                    <div class="history-stat">
                        <span class="history-stat-label">Sentences</span>
                        <span class="history-stat-value">${sentenceCount}</span>
                    </div>
                    <div class="history-stat">
                        <span class="history-stat-label">Time</span>
                        <span class="history-stat-value">${this.formatTime(durationMinutes)}</span>
                    </div>
                    <div class="history-stat ${mistakesTone}">
                        <span class="history-stat-label">Mistakes</span>
                        <span class="history-stat-value">${mistakeTotal}</span>
                    </div>
                    <div class="history-stat ${successTone}" title="Success blends first-try accuracy, retries, and Alt help. Clean Pass: ${firstTrySuccessRate}%">
                        <span class="history-stat-label">Success</span>
                        <span class="history-stat-value">${successRate}%</span>
                    </div>
                    <div class="history-stat ${firstTrySuccessRate >= 80 ? 'good' : firstTrySuccessRate >= 50 ? 'warn' : 'bad'}">
                        <span class="history-stat-label">Clean Pass</span>
                        <span class="history-stat-value">${firstTrySuccessRate}%</span>
                    </div>
                    <div class="history-stat ${altTone}" title="Alt was used on ${altUsageCount} of ${sentenceCount} sentence${sentenceCount === 1 ? '' : 's'}">
                        <span class="history-stat-label">Alt help</span>
                        <span class="history-stat-value">${altUsageRate}%</span>
                    </div>
                </div>
            </div>
        `;
    }
    // Utility Methods
    formatTime(minutes) {
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return `${hours}h ${mins}m`;
    }
    // Practice Session Management
    startPracticeSession() {
        this.startTimer();
        this.updateStreak();
        this.currentSessionMistakes = 0;
        this.currentSessionAltSentences = {};
        this.currentSessionAltPeeks = 0;
        this.todayStats.sentences = 0;
        this.todayStats.completedSentences = 0;
        this.todayStats.firstTrySuccesses = 0;
        this.saveTodayStats();
        this.saveStats();
        this.saveSessionTime();
        this.updateUI();
    }
    endPracticeSession(completedSentenceCount) {
        this.stopTimer();
        this.updateStreak();
        this.stats.totalPractices++;
        const sentenceTotal = Number(completedSentenceCount) || 0;
        const completedSentences = Math.max(0, Number(this.todayStats.completedSentences ?? this.todayStats.sentences) || 0);
        const firstTrySuccesses = Math.max(0, Number(this.todayStats.firstTrySuccesses) || 0);
        const firstTrySuccessRate = this.computeFirstTrySuccessRate(completedSentences, firstTrySuccesses);
        const altUsageCount = Object.keys(this.currentSessionAltSentences || {}).length;
        const altUsageRate = completedSentences > 0
            ? Math.round((altUsageCount / completedSentences) * 100)
            : 0;
        const successRate = this.computeSessionSuccessRate({
            completedSentences,
            mistakes: this.currentSessionMistakes,
            altUsageRate,
            firstTrySuccessRate
        });
        const sessionDayKey = this.getLocalDayKey();
        this.stats.practiceHistory.unshift({
            date: new Date().toISOString(),
            dayKey: sessionDayKey,
            sentences: sentenceTotal,
            completedSentences,
            firstTrySuccesses,
            duration: this.todayStats.practiceTime,
            mistakes: this.currentSessionMistakes,
            successRate,
            firstTrySuccessRate,
            altUsageCount,
            altUsageRate
        });
        this.currentSessionAltSentences = {};
        this.currentSessionAltPeeks = 0;
        this.saveStats();
        this.updateUI();
    }
    // Streak Management
    updateStreak() {
        const now = new Date();
        const todayKey = this.getLocalDayKey(now);
        if (!todayKey) {
            return false;
        }

        this.stats = this.repairStatsForConsistency(this.stats);

        const lastPracticeKey = this.normalizeStoredDayKey(this.stats.lastPracticeDateKey || this.stats.lastPracticeDate)
            || this.getLatestActivityDayKey(this.stats)
            || this.getLatestPracticeDayKeyFromHistory();
        const basePracticeDays = this.getResolvedPracticeDayCount(this.stats);

        if (lastPracticeKey) {
            const daysDiff = this.getDayDifference(lastPracticeKey, todayKey);
            if (daysDiff === 0) {
                return false;
            }
        }

        const nextPracticeDays = Math.max(1, basePracticeDays + 1);
        this.stats.practiceDays = nextPracticeDays;
        this.stats.streak = nextPracticeDays;
        this.stats.lastPracticeDateKey = todayKey;
        this.stats.lastPracticeDate = now.toISOString();
        this.saveStats();
        this.updateUI();
        return true;
    }
// Mistake Management

    recordMistake(incorrect, correct, options = {}) {
        const cleanCorrect = normalizeWordKey(correct);
        const cleanIncorrect = normalizeWordKey(incorrect);
        const skipReviewEntry = Boolean(options && options.skipReviewEntry);
        const hasAnyContent = Boolean(String(incorrect ?? '').trim() || String(correct ?? '').trim());
        if (!hasAnyContent) {
            return;
        }

        const existingScheduleEntry = (!skipReviewEntry && cleanCorrect && typeof SpacedRepetitionManager !== 'undefined' && SpacedRepetitionManager && typeof SpacedRepetitionManager.getEntry === 'function')
            ? SpacedRepetitionManager.getEntry(cleanCorrect, 'mistake')
            : null;

        const existingMistake = !skipReviewEntry
            ? this.todayStats.mistakes.find((mistake) => {
                return normalizeWordKey(mistake.correct) === cleanCorrect && mistake.type !== 'wordList';
            })
            : null;

        // Count every failed attempt in the session mistake total, but do not
        // distort the first-try success denominator for the history summary.
        this.currentSessionMistakes++;

        if (!skipReviewEntry && existingMistake && existingScheduleEntry && !existingMistake.spaced) {
            existingMistake.preserveSchedule = true;
        }

        if (!skipReviewEntry && !existingMistake) {
            const mistake = {
                incorrect,
                correct,
                type: 'mistake',
                timestamp: new Date().toISOString(),
                preserveSchedule: Boolean(existingScheduleEntry)
            };
            this.todayStats.mistakes.unshift(mistake);
        }

        this.saveTodayStats();
        this.updateUI();
    }
    recordAltUsage(sentenceIndex) {
        if (!Number.isInteger(sentenceIndex) || sentenceIndex < 0) {
            return;
        }

        if (!this.currentSessionAltSentences || typeof this.currentSessionAltSentences !== 'object') {
            this.currentSessionAltSentences = {};
        }

        this.currentSessionAltPeeks = (Number(this.currentSessionAltPeeks) || 0) + 1;

        if (!this.currentSessionAltSentences[sentenceIndex]) {
            this.currentSessionAltSentences[sentenceIndex] = true;
        }

        this.saveSessionTime();
    }
    recordSentenceCompletion(firstTry = false) {
        const completedSentences = Math.max(0, Number(this.todayStats.completedSentences ?? this.todayStats.sentences) || 0) + 1;
        this.todayStats.completedSentences = completedSentences;
        this.todayStats.sentences = completedSentences;
        if (firstTry) {
            this.todayStats.firstTrySuccesses = Math.max(0, Number(this.todayStats.firstTrySuccesses) || 0) + 1;
        }
        this.saveTodayStats();
        this.updateUI();
    }
    recordFirstTrySuccess() {
        this.recordSentenceCompletion(true);
    }
    clearPracticeHistory() {
        showConfirmation('Delete all practice history? This action cannot be undone.', (confirmed) => {
            if (!confirmed) return;
            this.stats.practiceHistory = [];
            this.saveStats();
            this.updateUI();
        });
    }

    deleteHistoryItem(index) {
        const session = this.stats.practiceHistory && this.stats.practiceHistory[index];
        if (!session) return;
        showConfirmation('Delete this practice history entry? This action cannot be undone.', (confirmed) => {
            if (!confirmed) return;
            this.stats.practiceHistory.splice(index, 1);
            this.saveStats();
            this.updateUI();
        }, { title: 'Delete entry', confirmText: 'Delete' });
    }
    resetDailyStats() {
        this.stopTimer();
        this.currentSessionMistakes = 0;
        this.currentSessionAltSentences = {};
        this.currentSessionAltPeeks = 0;
        this.todayStats.sentences = 0;
        this.todayStats.completedSentences = 0;
        this.todayStats.firstTrySuccesses = 0;
        this.todayStats.practiceTime = 0;
        this.sessionStartTime = null;
        this.lastSavedTime = 0;
        ExtensionStorage.removeItem('activeSession');
        this.saveTodayStats();
        this.updateUI();
    }

    /**
     * Reset only the session‑level statistics without affecting the daily
     * practice time or mistakes.  When the user restarts a practice
     * session, we want to clear any in‑session counters (such as the
     * number of sentences completed, first‑try successes and the
     * currentSessionMistakes count) but keep the accumulated practice
     * minutes and the list of mistakes for the day.  This method stops
     * any running timer, clears the session counters and removes the
     * activeSession flag from ExtensionStorage.  It then persists the
     * updated todayStats and refreshes the UI.  It does not reset the
     * practiceTime or the mistakes array.
     */
    resetSessionStats() {
        // Stop the timer if it's running so we don't accumulate further
        // practice minutes while the user is restarting the session.
        this.stopTimer();
        // Clear the current session counters
        this.currentSessionMistakes = 0;
        this.todayStats.sentences = 0;
        this.todayStats.completedSentences = 0;
        this.todayStats.firstTrySuccesses = 0;
        // Do not reset todayStats.practiceTime or todayStats.mistakes here
        // because those values represent the accumulated practice minutes
        // and mistake records for the entire day.
        // Clear session tracking variables
        this.sessionStartTime = null;
        this.lastSavedTime = 0;
        try {
            ExtensionStorage.removeItem('activeSession');
        } catch (e) {
            /* ignore */
        }
        // Persist the modified todayStats
        this.saveTodayStats();
        // Refresh the UI to reflect the cleared counters
        this.updateUI();
    }

    /**
     * Shuffle an array in place using Fisher‑Yates algorithm. This helper is
     * used to mix old and new practice items so that learners encounter
     * spelling mistakes and vocabulary words in an interleaved order. Without
     * shuffling, recently added items would always appear at the start of the
     * list which defeats the purpose of interleaving practice.
     *
     * @param {Array} array - The array to shuffle.
     * @returns {Array} The shuffled array.
     */
    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    /**
     * Inject any words that are due for review from the spaced repetition
     * schedule into today’s mistakes list. Each due word appears as both
     * the incorrect and correct field so that the user rewrites it
     * correctly. After injection, the list is shuffled to mix these
     * scheduled reviews with freshly recorded mistakes, implementing
     * interleaved practice. Duplicate entries are skipped to avoid
     * redundancy.
     */
    injectDueWords() {
        // Pull due words from the spaced repetition schedule into today's
        // practice list. Only consider items of type 'mistake' here so
        // vocabulary words (type 'wordList') remain in the Word List.
        if (typeof SpacedRepetitionManager === 'undefined') return;

        // A fresh spelling mistake should not become a spaced-review item until
        // the user has completed the first rewrite successfully.
        const pendingInitialMistakes = this.getPendingInitialMistakes({ includeToday: true });
        const pendingInitialWords = new Set();
        const preserveScheduledWords = new Set();
        pendingInitialMistakes.forEach((mistake) => {
            const key = normalizeWordKey((mistake && (mistake.correct || mistake.incorrect)) || '');
            if (!key) return;
            pendingInitialWords.add(key);
            if (mistake && mistake.preserveSchedule) {
                preserveScheduledWords.add(key);
            }
        });

        // Filter out vocabulary items so they are not injected into the mistakes list
        const dueWords = SpacedRepetitionManager.getDueWords().filter(item => {
            if (!item || item.type === 'wordList') return false;
            const key = normalizeWordKey(item.word || '');
            if (!key) return false;
            if (pendingInitialWords.has(key)) {
                // Cleanup stale schedule entries created by older builds, but keep
                // legitimate existing schedules when the user made the same mistake again.
                if (!preserveScheduledWords.has(key) && typeof SpacedRepetitionManager.removeWord === 'function') {
                    SpacedRepetitionManager.removeWord(key, 'mistake');
                }
                return false;
            }
            return true;
        });
        if (!dueWords || dueWords.length === 0) return;
        let added = false;
        dueWords.forEach(item => {
            const wordLower = String(item.word || '').toLowerCase();
            if (!wordLower) return;

            // If the word already exists in today's mistakes (fresh mistake from
            // today), don't skip it — mark it as spaced so the user still sees
            // it's due for review.
            const existing = (this.todayStats.mistakes || []).find(m => {
                if (!m || !m.correct) return false;
                const existingWord = m.correct.replace(/[.,!?]/g, '').toLowerCase();
                const existingType = m.type === 'wordList' ? 'wordList' : 'mistake';
                const dueType = item.type === 'wordList' ? 'wordList' : 'mistake';
                return existingWord === wordLower && existingType === dueType;
            });

            if (existing) {
                const wasSpaced = Boolean(existing.spaced);
                existing.spaced = true;
                existing.scheduleKey = item.scheduleKey || existing.scheduleKey || null;
                existing.stage = Number(item.stage) || existing.stage || 0;
                // Preserve any existing type, but ensure it stays "mistake" for
                // spelling-mistake reviews.
                existing.type = existing.type || item.type || 'mistake';
                if (!wasSpaced) added = true;
                return;
            }

            const entry = {
                incorrect: item.word,
                correct: item.word,
                type: item.type || 'mistake',
                timestamp: new Date().toISOString(),
                spaced: true,
                scheduleKey: item.scheduleKey || null,
                stage: Number(item.stage) || 0
            };
            this.todayStats.mistakes.unshift(entry);
            added = true;
        });
        if (added) {
            // Shuffle the list to interleave due words with existing mistakes
            this.todayStats.mistakes = this.shuffleArray(this.todayStats.mistakes);
            this.saveTodayStats();
        }
    }

    /**
     * Immediately schedule a word from the user’s personal word list for
     * practice. This method records the word in the spaced repetition
     * schedule (if not already present) and then injects it into the current
     * mistake list so it appears in the rewriting queue. The list is
     * shuffled afterwards to maintain interleaved practice. This method is
     * intended to be called when the user clicks the “Add to Word List”
     * button in the custom context menu.
     *
     * @param {string} word - The word to schedule and practice.
     */
    addPracticeWordFromList(word) {
        if (!word) return;
        const clean = word.replace(/[.,!?]/g, '').toLowerCase();
        if (typeof SpacedRepetitionManager !== 'undefined') {
            SpacedRepetitionManager.recordWord(clean, 'wordList');
        }
        // Avoid adding duplicates to the mistake list
        const exists = (this.todayStats.mistakes || []).some(m => {
            const existingType = m && m.type === 'wordList' ? 'wordList' : 'mistake';
            return m && m.correct && m.correct.replace(/[.,!?]/g, '').toLowerCase() === clean && existingType === 'wordList';
        });
        if (!exists) {
            const entry = {
                incorrect: word,
                correct: word,
                type: 'wordList',
                timestamp: new Date().toISOString(),
                spaced: true
            };
            this.todayStats.mistakes.unshift(entry);
            // Shuffle to mix with other mistakes
            this.todayStats.mistakes = this.shuffleArray(this.todayStats.mistakes);
            this.saveTodayStats();
            this.updateUI();
        }
    }

    /**
     * Schedule a word from the mistake spaced repetition schedule for immediate practice.
     * This method ensures the word has a spaced schedule entry (with type 'mistake')
     * and then injects it into today's mistake list marked as spaced. It is used
     * when the user clicks the “Practice” button next to a scheduled review.
     *
     * @param {string} word - The lowercase form of the word to practice.
     */
    addPracticeWordFromSchedule(word) {
        if (!word) return;
        const clean = word.replace(/[.,!?]/g, '').toLowerCase();
        // Ensure the word exists in the spaced schedule with type 'mistake'
        if (typeof SpacedRepetitionManager !== 'undefined') {
            SpacedRepetitionManager.recordWord(clean, 'mistake');
        }
        // Avoid duplicates in today's list
        const exists = (this.todayStats.mistakes || []).some(m => {
            const existingType = m && m.type === 'wordList' ? 'wordList' : 'mistake';
            return m && m.correct && m.correct.replace(/[.,!?]/g, '').toLowerCase() === clean && existingType === 'mistake';
        });
        if (!exists) {
            const entry = {
                incorrect: word,
                correct: word,
                type: 'mistake',
                timestamp: new Date().toISOString(),
                spaced: true
            };
            this.todayStats.mistakes.unshift(entry);
            // Shuffle to interleave with other mistakes
            this.todayStats.mistakes = this.shuffleArray(this.todayStats.mistakes);
            this.saveTodayStats();
            this.updateUI();
        }
    }
}

// Initialize statistics manager and make it globally available
// -----------------------------------------------------------------------------
// SpacedRepetitionManager
//
// This lightweight manager maintains a spaced‑repetition schedule for
// individual words. Each entry in the schedule records the current
// interval stage and a timestamp (in milliseconds) for when the next review
// is due. When a word is recorded (either from a spelling mistake or when
// added via the context menu), it is scheduled for immediate review. After
// each successful rewrite during practice, the interval is increased,
// progressing through a series of expanding delays (1, 3, 7, 14, 30 days).
// Conversely, a failed attempt resets the interval to the shortest delay.
// The schedule is persisted in ExtensionStorage under the key
// 'spacedSchedule'. This manager is global so that other modules can
// interact with it directly.
const SpacedRepetitionManager = {
    schedule: {},

    /**
     * Build a namespaced schedule key so the same word can exist independently
     * in both the Word List and Spelling Mistakes schedules.
     *
     * @param {string} word
     * @param {string} type - 'wordList' | 'mistake'
     * @returns {string}
     */
    makeKey(word, type) {
        const base = normalizeWordKey(word);
        const t = type === 'wordList' ? 'wordList' : 'mistake';
        return `${t}:${base}`;
    },

    /**
     * Parse a namespaced schedule key back into { type, word }.
     *
     * @param {string} scheduleKey
     * @param {object} entry
     * @returns {{type:string, word:string}}
     */
    parseKey(scheduleKey, entry) {
        const raw = String(scheduleKey || '');
        if (raw.includes(':')) {
            const [prefix, ...rest] = raw.split(':');
            const base = rest.join(':');
            const inferred = prefix === 'wordList' ? 'wordList' : 'mistake';
            return { type: (entry && entry.type) ? entry.type : inferred, word: base };
        }
        // Legacy (pre-namespace) key
        const legacyType = entry && entry.type === 'wordList' ? 'wordList' : 'mistake';
        return { type: legacyType, word: raw };
    },

    // Load the schedule from ExtensionStorage (with migration for old formats)
    loadSchedule() {
        let saved = {};
        try {
            saved = getStoredJSON('spacedSchedule', null) || {};
        } catch (e) {
            saved = {};
        }

        const migrated = {};
        let changed = false;

        for (const key in (saved || {})) {
            if (!Object.prototype.hasOwnProperty.call(saved, key)) continue;
            const entry = saved[key];
            if (!entry) continue;

            if (String(key).includes(':')) {
                // Already namespaced; ensure entry.type matches the namespace
                const parsed = this.parseKey(key, entry);
                const scheduleKey = this.makeKey(parsed.word, parsed.type);
                const nextEntry = { ...entry, type: parsed.type };

                if (parsed.type === 'wordList' && nextEntry.mastered) {
                    nextEntry.stage = Math.max(4, Number(nextEntry.stage) || 0);
                    nextEntry.nextDue = Number.MAX_SAFE_INTEGER;
                    changed = true;
                }

                if (parsed.type === 'mistake' && nextEntry.mastered) {
                    delete migrated[scheduleKey];
                    changed = true;
                    continue;
                }

                migrated[scheduleKey] = nextEntry;
                if (scheduleKey !== key || entry.type !== parsed.type) changed = true;
            } else {
                // Legacy key: use entry.type to namespace, default to 'mistake'
                const legacyType = entry.type === 'wordList' ? 'wordList' : 'mistake';
                const scheduleKey = this.makeKey(key, legacyType);
                const nextEntry = { ...entry, type: legacyType };

                if (legacyType === 'wordList' && nextEntry.mastered) {
                    nextEntry.stage = Math.max(4, Number(nextEntry.stage) || 0);
                    nextEntry.nextDue = Number.MAX_SAFE_INTEGER;
                }

                if (legacyType === 'mistake' && nextEntry.mastered) {
                    changed = true;
                    continue;
                }

                migrated[scheduleKey] = nextEntry;
                changed = true;
            }
        }

        this.schedule = migrated;

        // Persist migration so we don't keep re-migrating on every load
        if (changed) {
            this.saveSchedule();
        }
    },

    // Save the schedule back to ExtensionStorage
    saveSchedule() {
        try {
            ExtensionStorage.setItem('spacedSchedule', JSON.stringify(this.schedule));
        } catch (e) {
            // ignore storage errors silently
        }
    },

    cleanupMasteredWordListReviews() {
        const mgr = window.statisticsManager;
        if (!mgr || !mgr.todayStats || !Array.isArray(mgr.todayStats.mistakes)) {
            return false;
        }

        const nextMistakes = mgr.todayStats.mistakes.filter((item) => {
            if (!item || item.type !== 'wordList') {
                return true;
            }

            const word = normalizeWordKey(item.correct || item.incorrect || '');
            if (!word) {
                return false;
            }

            const entry = this.getEntry(word, 'wordList');
            return !(entry && entry.mastered);
        });

        if (nextMistakes.length === mgr.todayStats.mistakes.length) {
            return false;
        }

        mgr.todayStats.mistakes = nextMistakes;
        if (typeof mgr.saveTodayStats === 'function') {
            mgr.saveTodayStats();
        }
        return true;
    },

    /**
     * Get a schedule entry by word + type.
     */
    getEntry(word, type) {
        const key = this.makeKey(word, type);
        return this.schedule[key] || null;
    },

    /**
     * Record a word into the spaced repetition schedule.
     *
     * @param {string} word
     * @param {string} type - 'mistake' | 'wordList'
     */
    recordWord(word, type) {
        if (!word) return;
        const t = type === 'wordList' ? 'wordList' : 'mistake';
        const key = this.makeKey(word, t);
        const now = Date.now();

        if (!this.schedule[key]) {
            const firstReviewDate = new Date();
            firstReviewDate.setDate(firstReviewDate.getDate() + 1);
            this.schedule[key] = {
                stage: 0,
                nextDue: firstReviewDate.getTime(),
                type: t,
                lastReviewed: new Date().toISOString(),
                mastered: false
            };
        } else {
            if (this.schedule[key].type !== t) {
                this.schedule[key].type = t;
            }
            if (this.schedule[key].nextDue < now) {
                this.schedule[key].nextDue = now;
            }
        }

        this.saveSchedule();
    },

    /**
     * Update a word in the schedule after a review attempt.
     *
     * @param {string} word
     * @param {boolean} success
     * @param {string} type - 'mistake' | 'wordList'
     */
    recordReviewResult(word, success, type) {
        if (!word) return;
        const t = type === 'wordList' ? 'wordList' : 'mistake';
        const key = this.makeKey(word, t);

        if (!this.schedule[key]) {
            this.recordWord(word, t);
        }

        const entry = this.schedule[key];
        if (!entry) return;

        if (t === 'wordList' && entry.mastered) {
            this.cleanupMasteredWordListReviews();
            return;
        }

        const intervals = [1, 3, 7, 14, 30];
        const lastStage = intervals.length - 1;
        const prevStage = Number(entry.stage) || 0;

        // Finish rule: after the 30-day review
        if (success && prevStage >= lastStage) {
            if (t === 'wordList') {
                this.schedule[key] = {
                    ...entry,
                    stage: lastStage,
                    mastered: true,
                    nextDue: Number.MAX_SAFE_INTEGER,
                    lastReviewed: new Date().toISOString()
                };
            } else {
                delete this.schedule[key];

                // Also remove from the visible Spelling Mistakes list (if present)
                try {
                    const mgr = window.statisticsManager;
                    if (mgr && mgr.todayStats && Array.isArray(mgr.todayStats.mistakes)) {
                        const target = normalizeWordKey(word);
                        mgr.todayStats.mistakes = mgr.todayStats.mistakes.filter((m) => {
                            const correct = normalizeWordKey(m && m.correct ? String(m.correct) : '');
                            const itemType = m && m.type === 'wordList' ? 'wordList' : 'mistake';
                            return !(correct === target && itemType === 'mistake');
                        });
                        mgr.saveTodayStats && mgr.saveTodayStats();
                    }
                } catch (e) {
                    /* ignore */
                }
            }

            this.saveSchedule();
            this.cleanupMasteredWordListReviews();
            return;
        }

        let stage = prevStage;
        if (success) {
            stage = Math.min(prevStage + 1, lastStage);
        } else {
            stage = 0;
        }

        const nextDate = new Date();
        nextDate.setDate(nextDate.getDate() + intervals[stage]);

        this.schedule[key] = {
            ...entry,
            stage,
            mastered: Boolean(entry.mastered) || false,
            nextDue: nextDate.getTime(),
            lastReviewed: new Date().toISOString()
        };

        this.saveSchedule();
    },

    /**
     * Retrieve all words whose nextDue timestamp is <= now.
     * @returns {Array<{word:string, type:string, scheduleKey:string, stage:number}>}
     */
    getDueWords() {
        const now = Date.now();
        const due = [];
        for (const scheduleKey in this.schedule) {
            if (!Object.prototype.hasOwnProperty.call(this.schedule, scheduleKey)) continue;
            const entry = this.schedule[scheduleKey];
            if (!entry || entry.mastered) continue;
            if (Number(entry.nextDue) <= now) {
                const parsed = this.parseKey(scheduleKey, entry);
                due.push({
                    word: parsed.word,
                    type: parsed.type,
                    scheduleKey,
                    stage: Number(entry.stage) || 0
                });
            }
        }
        return due;
    },

    /**
     * Remove any word-list schedule entries that no longer exist in the stored word list.
     */
    pruneWordListEntries(validWords = new Set()) {
        const validSet = validWords instanceof Set ? validWords : new Set();
        let changed = false;

        for (const scheduleKey in this.schedule) {
            if (!Object.prototype.hasOwnProperty.call(this.schedule, scheduleKey)) continue;
            const entry = this.schedule[scheduleKey];
            const parsed = this.parseKey(scheduleKey, entry);
            if (parsed.type === 'wordList' && !validSet.has(parsed.word)) {
                delete this.schedule[scheduleKey];
                changed = true;
            }
        }

        if (changed) this.saveSchedule();
        return changed;
    },

    /**
     * Remove a word from the schedule. If a type is provided, only remove that schedule.
     * If no type is provided, remove BOTH schedules for that word.
     */
    removeWord(word, type) {
        if (!word) return;
        const base = normalizeWordKey(word);

        if (type) {
            const key = this.makeKey(base, type);
            delete this.schedule[key];
        } else {
            delete this.schedule[this.makeKey(base, 'wordList')];
            delete this.schedule[this.makeKey(base, 'mistake')];
        }

        this.saveSchedule();
        this.cleanupMasteredWordListReviews();
    }
};

// Make the manager globally accessible so other functions can refer to it
window.SpacedRepetitionManager = SpacedRepetitionManager;

let statisticsManager = null;
window.statisticsManager = null;
if (statsApp.setService) {
    statsApp.setService('statisticsManager', null);
}

// Optional: Add window unload listener to save state when closing
window.addEventListener('beforeunload', () => {
    try {
        const manager = statisticsManager || window.statisticsManager;
        if (!manager || !manager.sessionStartTime) {
            return;
        }

        const elapsedMinutes = Math.floor((Date.now() - manager.sessionStartTime) / 60000);
        manager.todayStats.practiceTime = manager.lastSavedTime + elapsedMinutes;
        manager.saveTodayStats();
        manager.saveSessionTime();
    } catch (error) {
        console.error('Error saving statistics state:', error);
    }
});

function highlightSpellingMistakesFocus(options = {}) {
    const { highlightReview = false } = options || {};
    const dashboard = document.getElementById('statistics-dashboard');
    const mistakesList = document.getElementById('recent-mistakes');
    const section = mistakesList ? mistakesList.closest('.dashboard-section') : null;

    if (!dashboard || !section) {
        return;
    }

    section.classList.remove('review-focus-section');
    const highlightedItems = dashboard.querySelectorAll('.review-focus-item');
    highlightedItems.forEach((item) => item.classList.remove('review-focus-item'));

    requestAnimationFrame(() => {
        section.classList.add('review-focus-section');
        try {
            section.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
        } catch (error) {
            section.scrollIntoView(true);
        }

        if (highlightReview) {
            const reviewItems = mistakesList.querySelectorAll('.mistake-item.spaced');
            reviewItems.forEach((item) => item.classList.add('review-focus-item'));
        }

        window.clearTimeout(window.__tugadiReviewFocusTimer);
        window.__tugadiReviewFocusTimer = window.setTimeout(() => {
            section.classList.remove('review-focus-section');
            const activeItems = dashboard.querySelectorAll('.review-focus-item');
            activeItems.forEach((item) => item.classList.remove('review-focus-item'));
        }, 2600);
    });
}

// Function to open the statistics panel focused on mistakes
function openMistakesPanel(options = {}) {
    const dashboard = document.getElementById('statistics-dashboard');
    const statsBtn = document.getElementById('stats-dashboard-btn');
    const { focusSection = 'mistakes', highlightReview = false } = options || {};

    if (dashboard && statsBtn) {
        dashboard.style.display = 'block';
        requestAnimationFrame(() => {
            dashboard.classList.add('open');
            statsBtn.classList.add('active');
            if (window.statisticsManager) {
                window.statisticsManager.updateUI();
            }
            if (focusSection === 'mistakes') {
                setTimeout(() => {
                    highlightSpellingMistakesFocus({ highlightReview });
                }, 80);
            }
        });
    }
}

statsApp.setService && statsApp.setService('spacedRepetitionManager', SpacedRepetitionManager);
statsApp.modules.stats = {
    initializeStatisticsDashboardUI,
    resetAllData,
    clearMistakesAndReviews,
    resetStatisticsOnly,
    clearIndividualStat,
    StatisticsManager,
    SpacedRepetitionManager,
    openMistakesPanel
};
