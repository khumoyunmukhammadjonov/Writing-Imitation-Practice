(function () {
    const BACKUP_KEYS = [
        'activeSession',
        'lastStatsReset',
        'practiceStats',
        'spacedSchedule',
        'textControls',
        'theme',
        'todayStats',
        'wordList',
        'writingProgress'
    ];

    // Fixed schedule: manual rating buttons removed (1-3-7-14-30 days).


    const featureState = {
        wordList: {
            search: '',
            // One control instead of separate Filter + Sort.
            // Values encode a "view" preset (filter + ordering).
            view: 'all'
        }
    };

    function getManager() {
        return window.statisticsManager || null;
    }

    function getSpacedManager() {
        return window.SpacedRepetitionManager || null;
    }

    function getPracticeStateSafe() {
        const app = window.WritingImitationPractice;
        if (!app || !app.state) {
            return {};
        }
        app.state.practice = app.state.practice || {};
        return app.state.practice;
    }

    function coerceArray(value) {
        return Array.isArray(value) ? value : [];
    }

    function trimLog(list, limit) {
        const arr = coerceArray(list);
        if (arr.length <= limit) {
            return arr;
        }
        return arr.slice(arr.length - limit);
    }

    function ensureStatsShape(manager) {
        if (!manager || !manager.stats) {
            return;
        }

        manager.stats.attemptLog = trimLog(manager.stats.attemptLog, 1000);
        manager.stats.hintHistory = trimLog(manager.stats.hintHistory, 500);
        manager.stats.reviewChoices = trimLog(manager.stats.reviewChoices, 500);
        manager.stats.uiState = manager.stats.uiState && typeof manager.stats.uiState === 'object'
            ? manager.stats.uiState
            : {};

        if (typeof manager.stats.uiState.onboardingDismissed !== 'boolean') {
            manager.stats.uiState.onboardingDismissed = false;
        }
    }

    function persistStats(manager) {
        if (!manager) return;
        ensureStatsShape(manager);
        if (typeof manager.saveStats === 'function') {
            manager.saveStats();
        }
    }

    function parseMaybeJSON(raw) {
        if (typeof raw !== 'string') {
            return raw;
        }

        try {
            return JSON.parse(raw);
        } catch (error) {
            return raw;
        }
    }

    function toRawStorageValue(value) {
        return typeof value === 'string' ? value : JSON.stringify(value);
    }

    function getLatestHistoryDayKey(history, getDayKey) {
        const list = Array.isArray(history) ? history : [];
        let latestKey = null;

        list.forEach((entry) => {
            const key = typeof getDayKey === 'function'
                ? getDayKey(entry)
                : null;
            if (!key) return;
            if (!latestKey || key > latestKey) {
                latestKey = key;
            }
        });

        return latestKey;
    }

    function normalizeImportedRecords(records) {
        const nextRecords = records && typeof records === 'object' ? { ...records } : {};
        const stats = nextRecords.practiceStats && typeof nextRecords.practiceStats === 'object'
            ? { ...nextRecords.practiceStats }
            : null;

        const manager = getManager();
        const normalizeDayKey = manager && typeof manager.normalizeStoredDayKey === 'function'
            ? manager.normalizeStoredDayKey.bind(manager)
            : (value) => {
                if (!value) return null;
                const parsed = new Date(value);
                if (Number.isNaN(parsed.getTime())) return null;
                const year = parsed.getFullYear();
                const month = String(parsed.getMonth() + 1).padStart(2, '0');
                const day = String(parsed.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            };

        if (stats) {
            stats.practiceHistory = coerceArray(stats.practiceHistory)
                .filter((session) => session && typeof session === 'object')
                .map((session) => {
                    const dayKey = normalizeDayKey(session.dayKey || session.dateKey || session.date);
                    return dayKey ? { ...session, dayKey } : { ...session };
                });

            stats.attemptLog = coerceArray(stats.attemptLog)
                .filter((entry) => entry && typeof entry === 'object')
                .map((entry) => {
                    const dayKey = normalizeDayKey(entry.dayKey || entry.dateKey || entry.timestamp || entry.date);
                    return dayKey ? { ...entry, dayKey } : { ...entry };
                });

            const historyKey = getLatestHistoryDayKey(stats.practiceHistory, (entry) => normalizeDayKey(entry && (entry.dayKey || entry.date)));
            const attemptKey = getLatestHistoryDayKey(stats.attemptLog, (entry) => normalizeDayKey(entry && (entry.dayKey || entry.timestamp || entry.date)));
            const storedKey = normalizeDayKey(stats.lastPracticeDateKey || stats.lastPracticeDate);
            const finalKey = [storedKey, historyKey, attemptKey].filter(Boolean).sort().pop() || null;

            if (finalKey) {
                stats.lastPracticeDateKey = finalKey;
                stats.lastPracticeDate = `${finalKey}T12:00:00.000Z`;
            }

            stats.importedAt = new Date().toISOString();
            stats.importedStreak = Number.isFinite(Number(stats.streak)) ? Number(stats.streak) : 0;
            nextRecords.practiceStats = stats;
        }

        return nextRecords;
    }

    function injectStorageButtons() {
        const container = document.querySelector('.storage-buttons');
        if (!container || container.querySelector('[data-v21-storage-tools]')) {
            return;
        }

        const wrap = document.createElement('div');
        wrap.className = 'storage-buttons v21-storage-tools';
        wrap.dataset.v21StorageTools = '1';
        wrap.innerHTML = `
            <button id="export-backup-btn" class="storage-btn secondary-action" type="button">
                <span class="btn-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 3v10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        <path d="M8 11l4 4 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M4 17v3h16v-3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span> Export Backup
            </button>
            <button id="import-backup-btn" class="storage-btn secondary-action" type="button">
                <span class="btn-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 21V11" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        <path d="M8 13l4-4 4 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M4 7V4h16v3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span> Import Backup
            </button>
            <input id="import-backup-input" type="file" accept="application/json" hidden>
        `;

        // Insert backup tools ABOVE the destructive reset action.
        // This keeps the primary "Reset All Data" button visually separated.
        container.parentNode.insertBefore(wrap, container);

        const exportBtn = wrap.querySelector('#export-backup-btn');
        const importBtn = wrap.querySelector('#import-backup-btn');
        const input = wrap.querySelector('#import-backup-input');

        if (exportBtn) {
            exportBtn.addEventListener('click', exportBackup);
        }

        if (importBtn && input) {
            importBtn.addEventListener('click', () => input.click());
            input.addEventListener('change', async (event) => {
                const file = event.target.files && event.target.files[0];
                if (!file) return;
                try {
                    await importBackup(file);
                } finally {
                    input.value = '';
                }
            });
        }
    }

    function exportBackup() {
        const payload = {
            version: '1.4',
            exportedAt: new Date().toISOString(),
            records: {}
        };

        BACKUP_KEYS.forEach((key) => {
            const raw = ExtensionStorage.getItem(key);
            if (raw !== null) {
                payload.records[key] = parseMaybeJSON(raw);
            }
        });

        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        const stamp = new Date().toISOString().slice(0, 10);
        link.href = url;
        link.download = `writing-imitation-backup-${stamp}.json`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 1500);
        if (typeof showTransientMessage === 'function') {
            showTransientMessage('Backup exported.');
        }
    }

    function importBackup(file) {
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = () => {
                try {
                    const parsed = JSON.parse(String(reader.result || '{}'));
                    const records = parsed && parsed.records && typeof parsed.records === 'object'
                        ? normalizeImportedRecords(parsed.records)
                        : null;

                    if (!records) {
                        throw new Error('Invalid backup file.');
                    }

                    BACKUP_KEYS.forEach((key) => {
                        if (Object.prototype.hasOwnProperty.call(records, key)) {
                            ExtensionStorage.setItem(key, toRawStorageValue(records[key]));
                        }
                    });

                    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                        try {
                            chrome.runtime.sendMessage({ type: 'tugadi-sync-review-check', reason: 'backup-import' }).catch(() => {});
                        } catch (error) {
                            // Ignore messaging failures.
                        }
                    }

                    if (typeof showTransientMessage === 'function') {
                        showTransientMessage('Backup imported. Reloading…', { duration: 1400 });
                    }

                    window.setTimeout(() => {
                        window.location.reload();
                    }, 450);
                } catch (error) {
                    console.error('Import failed.', error);
                    if (typeof showTransientMessage === 'function') {
                        showTransientMessage('Import failed. Choose a valid backup JSON.');
                    }
                } finally {
                    resolve();
                }
            };
            reader.onerror = () => {
                if (typeof showTransientMessage === 'function') {
                    showTransientMessage('Import failed. The file could not be read.');
                }
                resolve();
            };
            reader.readAsText(file);
        });
    }

    function injectOnboardingBanner() {
        const manager = getManager();
        if (!manager) return;
        ensureStatsShape(manager);

        const container = document.querySelector('.container');
        if (!container) return;

        const existing = document.getElementById('onboarding-banner');
        if (existing) {
            existing.remove();
        }

        const shouldShow = !manager.stats.uiState.onboardingDismissed && (
            !manager.stats.totalPractices || !(coerceArray(getStoredJSON('wordList', [])).length)
        );

        if (!shouldShow) {
            return;
        }

        const banner = document.createElement('section');
        banner.id = 'onboarding-banner';
        banner.className = 'onboarding-banner';
        banner.innerHTML = `
            <div class="onboarding-copy">
                <h2>Start here</h2>
                <p>Build a tiny daily loop: practice a sentence, save hard words, then review what comes back.</p>
                <ol>
                    <li>Paste a short paragraph.</li>
                    <li>Practice one round from memory.</li>
                    <li>Save difficult words to your list.</li>
                    <li>Review scheduled items each day.</li>
                </ol>
            </div>
            <div class="onboarding-actions">
                <button id="onboarding-dismiss-btn" class="storage-btn secondary-action" type="button">Got it</button>
            </div>
        `;

        const article = document.getElementById('article-input');
        if (article) {
            container.insertBefore(banner, article);
        } else {
            container.prepend(banner);
        }

        const dismissBtn = banner.querySelector('#onboarding-dismiss-btn');
        if (dismissBtn) {
            dismissBtn.addEventListener('click', () => {
                manager.stats.uiState.onboardingDismissed = true;
                persistStats(manager);
                banner.remove();
            });
        }
    }

    function ensureInsightsSection() {
        const dashboardContent = document.querySelector('#statistics-dashboard .dashboard-content');
        if (!dashboardContent) {
            return null;
        }

        let section = document.getElementById('insights-section');
        if (section) {
            return section;
        }

        section = document.createElement('div');
        section.id = 'insights-section';
        section.className = 'dashboard-section';
        section.innerHTML = `
            <h3><i class="fi fi-rr-chart-line-up"></i> Progress</h3>
            <div id="insights-content" class="progress-insights"></div>
        `;

        const storageSection = Array.from(dashboardContent.querySelectorAll('.dashboard-section')).pop();
        if (storageSection) {
            dashboardContent.insertBefore(section, storageSection);
        } else {
            dashboardContent.appendChild(section);
        }

        return section;
    }

    function getDateWindow(daysBack) {
        const end = new Date();
        end.setHours(23, 59, 59, 999);
        const start = new Date();
        start.setHours(0, 0, 0, 0);
        start.setDate(start.getDate() - daysBack);
        return { start, end };
    }

    function summarizeSessions(list) {
        const sessions = coerceArray(list);
        const totals = sessions.reduce((acc, session) => {
            acc.sessions += 1;
            acc.sentences += Number(session.sentences) || 0;
            acc.minutes += Number(session.duration) || 0;
            acc.successSum += Number(session.successRate) || 0;
            return acc;
        }, { sessions: 0, sentences: 0, minutes: 0, successSum: 0 });

        totals.avgSuccess = totals.sessions ? Math.round(totals.successSum / totals.sessions) : 0;
        return totals;
    }
    function getWordMissCount(wordKey) {
        const manager = getManager();
        if (!manager || !manager.stats) return 0;
        return coerceArray(manager.stats.attemptLog).filter((entry) => {
            return entry && entry.focusWord === wordKey && entry.success === false;
        }).length;
    }


    function makeInsightDayKey(value) {
        const date = value instanceof Date ? new Date(value.getTime()) : new Date(value || Date.now());
        if (Number.isNaN(date.getTime())) {
            return null;
        }
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    function parseInsightDayKey(key) {
        const raw = String(key || '');
        if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
            return null;
        }
        const parts = raw.split('-').map(Number);
        const date = new Date(parts[0], parts[1] - 1, parts[2], 12, 0, 0, 0);
        return Number.isNaN(date.getTime()) ? null : date;
    }

    function insightSafeNumber(value) {
        const n = Number(value);
        return Number.isFinite(n) ? n : 0;
    }

    function insightRound(value, digits) {
        const factor = Math.pow(10, digits || 1);
        return Math.round(insightSafeNumber(value) * factor) / factor;
    }

    function formatInsightMinutes(minutes) {
        const total = Math.max(0, Math.round(insightSafeNumber(minutes)));
        const hours = Math.floor(total / 60);
        const mins = total % 60;
        if (hours && mins) return `${hours}h ${mins}m`;
        if (hours) return `${hours}h`;
        return `${mins}m`;
    }

    function formatInsightDate(value, options) {
        const date = value instanceof Date ? value : new Date(value || Date.now());
        if (Number.isNaN(date.getTime())) {
            return 'Unknown';
        }
        return date.toLocaleDateString(undefined, options || { month: 'short', day: 'numeric' });
    }

    function humanizeInsightErrorType(label) {
        const raw = String(label || 'unknown');
        if (raw === 'spelling') return 'Spelling';
        if (raw === 'spacing') return 'Spacing';
        if (raw === 'omission') return 'Missing part';
        if (raw === 'capitalization') return 'Capitalization';
        if (raw.indexOf('punctuation:') === 0) {
            const detail = raw.split(':')[1] || 'mark';
            return `Punctuation (${detail.replace(/-/g, ' ')})`;
        }
        return raw.charAt(0).toUpperCase() + raw.slice(1).replace(/[_-]+/g, ' ');
    }

    function summarizeInsightRows(rows) {
        const summary = {
            sessions: 0,
            sentences: 0,
            minutes: 0,
            mistakes: 0,
            attempts: 0,
            failures: 0,
            successWeighted: 0,
            firstTryWeighted: 0,
            altWeighted: 0,
            weight: 0,
            avgSuccess: 0,
            avgFirstTrySuccess: 0,
            avgAltUsage: 0,
            avgMistakesPerSession: 0
        };

        coerceArray(rows).forEach((row) => {
            summary.sessions += insightSafeNumber(row && row.sessions);
            summary.sentences += insightSafeNumber(row && row.sentences);
            summary.minutes += insightSafeNumber(row && row.minutes);
            summary.mistakes += insightSafeNumber(row && row.mistakes);
            summary.attempts += insightSafeNumber(row && row.attempts);
            summary.failures += insightSafeNumber(row && row.failures);
            summary.successWeighted += insightSafeNumber(row && row.successWeighted);
            summary.firstTryWeighted += insightSafeNumber(row && row.firstTryWeighted);
            summary.altWeighted += insightSafeNumber(row && row.altWeighted);
            summary.weight += insightSafeNumber(row && row.weight);
        });

        summary.avgSuccess = summary.weight ? Math.round(summary.successWeighted / summary.weight) : 0;
        summary.avgFirstTrySuccess = summary.weight ? Math.round(summary.firstTryWeighted / summary.weight) : 0;
        summary.avgAltUsage = summary.weight ? Math.round(summary.altWeighted / summary.weight) : 0;
        summary.avgMistakesPerSession = summary.sessions ? insightRound(summary.mistakes / summary.sessions, 1) : 0;
        return summary;
    }

    function formatInsightDelta(current, previous, options) {
        const settings = options || {};
        if (!previous && previous !== 0) {
            return { tone: 'neutral', text: 'Need more history' };
        }
        const digits = settings.digits || 0;
        const suffix = settings.suffix || '';
        const reverse = Boolean(settings.reverse);
        const delta = insightSafeNumber(current) - insightSafeNumber(previous);
        if (Math.abs(delta) < 0.05) {
            return { tone: 'neutral', text: 'No real change' };
        }
        const amount = digits === 0 ? Math.round(Math.abs(delta)) : insightRound(Math.abs(delta), digits);
        const improved = reverse ? delta < 0 : delta > 0;
        const direction = reverse ? (improved ? 'lower' : 'higher') : (improved ? 'higher' : 'lower');
        return {
            tone: improved ? 'good' : 'warn',
            text: `${amount}${suffix} ${direction}`
        };
    }

    function buildInsightSparkline(points, valueKey, options) {
        const settings = options || {};
        const width = 320;
        const height = 132;
        const paddingX = 12;
        const paddingTop = 16;
        const paddingBottom = 24;
        const values = coerceArray(points).map((point) => insightSafeNumber(point && point[valueKey]));
        const activeValues = values.filter((value, index) => {
            const point = points[index] || {};
            return insightSafeNumber(point.sessions) > 0 || insightSafeNumber(point.sentences) > 0 || insightSafeNumber(point.weight) > 0;
        });
        const bestValue = settings.bestValue == null ? null : insightSafeNumber(settings.bestValue);
        const maxSource = bestValue == null ? values : values.concat([bestValue]);
        const max = Math.max(...maxSource, 1);
        const min = Math.min(...values, 0, bestValue == null ? 0 : bestValue);
        const range = max - min || 1;
        const xFor = (index) => {
            if (values.length <= 1) return width / 2;
            return paddingX + ((width - (paddingX * 2)) * (index / (values.length - 1)));
        };
        const yFor = (value) => paddingTop + ((height - paddingTop - paddingBottom) * (1 - ((value - min) / range)));
        const pointsString = values.map((value, index) => `${xFor(index)},${yFor(value)}`).join(' ');
        const lastIndex = Math.max(0, values.length - 1);
        const lastValueRaw = values.length ? values[lastIndex] : 0;
        const formatter = typeof settings.formatter === 'function' ? settings.formatter : ((value) => String(value));
        const latestValue = formatter(lastValueRaw);
        const bestText = bestValue == null ? '—' : formatter(bestValue);
        const bestY = bestValue == null ? null : yFor(bestValue);

        return `
            <div class="progress-line-card">
                <div class="progress-line-head">
                    <div>
                        <h4>${escapeHTML(settings.label || '')}</h4>
                        <p>${escapeHTML(settings.note || '')}</p>
                    </div>
                    <div class="progress-line-stats">
                        <span><strong>${escapeHTML(latestValue)}</strong> latest</span>
                        <span><strong>${escapeHTML(bestText)}</strong> best</span>
                    </div>
                </div>
                <svg viewBox="0 0 ${width} ${height}" class="progress-sparkline" aria-hidden="true">
                    <line x1="${paddingX}" y1="${height - paddingBottom}" x2="${width - paddingX}" y2="${height - paddingBottom}" class="progress-spark-axis"></line>
                    ${bestY == null ? '' : `<line x1="${paddingX}" y1="${bestY}" x2="${width - paddingX}" y2="${bestY}" class="progress-best-line"></line>`}
                    <polyline points="${pointsString}" class="progress-spark-path"></polyline>
                    ${values.map((value, index) => `<circle cx="${xFor(index)}" cy="${yFor(value)}" r="${index === lastIndex ? 4.4 : 3.1}" class="progress-spark-dot${index === lastIndex ? ' active' : ''}"></circle>`).join('')}
                </svg>
                <div class="progress-chart-foot">
                    <span>${escapeHTML(points[0] ? points[0].label : 'Earlier')}</span>
                    <span>${escapeHTML(points[lastIndex] ? points[lastIndex].label : 'Now')}</span>
                </div>
            </div>`;
    }

    function buildProgressStatus(currentSummary, previousSummary, previousAvailable) {
        if (!previousAvailable) {
            return {
                stateClass: 'neutral',
                title: 'Building baseline',
                detail: 'One more full week unlocks a direct comparison.'
            };
        }

        const changes = [
            {
                key: 'Success',
                delta: insightSafeNumber(currentSummary.avgSuccess) - insightSafeNumber(previousSummary.avgSuccess),
                threshold: 3,
                reverse: false,
                format: (value) => `${Math.round(Math.abs(value))} pts`
            },
            {
                key: 'Mistakes',
                delta: insightSafeNumber(currentSummary.avgMistakesPerSession) - insightSafeNumber(previousSummary.avgMistakesPerSession),
                threshold: 0.2,
                reverse: true,
                format: (value) => String(insightRound(Math.abs(value), 1))
            },
            {
                key: 'Alt help',
                delta: insightSafeNumber(currentSummary.avgAltUsage) - insightSafeNumber(previousSummary.avgAltUsage),
                threshold: 3,
                reverse: true,
                format: (value) => `${Math.round(Math.abs(value))} pts`
            }
        ];

        const improved = [];
        const slipped = [];
        changes.forEach((item) => {
            if (Math.abs(item.delta) < item.threshold) return;
            const isBetter = item.reverse ? item.delta < 0 : item.delta > 0;
            const label = `${item.key} ${item.delta > 0 ? 'up' : 'down'} ${item.format(item.delta)}`;
            if (isBetter) improved.push(label);
            else slipped.push(label);
        });

        if (improved.length >= 2 && slipped.length === 0) {
            return {
                stateClass: 'good',
                title: 'Improving',
                detail: improved.join(' · ')
            };
        }
        if (slipped.length >= 2 && improved.length === 0) {
            return {
                stateClass: 'warn',
                title: 'Needs attention',
                detail: slipped.join(' · ')
            };
        }
        if (!improved.length && !slipped.length) {
            return {
                stateClass: 'neutral',
                title: 'Steady',
                detail: 'The last two 7-day blocks are close.'
            };
        }
        return {
            stateClass: 'neutral',
            title: 'Mixed',
            detail: improved.concat(slipped).join(' · ')
        };
    }

    function computeInsights() {
        const manager = getManager();
        if (!manager) {
            return null;
        }

        ensureStatsShape(manager);
        const stats = manager.stats;
        const history = coerceArray(stats.practiceHistory)
            .map((session) => {
                const date = new Date(session && session.date ? session.date : Date.now());
                if (Number.isNaN(date.getTime())) return null;
                return {
                    date,
                    dateKey: makeInsightDayKey(date),
                    sentences: Math.max(0, insightSafeNumber(session && session.sentences)),
                    duration: Math.max(0, insightSafeNumber(session && session.duration)),
                    mistakes: Math.max(0, insightSafeNumber(session && session.mistakes)),
                    successRate: Math.max(0, Math.min(100, insightSafeNumber(session && session.successRate))),
                    firstTrySuccessRate: Math.max(0, Math.min(100, insightSafeNumber(session && (session.firstTrySuccessRate ?? session.successRate)))),
                    altUsageRate: Math.max(0, Math.min(100, insightSafeNumber(session && session.altUsageRate)))
                };
            })
            .filter(Boolean)
            .sort((a, b) => a.date - b.date);

        if (!history.length) {
            return null;
        }

        const DAY = 24 * 60 * 60 * 1000;
        const today = parseInsightDayKey(makeInsightDayKey(new Date())) || new Date();
        const latestHistoryEntry = history[history.length - 1] || null;
        const latestHistoryDate = latestHistoryEntry ? (parseInsightDayKey(latestHistoryEntry.dateKey) || latestHistoryEntry.date) : null;
        const anchorDate = latestHistoryDate && latestHistoryDate.getTime() < today.getTime() ? latestHistoryDate : today;
        const dailyMap = new Map();

        history.forEach((session) => {
            const existing = dailyMap.get(session.dateKey) || {
                date: parseInsightDayKey(session.dateKey) || session.date,
                dateKey: session.dateKey,
                sessions: 0,
                sentences: 0,
                minutes: 0,
                mistakes: 0,
                attempts: 0,
                failures: 0,
                successWeighted: 0,
                firstTryWeighted: 0,
                altWeighted: 0,
                weight: 0
            };
            const weight = Math.max(1, session.sentences || 0);
            existing.sessions += 1;
            existing.sentences += session.sentences;
            existing.minutes += session.duration;
            existing.mistakes += session.mistakes;
            existing.successWeighted += session.successRate * weight;
            existing.firstTryWeighted += session.firstTrySuccessRate * weight;
            existing.altWeighted += session.altUsageRate * weight;
            existing.weight += weight;
            dailyMap.set(session.dateKey, existing);
        });

        const buildWindow = (endDate, days) => {
            const end = new Date(endDate instanceof Date ? endDate.getTime() : endDate);
            end.setHours(12, 0, 0, 0);
            const rows = [];
            for (let i = days - 1; i >= 0; i -= 1) {
                const date = new Date(end.getTime() - (i * DAY));
                const key = makeInsightDayKey(date);
                rows.push(dailyMap.get(key) || {
                    date,
                    dateKey: key,
                    sessions: 0,
                    sentences: 0,
                    minutes: 0,
                    mistakes: 0,
                    attempts: 0,
                    failures: 0,
                    successWeighted: 0,
                    altWeighted: 0,
                    weight: 0
                });
            }
            return rows;
        };

        const currentRows = buildWindow(anchorDate, 7);
        const previousRows = buildWindow(new Date(anchorDate.getTime() - (7 * DAY)), 7);
        const currentSummary = summarizeInsightRows(currentRows);
        const previousSummary = summarizeInsightRows(previousRows);
        const previousAvailable = previousSummary.sessions > 0 || previousSummary.sentences > 0 || previousSummary.weight > 0;

        const trendBlocks = [];
        for (let offset = 7; offset >= 0; offset -= 1) {
            const end = new Date(anchorDate.getTime() - (offset * 7 * DAY));
            const rows = buildWindow(end, 7);
            const summary = summarizeInsightRows(rows);
            trendBlocks.push({
                label: offset === 0 ? 'Now' : `${offset}w ago`,
                range: `${formatInsightDate(rows[0].date)} – ${formatInsightDate(rows[rows.length - 1].date)}`,
                ...summary
            });
        }

        const windows = [];
        let cursor = parseInsightDayKey(history[0].dateKey) || history[0].date;
        cursor = new Date(cursor.getTime());
        cursor.setHours(12, 0, 0, 0);
        while (cursor <= anchorDate) {
            const rows = buildWindow(cursor, 7);
            const summary = summarizeInsightRows(rows);
            if (summary.sessions > 0 || summary.sentences > 0 || summary.weight > 0) {
                windows.push({ rows, summary });
            }
            cursor = new Date(cursor.getTime() + DAY);
        }

        const bestFor = (key, mode) => {
            if (!windows.length) return null;
            return windows.reduce((best, item) => {
                if (!best) return item;
                const currentValue = insightSafeNumber(item.summary[key]);
                const bestValue = insightSafeNumber(best.summary[key]);
                if (mode === 'min') {
                    return currentValue < bestValue ? item : best;
                }
                return currentValue > bestValue ? item : best;
            }, null);
        };

        const bestSuccess = bestFor('avgSuccess', 'max');
        const bestFirstTry = bestFor('avgFirstTrySuccess', 'max');
        const bestMistakes = bestFor('avgMistakesPerSession', 'min');
        const bestAlt = bestFor('avgAltUsage', 'min');

        return {
            currentSummary,
            previousSummary,
            previousAvailable,
            currentRange: `${formatInsightDate(currentRows[0].date)} – ${formatInsightDate(currentRows[currentRows.length - 1].date)}`,
            previousRange: `${formatInsightDate(previousRows[0].date)} – ${formatInsightDate(previousRows[previousRows.length - 1].date)}`,
            trendBlocks,
            status: buildProgressStatus(currentSummary, previousSummary, previousAvailable),
            metrics: [
                {
                    key: 'success',
                    label: 'Success',
                    current: `${currentSummary.avgSuccess}%`,
                    previous: previousAvailable ? `${previousSummary.avgSuccess}%` : '—',
                    best: bestSuccess ? `${bestSuccess.summary.avgSuccess}%` : '—',
                    delta: previousAvailable ? formatInsightDelta(currentSummary.avgSuccess, previousSummary.avgSuccess, { digits: 0, suffix: ' pts' }) : { tone: 'neutral', text: 'Need more history' },
                    note: currentRange,
                    bestValue: bestSuccess ? bestSuccess.summary.avgSuccess : null
                },
                {
                    key: 'firstTry',
                    label: 'Clean Pass',
                    current: `${currentSummary.avgFirstTrySuccess}%`,
                    previous: previousAvailable ? `${previousSummary.avgFirstTrySuccess}%` : '—',
                    best: bestFirstTry ? `${bestFirstTry.summary.avgFirstTrySuccess}%` : '—',
                    delta: previousAvailable ? formatInsightDelta(currentSummary.avgFirstTrySuccess, previousSummary.avgFirstTrySuccess, { digits: 0, suffix: ' pts' }) : { tone: 'neutral', text: 'Need more history' },
                    note: `${currentSummary.sentences} sentences`,
                    bestValue: bestFirstTry ? bestFirstTry.summary.avgFirstTrySuccess : null
                },
                {
                    key: 'mistakes',
                    label: 'Mistakes / session',
                    current: String(currentSummary.avgMistakesPerSession),
                    previous: previousAvailable ? String(previousSummary.avgMistakesPerSession) : '—',
                    best: bestMistakes ? String(bestMistakes.summary.avgMistakesPerSession) : '—',
                    delta: previousAvailable ? formatInsightDelta(currentSummary.avgMistakesPerSession, previousSummary.avgMistakesPerSession, { digits: 1, reverse: true }) : { tone: 'neutral', text: 'Need more history' },
                    note: currentRange,
                    bestValue: bestMistakes ? bestMistakes.summary.avgMistakesPerSession : null
                },
                {
                    key: 'alt',
                    label: 'Alt help',
                    current: `${currentSummary.avgAltUsage}%`,
                    previous: previousAvailable ? `${previousSummary.avgAltUsage}%` : '—',
                    best: bestAlt ? `${bestAlt.summary.avgAltUsage}%` : '—',
                    delta: previousAvailable ? formatInsightDelta(currentSummary.avgAltUsage, previousSummary.avgAltUsage, { digits: 0, suffix: ' pts', reverse: true }) : { tone: 'neutral', text: 'Need more history' },
                    note: currentRange,
                    bestValue: bestAlt ? bestAlt.summary.avgAltUsage : null
                }
            ],
            charts: [
                {
                    valueKey: 'avgSuccess',
                    label: 'Success trend',
                    note: 'Higher is better · 7-day blocks',
                    formatter: (value) => `${Math.round(value)}%`,
                    bestValue: bestSuccess ? bestSuccess.summary.avgSuccess : null
                },
                {
                    valueKey: 'avgFirstTrySuccess',
                    label: 'Clean Pass trend',
                    note: 'Higher is better · 7-day blocks',
                    formatter: (value) => `${Math.round(value)}%`,
                    bestValue: bestFirstTry ? bestFirstTry.summary.avgFirstTrySuccess : null
                },
                {
                    valueKey: 'avgMistakesPerSession',
                    label: 'Mistakes trend',
                    note: 'Lower is better · 7-day blocks',
                    formatter: (value) => String(insightRound(value, 1)),
                    bestValue: bestMistakes ? bestMistakes.summary.avgMistakesPerSession : null
                },
                {
                    valueKey: 'avgAltUsage',
                    label: 'Alt help trend',
                    note: 'Lower is better · 7-day blocks',
                    formatter: (value) => `${Math.round(value)}%`,
                    bestValue: bestAlt ? bestAlt.summary.avgAltUsage : null
                }
            ]
        };
    }

    function renderInsights() {
        const manager = getManager();
        if (!manager) return;
        ensureStatsShape(manager);

        const section = ensureInsightsSection();
        if (!section) return;

        const insights = computeInsights();
        const content = section.querySelector('#insights-content');
        if (!content) return;
        if (!insights) {
            content.innerHTML = '<p class="empty-state compact">Complete a few sessions to unlock progress.</p>';
            return;
        }

        const metricsMarkup = insights.metrics.map((metric) => `
            <div class="progress-metric-card">
                <div class="progress-metric-top">
                    <span>${escapeHTML(metric.label)}</span>
                    <span class="progress-delta-pill ${metric.delta.tone}">${escapeHTML(metric.delta.text)}</span>
                </div>
                <div class="progress-metric-value">${escapeHTML(metric.current)}</div>
                <div class="progress-metric-meta">
                    <span>Previous <strong>${escapeHTML(metric.previous)}</strong></span>
                    <span>Best <strong>${escapeHTML(metric.best)}</strong></span>
                </div>
                <div class="progress-metric-note">${escapeHTML(metric.note)}</div>
            </div>`).join('');

        const chartMarkup = insights.charts.map((chart) => buildInsightSparkline(insights.trendBlocks, chart.valueKey, chart)).join('');

        content.innerHTML = `
            <div class="progress-shell">
                <div class="progress-summary-card ${insights.status.stateClass}">
                    <div>
                        <div class="progress-summary-label">Latest 7 days</div>
                        <h4>${escapeHTML(insights.status.title)}</h4>
                        <p>${escapeHTML(insights.status.detail)}</p>
                    </div>
                    <div class="progress-summary-side">
                        <span>${escapeHTML(insights.currentRange)}</span>
                        <strong>${escapeHTML(insights.previousAvailable ? `vs ${insights.previousRange}` : 'Baseline only')}</strong>
                    </div>
                </div>
                <div class="progress-metrics-grid">
                    ${metricsMarkup}
                </div>
                <div class="progress-lines-grid">
                    ${chartMarkup}
                </div>
            </div>`;
    }

    function detectPunctuationDifference(originalWord, userWord) {
        const original = String(originalWord || '');
        const user = String(userWord || '');

        const has = (value, char) => value.indexOf(char) !== -1;
        if (has(original, ',') && !has(user, ',')) return 'missing-comma';
        if (!has(original, ',') && has(user, ',')) return 'extra-comma';
        if (has(original, '.') && !has(user, '.')) return 'missing-period';
        if (!has(original, '.') && has(user, '.')) return 'extra-period';
        if ((/["“”]/.test(original) || /["“”]/.test(user))) return 'quote-mismatch';
        if ((/[']/.test(original) || /[']/.test(user) || /[’]/.test(original) || /[’]/.test(user))) return 'apostrophe';
        if (original.replace(/\W/g, '').toLowerCase() === user.replace(/\W/g, '').toLowerCase()) return 'punctuation-form';
        return 'other';
    }

    function classifyAttempt(rawUserInput, originalSentence, state) {
        const raw = String(rawUserInput || '').trim();
        const originalRaw = String(originalSentence || '').trim();
        const analysis = {
            timestamp: new Date().toISOString(),
            success: false,
            errorType: 'spelling',
            focusWord: '',
            incorrectWord: '',
            correctWord: '',
            sentenceIndex: Number(state && state.currentSentenceIndex) || 0
        };

        if (!raw || !originalRaw) {
            return analysis;
        }

        if (/\s{2,}/.test(raw)) {
            analysis.errorType = 'spacing';
            return analysis;
        }

        const originalNormalized = normalizeText(originalRaw);
        const userNormalized = normalizeText(raw);

        if (originalNormalized === userNormalized) {
            analysis.success = true;
            analysis.errorType = 'success';
            return analysis;
        }

        const originalWords = originalNormalized.split(' ');
        const userWords = userNormalized.split(' ');
        const length = Math.max(originalWords.length, userWords.length);

        for (let i = 0; i < length; i += 1) {
            const originalWord = originalWords[i] || '';
            const userWord = userWords[i] || '';
            if (originalWord === userWord) continue;

            analysis.correctWord = originalWord;
            analysis.incorrectWord = userWord;
            analysis.focusWord = normalizeWordKey(originalWord || userWord);

            if (!userWord) {
                analysis.errorType = 'omission';
                return analysis;
            }

            if (normalizeWordKey(originalWord) === normalizeWordKey(userWord)) {
                const strippedOriginal = String(originalWord).replace(/[.,!?;:'"“”‘’()-]/g, '');
                const strippedUser = String(userWord).replace(/[.,!?;:'"“”‘’()-]/g, '');
                if (strippedOriginal.toLowerCase() === strippedUser.toLowerCase() && strippedOriginal !== strippedUser) {
                    analysis.errorType = 'punctuation:' + detectPunctuationDifference(originalWord, userWord);
                } else {
                    analysis.errorType = 'capitalization';
                }
            } else if (originalWord.replace(/[^A-Za-z]/g, '').toLowerCase() === userWord.replace(/[^A-Za-z]/g, '').toLowerCase()) {
                analysis.errorType = 'punctuation:' + detectPunctuationDifference(originalWord, userWord);
            } else {
                analysis.errorType = 'spelling';
            }
            return analysis;
        }

        return analysis;
    }

    // patchSpacedRepetitionManager removed (fixed schedule UI).

// createQuickReviewControls removed (fixed schedule UI).

    // handleQuickReviewChoice removed (fixed schedule UI).

    // decorateMistakesList removed (fixed schedule UI).

function getWordMeta(word, index) {
        const spaced = getSpacedManager();
        const key = normalizeWordKey(word);
        const entry = spaced
            ? (typeof spaced.getEntry === 'function'
                ? spaced.getEntry(key, 'wordList')
                : (spaced.schedule ? spaced.schedule[(spaced.makeKey ? spaced.makeKey(key, 'wordList') : key)] : null))
            : null;
        const due = Boolean(entry && Number(entry.nextDue) <= Date.now());
        const missCount = getWordMissCount(key);
        const nextDue = entry && typeof entry.nextDue !== 'undefined'
            ? (Number(entry.nextDue) || Number.MAX_SAFE_INTEGER)
            : Number.MAX_SAFE_INTEGER;
        return {
            key,
            due,
            stage: entry ? Number(entry.stage) || 0 : 0,
            mastered: Boolean(entry && entry.mastered),
            nextDue,
            missCount,
            recent: index >= Math.max(0, coerceArray(getStoredJSON('wordList', [])).length - 5)
        };
    }

    function injectWordListToolbar() {
        const section = document.getElementById('word-list-section');
        const heading = section ? section.querySelector('h2') : null;
        if (!section || !heading || section.querySelector('.word-list-toolbar')) {
            return;
        }

        const toolbar = document.createElement('div');
        toolbar.className = 'word-list-toolbar';
        toolbar.innerHTML = `
            <input id="word-list-search" type="search" placeholder="Search words">
            <select id="word-list-view" aria-label="Word list view">
                <option value="all">All words</option>
                <option value="due">Ready to review</option>
                <option value="learning">In progress</option>
                <option value="alpha">A-Z</option>
                <option value="mastered">Mastered</option>
            </select>
        `;
        heading.insertAdjacentElement('afterend', toolbar);

        const search = toolbar.querySelector('#word-list-search');
        const view = toolbar.querySelector('#word-list-view');

        if (search) {
            search.addEventListener('input', (event) => {
                featureState.wordList.search = event.target.value || '';
                applyWordListToolbar();
            });
        }
        if (view) {
            view.addEventListener('change', (event) => {
                featureState.wordList.view = event.target.value || 'all';
                applyWordListToolbar();
            });
        }
    }

    function decorateWordList() {
        injectWordListToolbar();
        const list = document.getElementById('word-list');
        if (!list) return;

        const words = typeof getStoredWordList === 'function' ? getStoredWordList() : [];
        const items = Array.from(list.querySelectorAll('.word-list-item'));

        items.forEach((item) => {
            const removeBtn = item.querySelector('.remove-word-btn');
            const index = removeBtn ? parseInt(removeBtn.getAttribute('data-index'), 10) : -1;
            const word = words[index] || '';
            if (!word) return;

            const meta = getWordMeta(word, index);
            item.dataset.search = word.toLowerCase();
            item.dataset.due = meta.due ? '1' : '0';
            item.dataset.stage = String(meta.stage);
            item.dataset.mastered = meta.mastered ? '1' : '0';
            item.dataset.nextDue = String(meta.nextDue);
            item.dataset.missCount = String(meta.missCount);
            item.dataset.recent = meta.recent ? '1' : '0';
            item.dataset.alpha = word.toLowerCase();
            item.dataset.indexValue = String(index);

            // Fixed schedule: remove any old badge rows / rating buttons, if present.
            const existingMetaRow = item.querySelector('.word-meta-inline');
            if (existingMetaRow) existingMetaRow.remove();
            const existingControls = item.querySelector('.quick-review-controls');
            if (existingControls) existingControls.remove();
        });

        applyWordListToolbar();
    }


    function applyWordListToolbar() {
        const list = document.getElementById('word-list');
        if (!list) return;

        const existingEmpty = list.querySelector('.filtered-empty-state');
        if (existingEmpty) existingEmpty.remove();

        const items = Array.from(list.querySelectorAll('.word-list-item'));
        if (!items.length) return;

        const searchTerm = featureState.wordList.search.trim().toLowerCase();

        // Decode the "view" preset into filter + sort.
        let viewValue = featureState.wordList.view || 'all';

        // Backwards compatibility for older saved presets
        if (['all-alpha'].includes(viewValue)) viewValue = 'alpha';
        if (['stage', 'stage0', 'stage1', 'stage2', 'stage3', 'stage4', 'recent'].includes(viewValue)) viewValue = 'learning';

        let filterValue = 'all';
        let sortValue = 'nextDue';

        switch (viewValue) {
            case 'alpha':
                filterValue = 'all';
                sortValue = 'alpha';
                break;
            case 'due':
                filterValue = 'due';
                sortValue = 'nextDue';
                break;
            case 'learning':
                filterValue = 'active';
                sortValue = 'nextDue';
                break;
            case 'mastered':
                filterValue = 'mastered';
                sortValue = 'alpha';
                break;
            case 'all':
            default:
                filterValue = 'all';
                sortValue = 'nextDue';
                break;
        }

        const visibleItems = items.filter((item) => {
            const textMatch = !searchTerm || (item.dataset.search || '').includes(searchTerm);
            if (!textMatch) return false;

            const due = item.dataset.due === '1';
            const stage = Number(item.dataset.stage) || 0;
            const mastered = item.dataset.mastered === '1';
            const missCount = Number(item.dataset.missCount) || 0;
            const recent = item.dataset.recent === '1';

            switch (filterValue) {
                case 'due':
                    return due;
                case 'stage0':
                    return stage === 0 && !mastered;
                case 'stage1':
                    return stage === 1 && !mastered;
                case 'stage2':
                    return stage === 2 && !mastered;
                case 'stage3':
                    return stage === 3 && !mastered;
                case 'stage4':
                    return stage === 4 && !mastered;
                case 'mastered':
                    return mastered;
                case 'recent':
                    return recent;
                case 'active':
                    return !mastered;
                case 'all':
                default:
                    return true;
            }
        });

        items.forEach((item) => {
            item.style.display = visibleItems.includes(item) ? '' : 'none';
        });

        visibleItems.sort((a, b) => {
            const aAlpha = a.dataset.alpha || '';
            const bAlpha = b.dataset.alpha || '';

            if (sortValue === 'alpha') {
                return aAlpha.localeCompare(bAlpha);
            }

            if (sortValue === 'recent') {
                return (Number(b.dataset.indexValue) || 0) - (Number(a.dataset.indexValue) || 0);
            }

            const aStage = Number(a.dataset.stage) || 0;
            const bStage = Number(b.dataset.stage) || 0;
            const aDueAt = Number(a.dataset.nextDue) || Number.MAX_SAFE_INTEGER;
            const bDueAt = Number(b.dataset.nextDue) || Number.MAX_SAFE_INTEGER;

            if (sortValue === 'stage') {
                if (aStage !== bStage) return aStage - bStage;
                if (aDueAt !== bDueAt) return aDueAt - bDueAt;
                return aAlpha.localeCompare(bAlpha);
            }

            // Default: soonest due first
            if (aDueAt !== bDueAt) return aDueAt - bDueAt;
            return aAlpha.localeCompare(bAlpha);
        });

        visibleItems.forEach((item) => list.appendChild(item));

        if (!visibleItems.length) {
            const empty = document.createElement('li');
            empty.className = 'empty-state filtered-empty-state';
            empty.textContent = 'No words match this filter yet.';
            list.appendChild(empty);
        }
    }

    function patchDisplayWordList() {
        if (typeof window.displayWordList !== 'function' || window.displayWordList.__v21Enhanced) {
            decorateWordList();
            return;
        }

        const original = window.displayWordList;
        const enhanced = function enhancedDisplayWordList() {
            const result = original.apply(this, arguments);
            decorateWordList();
            return result;
        };
        enhanced.__v21Enhanced = true;
        window.displayWordList = enhanced;
        try {
            displayWordList = enhanced;
        } catch (error) {
            /* noop */
        }
    }

    function patchStatisticsManager() {
        const manager = getManager();
        if (!manager) return;
        ensureStatsShape(manager);

        manager.logAttempt = function logAttempt(entry) {
            ensureStatsShape(this);
            this.stats.attemptLog.push({
                timestamp: new Date().toISOString(),
                dayKey: typeof this.getLocalDayKey === 'function' ? this.getLocalDayKey() : null,
                ...entry
            });
            this.stats.attemptLog = trimLog(this.stats.attemptLog, 1000);
            persistStats(this);
            renderInsights();
        };

        if (!manager.__v21Enhanced) {
            const originalUpdateUI = manager.updateUI.bind(manager);
            manager.updateUI = function enhancedUpdateUI() {
                ensureStatsShape(this);
                originalUpdateUI();
                renderInsights();
                injectOnboardingBanner();
            };
            manager.__v21Enhanced = true;
        }

        manager.updateUI();
    }

    function patchPracticeHandlers() {
        const input = document.getElementById('user-input');
        const checkBtn = document.getElementById('check-button');
        if (!input || !checkBtn || input.dataset.v21Patched === '1') {
            return;
        }

        const originalHandle = window.handleKeyDown;
        const originalCheck = window.checkText;

        if (typeof originalHandle === 'function') {
            input.removeEventListener('keydown', originalHandle);
        }
        if (typeof originalCheck === 'function') {
            checkBtn.removeEventListener('click', originalCheck);
        }

        function enhancedCheckText() {
            const state = getPracticeStateSafe();
            const originalSentence = coerceArray(state.sentences)[Number(state.currentSentenceIndex) || 0] || '';
            const rawUserInput = input.value;
            const attempt = classifyAttempt(rawUserInput, originalSentence, state);

            let result = null;
            if (typeof originalCheck === 'function') {
                result = originalCheck();
            }

            const manager = getManager();
            const shouldLog = !result || (result.status !== 'ignored' && result.status !== 'ignored-empty' && result.status !== 'ignored-duplicate');
            if (shouldLog && manager && typeof manager.logAttempt === 'function') {
                manager.logAttempt(attempt);
            }

        }

        function enhancedHandleKeyDown(event) {
            if (event.key === 'Enter') {
                event.preventDefault();
                if (event.repeat) {
                    return;
                }
                enhancedCheckText();
            } else if (event.key === 'Alt') {
                event.preventDefault();
                if (typeof showOriginalSentence === 'function') {
                    showOriginalSentence();
                }
            } else if (!event.altKey && typeof hideOriginalSentence === 'function') {
                hideOriginalSentence();
            }
        }

        input.addEventListener('keydown', enhancedHandleKeyDown);
        checkBtn.addEventListener('click', enhancedCheckText);
        input.dataset.v21Patched = '1';

        window.handleKeyDown = enhancedHandleKeyDown;
        window.checkText = enhancedCheckText;
    }

    function bootstrapV21Features() {
        injectStorageButtons();
        patchDisplayWordList();
        patchStatisticsManager();
        patchPracticeHandlers();
        injectOnboardingBanner();
        renderInsights();
        if (typeof displayWordList === 'function') {
            displayWordList();
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        // Run after the base app initialises (ui.js registers first).
        window.setTimeout(bootstrapV21Features, 0);
    });
})();
