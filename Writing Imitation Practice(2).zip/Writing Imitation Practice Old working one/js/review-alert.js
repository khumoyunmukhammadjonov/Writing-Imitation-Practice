(async function () {
  const REVIEW_DUE_CACHE_KEY = 'reviewDueCache';

  function safeJsonParse(value, fallback) {
    if (value == null) return fallback;
    if (typeof value !== 'string') return value;
    try {
      const parsed = JSON.parse(value);
      return parsed == null ? fallback : parsed;
    } catch (error) {
      return fallback;
    }
  }

  async function loadDueCache() {
    const raw = await chrome.storage.local.get([REVIEW_DUE_CACHE_KEY]);
    return safeJsonParse(raw[REVIEW_DUE_CACHE_KEY], {}) || {};
  }

  const title = document.getElementById('title');
  const body = document.getElementById('body');
  const secondary = document.getElementById('secondary');
  try {
    await chrome.runtime.sendMessage({ type: 'tugadi-reset-action-popup' });
  } catch (error) {
    // Ignore popup reset failures.
  }

  const cache = await loadDueCache();
  const pendingMistakes = Array.isArray(cache.pendingMistakes) ? cache.pendingMistakes : [];
  const dueMistakes = Array.isArray(cache.dueMistakes) ? cache.dueMistakes : [];
  const dueWordList = Array.isArray(cache.dueWordList) ? cache.dueWordList : [];
  const total = pendingMistakes.length + dueMistakes.length + dueWordList.length;

  if (total > 0) {
    title.textContent = 'You have words to review';
    body.textContent = 'Open the extension to continue.';
    secondary.textContent = 'Dismiss this reminder or open the extension now.';
  } else {
    title.textContent = 'No reviews due right now';
    body.textContent = 'You can still open the extension and keep practicing.';
    secondary.textContent = 'There is nothing due at the moment.';
  }

  document.getElementById('open-app').addEventListener('click', async () => {
    try {
      await chrome.runtime.sendMessage({ type: 'tugadi-open-extension-from-reminder' });
    } finally {
      window.close();
    }
  });

  document.getElementById('dismiss').addEventListener('click', async () => {
    try {
      await chrome.runtime.sendMessage({ type: 'tugadi-dismiss-review-reminder' });
    } finally {
      window.close();
    }
  });
})();
