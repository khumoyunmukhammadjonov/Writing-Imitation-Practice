/*
 * Central application namespace.
 *
 * This keeps shared services and state under one object while preserving
 * compatibility with classic script loading.
 */
(function bootstrapAppNamespace(global) {
    if (global.WritingImitationPractice) {
        return;
    }

    const app = {
        config: {
            storageLimitMB: 10
        },
        state: {
            practice: {
                sentences: [],
                currentSentenceIndex: 0,
                mistakeCount: 0,
                currentSentenceMistakeSet: new Set()
            }
        },
        services: {},
        modules: {
            storage: {},
            stats: {},
            practice: {},
            wordList: {},
            ui: {}
        },
        utils: {},
        dom: {
            get(id) {
                return document.getElementById(id);
            }
        },
        setService(name, value) {
            this.services[name] = value;
            return value;
        },
        getService(name) {
            return this.services[name] || null;
        },
        getStatisticsManager() {
            return this.getService('statisticsManager');
        },
        getSpacedRepetitionManager() {
            return this.getService('spacedRepetitionManager');
        }
    };

    global.WritingImitationPractice = app;
})(window);


/*
 * Shared letter-reconstruction helper used by rewrite practice.
 * It turns an input + bank container into a click-to-build puzzle where
 * the user must tap the letters in the correct order.
 */
(function registerLetterRebuildHelper(global) {
    function shuffleLetters(list) {
        const original = list.slice();
        const shuffled = list.slice();
        if (shuffled.length <= 1) {
            return shuffled;
        }

        let attempts = 0;
        do {
            for (let i = shuffled.length - 1; i > 0; i -= 1) {
                const j = Math.floor(Math.random() * (i + 1));
                const temp = shuffled[i];
                shuffled[i] = shuffled[j];
                shuffled[j] = temp;
            }
            attempts += 1;
        } while (attempts < 6 && shuffled.join('') === original.join(''));

        return shuffled;
    }

    function isAutoFilledCharacter(character) {
        return !/[0-9A-Za-zÀ-ÖØ-öø-ÿ]/.test(character || '');
    }

    function advanceIndex(chars, built, startIndex) {
        let index = startIndex;
        while (index < chars.length && built[index] !== '') {
            index += 1;
        }
        return index;
    }

    global.setupLetterRebuild = function setupLetterRebuild(options) {
        const {
            target,
            inputEl,
            bankEl,
            onComplete,
            instructionText
        } = options || {};

        if (!inputEl || !bankEl) {
            return null;
        }

        const safeTarget = String(target || '');
        const chars = safeTarget.split('');
        const built = chars.map((character) => (isAutoFilledCharacter(character) ? character : ''));
        const clickableChars = chars.filter((character) => !isAutoFilledCharacter(character));
        let currentIndex = advanceIndex(chars, built, 0);

        inputEl.value = built.join('');
        inputEl.readOnly = true;
        inputEl.setAttribute('aria-readonly', 'true');
        inputEl.placeholder = 'Tap the letters in order';
        inputEl.classList.remove('correct', 'incorrect');

        bankEl.innerHTML = '';
        bankEl.classList.add('letter-bank');

        if (instructionText) {
            const instructionEl = document.createElement('div');
            instructionEl.className = 'letter-bank-instruction';
            instructionEl.textContent = instructionText;
            bankEl.appendChild(instructionEl);
        }

        const buttonsWrap = document.createElement('div');
        buttonsWrap.className = 'letter-bank-buttons';
        bankEl.appendChild(buttonsWrap);

        const renderInput = () => {
            inputEl.value = built.join('');
        };

        const finishIfComplete = () => {
            if (currentIndex >= chars.length) {
                inputEl.classList.remove('incorrect');
                inputEl.classList.add('correct');
                if (typeof onComplete === 'function') {
                    onComplete();
                }
            }
        };

        shuffleLetters(clickableChars).forEach((character) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'letter-chip';
            button.textContent = character;
            button.setAttribute('aria-label', `Letter ${character}`);
            button.addEventListener('click', () => {
                if (button.disabled || currentIndex >= chars.length) {
                    return;
                }

                const expected = chars[currentIndex];
                if (character.toLowerCase() === String(expected).toLowerCase()) {
                    built[currentIndex] = expected;
                    button.disabled = true;
                    button.classList.remove('incorrect');
                    button.classList.add('used');
                    inputEl.classList.remove('incorrect');
                    renderInput();
                    currentIndex = advanceIndex(chars, built, currentIndex + 1);
                    finishIfComplete();
                } else {
                    button.classList.add('incorrect');
                    inputEl.classList.remove('correct');
                    inputEl.classList.add('incorrect');
                    setTimeout(() => {
                        button.classList.remove('incorrect');
                        inputEl.classList.remove('incorrect');
                    }, 450);
                }
            });
            buttonsWrap.appendChild(button);
        });

        finishIfComplete();
        return {
            target: safeTarget,
            destroy() {
                bankEl.innerHTML = '';
                inputEl.value = '';
                inputEl.classList.remove('correct', 'incorrect');
            }
        };
    };
})(window);
