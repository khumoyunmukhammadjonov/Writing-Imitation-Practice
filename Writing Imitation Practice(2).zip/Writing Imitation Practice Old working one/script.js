/*
 * Legacy monolithic script retired.
 *
 * The extension now loads:
 *   - js/app-core.js
 *   - js/storage.js
 *   - js/stats.js
 *   - js/practice.js
 *   - js/word-list.js
 *   - js/ui.js
 *
 * Styles are also split into /css for easier maintenance.
 */
