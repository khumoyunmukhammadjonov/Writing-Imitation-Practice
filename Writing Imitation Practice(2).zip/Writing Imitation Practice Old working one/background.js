// background.js - service worker for the Writing Imitation Practice extension

const REVIEW_NOTIFICATION_STATE_KEY = 'reviewNotificationState';
const REVIEW_DUE_CACHE_KEY = 'reviewDueCache';
const NEXT_DUE_ALARM = 'review-next-due';
const SAFETY_CHECK_ALARM = 'review-safety-check';
const REVIEW_NOTIFICATION_ID = 'tugadi-review-ready';
const SAFETY_CHECK_PERIOD_MINUTES = 1;
const NOTIFICATION_REPEAT_COOLDOWN_MS = 60 * 60 * 1000;
const OPEN_EXTENSION_BUTTON_INDEX = 0;
const DISMISS_BUTTON_INDEX = 1;
const REMINDER_ACTION_POPUP = 'review-alert.html';
const DEFAULT_ACTION_POPUP = '';

function normalizeWordKey(value) {
  if (value && typeof value === 'object') {
    const candidate = value.word ?? value.text ?? value.value ?? value.term ?? value.label;
    value = candidate == null ? '' : candidate;
  }

  return String(value ?? '')
    .replace(/[.,!?]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function safeJsonParse(value, fallback) {
  if (value == null) return fallback;
  if (typeof value !== 'string') return value;
  try {
    const parsed = JSON.parse(value);
    return parsed == null ? fallback : parsed;
  } catch (error) {
    return fallback;
  }
}


function getPendingInitialMistakes(todayStats, now = Date.now()) {
  const stats = todayStats && typeof todayStats === 'object' ? todayStats : {};
  const mistakes = Array.isArray(stats.mistakes) ? stats.mistakes : [];
  const todayStart = new Date(now);
  todayStart.setHours(0, 0, 0, 0);
  const todayStartMs = todayStart.getTime();

  return mistakes.filter((mistake) => {
    if (!mistake || mistake.type === 'wordList' || mistake.spaced) {
      return false;
    }

    const baseCorrect = normalizeWordKey(mistake.correct || mistake.incorrect || '');
    if (!baseCorrect) {
      return false;
    }

    const timestamp = mistake.timestamp ? new Date(mistake.timestamp).getTime() : Number.NaN;
    return Number.isNaN(timestamp) || timestamp < todayStartMs;
  });
}

async function setActionPopup(popupPath = DEFAULT_ACTION_POPUP) {
  try {
    if (chrome.action && typeof chrome.action.setPopup === 'function') {
      await chrome.action.setPopup({ popup: popupPath || '' });
    }
  } catch (error) {
    console.warn('Could not set action popup.', error);
  }
}

function parseScheduleKey(scheduleKey, entry) {
  const raw = String(scheduleKey || '');
  if (raw.includes(':')) {
    const [prefix, ...rest] = raw.split(':');
    const inferred = prefix === 'wordList' ? 'wordList' : 'mistake';
    return {
      type: entry && entry.type ? entry.type : inferred,
      word: rest.join(':')
    };
  }
  return {
    type: entry && entry.type === 'wordList' ? 'wordList' : 'mistake',
    word: raw
  };
}

async function getStorageSnapshot() {
  const raw = await chrome.storage.local.get([
    'spacedSchedule',
    'wordList',
    'todayStats',
    REVIEW_NOTIFICATION_STATE_KEY
  ]);

  return {
    schedule: safeJsonParse(raw.spacedSchedule, {}) || {},
    wordList: safeJsonParse(raw.wordList, []) || [],
    todayStats: safeJsonParse(raw.todayStats, {}) || {},
    notificationState: safeJsonParse(raw[REVIEW_NOTIFICATION_STATE_KEY], {}) || {}
  };
}


function buildReviewSummary(schedule, wordList, todayStats, now = Date.now()) {
  const wordSet = new Set((Array.isArray(wordList) ? wordList : []).map(normalizeWordKey).filter(Boolean));
  const pendingMistakes = getPendingInitialMistakes(todayStats, now)
    .map((mistake) => normalizeWordKey(mistake && (mistake.correct || mistake.incorrect || '')))
    .filter(Boolean);
  const blockedPendingWordSet = new Set(pendingMistakes);
  const dueMistakes = [];
  const dueWordList = [];
  let nextFutureDue = null;

  for (const [key, entry] of Object.entries(schedule || {})) {
    if (!entry || entry.mastered) continue;
    const parsed = parseScheduleKey(key, entry);
    const word = normalizeWordKey(parsed.word);
    if (!word) continue;

    if (parsed.type === 'wordList' && !wordSet.has(word)) {
      continue;
    }

    const nextDue = Number(entry.nextDue);
    if (!Number.isFinite(nextDue)) continue;

    if (nextDue <= now) {
      if (parsed.type === 'wordList') {
        dueWordList.push(word);
      } else if (!blockedPendingWordSet.has(word)) {
        dueMistakes.push(word);
      }
      continue;
    }

    if (nextFutureDue == null || nextDue < nextFutureDue) {
      nextFutureDue = nextDue;
    }
  }

  pendingMistakes.sort();
  dueMistakes.sort();
  dueWordList.sort();

  return {
    pendingMistakes,
    dueMistakes,
    dueWordList,
    nextFutureDue
  };
}

function buildSummarySignature(summary) {
  const pendingMistakes = Array.isArray(summary?.pendingMistakes) ? summary.pendingMistakes : [];
  const mistakes = Array.isArray(summary?.dueMistakes) ? summary.dueMistakes : [];
  const wordList = Array.isArray(summary?.dueWordList) ? summary.dueWordList : [];
  return JSON.stringify({ pendingMistakes, mistakes, wordList });
}

function getDueCount(summary) {
  return (Array.isArray(summary?.pendingMistakes) ? summary.pendingMistakes.length : 0)
    + (Array.isArray(summary?.dueMistakes) ? summary.dueMistakes.length : 0)
    + (Array.isArray(summary?.dueWordList) ? summary.dueWordList.length : 0);
}

function getNotificationTitle() {
  return 'Review ready';
}

function getNotificationMessage() {
  return 'You have words to review. Open the extension to continue.';
}

async function getNotificationPermissionLevel() {
  try {
    if (chrome.notifications && typeof chrome.notifications.getPermissionLevel === 'function') {
      return await chrome.notifications.getPermissionLevel();
    }
  } catch (error) {
    console.warn('Could not read notification permission level.', error);
  }
  return 'granted';
}

async function saveNotificationState(state) {
  await chrome.storage.local.set({
    [REVIEW_NOTIFICATION_STATE_KEY]: JSON.stringify(state || {})
  });
}

async function clearReviewNotification() {
  try {
    await chrome.notifications.clear(REVIEW_NOTIFICATION_ID);
  } catch (error) {
    console.warn('Could not clear review notification.', error);
  }
}

async function isReviewNotificationVisible() {
  try {
    const existing = await chrome.notifications.getAll();
    return !!(existing && Object.prototype.hasOwnProperty.call(existing, REVIEW_NOTIFICATION_ID));
  } catch (error) {
    console.warn('Could not list current notifications.', error);
    return false;
  }
}

async function showNativeReviewNotification() {
  const permissionLevel = await getNotificationPermissionLevel();
  if (permissionLevel !== 'granted') {
    console.warn('Review notification not shown because permission is not granted.', permissionLevel);
    return { shown: false, permissionLevel, channel: 'native' };
  }

  try {
    try {
      await chrome.notifications.clear(REVIEW_NOTIFICATION_ID);
    } catch (error) {
      // Ignore clear failures before create.
    }

    const id = await chrome.notifications.create(REVIEW_NOTIFICATION_ID, {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon128.png'),
      title: getNotificationTitle(),
      message: getNotificationMessage(),
      buttons: [
        { title: 'Open extension' },
        { title: 'Dismiss' }
      ],
      priority: 2,
      requireInteraction: true,
      silent: false
    });

    console.info('Created native review notification.', id);
    return { shown: true, permissionLevel, id, channel: 'native' };
  } catch (error) {
    console.warn('Failed to create native review notification.', error);
    return { shown: false, permissionLevel, error: String(error), channel: 'native' };
  }
}

async function showActionPopupReminder() {
  if (!chrome.action || typeof chrome.action.openPopup !== 'function') {
    return { shown: false, reason: 'openPopup-unavailable', channel: 'popup' };
  }

  try {
    await setActionPopup(REMINDER_ACTION_POPUP);
    await chrome.action.openPopup();
    console.info('Opened action popup reminder.');
    return { shown: true, channel: 'popup' };
  } catch (error) {
    console.warn('Failed to open action popup reminder.', error);
    await setActionPopup(DEFAULT_ACTION_POPUP);
    return { shown: false, error: String(error), channel: 'popup' };
  }
}

async function showReviewReminder() {
  const popupResult = await showActionPopupReminder();
  if (popupResult.shown) {
    await clearReviewNotification();
    return popupResult;
  }

  await setActionPopup(DEFAULT_ACTION_POPUP);
  return showNativeReviewNotification();
}

async function updateActionBadge(summary) {
  try {
    const count = getDueCount(summary);

    if (count > 0) {
      await chrome.action.setBadgeBackgroundColor({ color: '#d4a017' });
      await chrome.action.setBadgeText({ text: String(Math.min(count, 99)) });
      await chrome.action.setTitle({ title: `${count} review${count === 1 ? '' : 's'} ready` });
    } else {
      await chrome.action.setBadgeText({ text: '' });
      await chrome.action.setTitle({ title: 'Writing Imitation Practice' });
    }
  } catch (error) {
    console.warn('Could not update action badge.', error);
  }
}

async function saveReviewDueCache(summary) {
  await chrome.storage.local.set({
    [REVIEW_DUE_CACHE_KEY]: JSON.stringify({
      checkedAt: new Date().toISOString(),
      pendingMistakes: Array.isArray(summary?.pendingMistakes) ? summary.pendingMistakes : [],
      dueMistakes: Array.isArray(summary?.dueMistakes) ? summary.dueMistakes : [],
      dueWordList: Array.isArray(summary?.dueWordList) ? summary.dueWordList : [],
      nextFutureDue: Number.isFinite(summary?.nextFutureDue) ? Number(summary.nextFutureDue) : null
    })
  });
}

async function markNotificationDismissed(dismissedAt) {
  const raw = await chrome.storage.local.get([REVIEW_NOTIFICATION_STATE_KEY]);
  const state = safeJsonParse(raw[REVIEW_NOTIFICATION_STATE_KEY], {}) || {};
  state.dismissedAt = dismissedAt;
  if (dismissedAt) {
    state.lastInteraction = 'dismissed';
  }
  await saveNotificationState(state);
}

async function getReviewLaunchContext() {
  try {
    const raw = await chrome.storage.local.get([REVIEW_DUE_CACHE_KEY]);
    const cache = safeJsonParse(raw[REVIEW_DUE_CACHE_KEY], {}) || {};
    const pendingMistakes = Array.isArray(cache.pendingMistakes) ? cache.pendingMistakes : [];
    const dueMistakes = Array.isArray(cache.dueMistakes) ? cache.dueMistakes : [];
    const dueWordList = Array.isArray(cache.dueWordList) ? cache.dueWordList : [];

    if (pendingMistakes.length > 0) {
      return { reviewKind: 'pendingMistakes', reviewCount: pendingMistakes.length };
    }
    if (dueMistakes.length > 0) {
      return { reviewKind: 'dueMistakes', reviewCount: dueMistakes.length };
    }
    if (dueWordList.length > 0) {
      return { reviewKind: 'dueVocab', reviewCount: dueWordList.length };
    }
  } catch (error) {
    console.warn('Could not build review launch context from cache.', error);
  }

  try {
    const { schedule, wordList, todayStats } = await getStorageSnapshot();
    const summary = buildReviewSummary(schedule, wordList, todayStats, Date.now());
    if (Array.isArray(summary.pendingMistakes) && summary.pendingMistakes.length > 0) {
      return { reviewKind: 'pendingMistakes', reviewCount: summary.pendingMistakes.length };
    }
    if (Array.isArray(summary.dueMistakes) && summary.dueMistakes.length > 0) {
      return { reviewKind: 'dueMistakes', reviewCount: summary.dueMistakes.length };
    }
    if (Array.isArray(summary.dueWordList) && summary.dueWordList.length > 0) {
      return { reviewKind: 'dueVocab', reviewCount: summary.dueWordList.length };
    }
  } catch (error) {
    console.warn('Could not build review launch context from storage snapshot.', error);
  }

  return null;
}

function buildExtensionURL(launchContext = null) {
  const url = new URL(chrome.runtime.getURL('index.html'));
  if (launchContext && launchContext.reviewKind && Number(launchContext.reviewCount) > 0) {
    url.searchParams.set('openReview', '1');
    url.searchParams.set('reviewKind', launchContext.reviewKind);
    url.searchParams.set('reviewCount', String(launchContext.reviewCount));
  }
  return url.toString();
}

async function openExtensionPage(launchContext = null) {
  await chrome.tabs.create({ url: buildExtensionURL(launchContext) });
}

async function syncReviewNotifications(options = {}) {
  const force = !!options.force;
  const reason = options.reason || 'unknown';
  const suppressReminder = !!options.suppressReminder;
  const { schedule, wordList, todayStats, notificationState } = await getStorageSnapshot();
  const summary = buildReviewSummary(schedule, wordList, todayStats, Date.now());
  const dueCount = getDueCount(summary);
  const signature = buildSummarySignature(summary);
  const now = Date.now();
  const currentState = notificationState && typeof notificationState === 'object' ? notificationState : {};
  const nextState = {
    signature,
    shownAt: Number(currentState.shownAt) || 0,
    dismissedAt: Number(currentState.dismissedAt) || 0,
    lastInteraction: currentState.lastInteraction || '',
    notificationPermissionLevel: String(currentState.notificationPermissionLevel || 'unknown'),
    deliveryChannel: String(currentState.deliveryChannel || 'unknown')
  };

  if (dueCount <= 0) {
    await clearReviewNotification();
    await setActionPopup(DEFAULT_ACTION_POPUP);
    nextState.signature = '';
    nextState.shownAt = 0;
    nextState.dismissedAt = 0;
    nextState.lastInteraction = 'cleared-no-due-items';
    nextState.deliveryChannel = 'none';
    await saveReviewDueCache(summary);
    await updateActionBadge(summary);
    await saveNotificationState(nextState);
    await scheduleNextDueAlarm(summary.nextFutureDue);
    console.info('Review sync complete: no due items.', { reason });
    return;
  }

  const notificationVisible = await isReviewNotificationVisible();
  const signatureChanged = signature !== String(currentState.signature || '');
  const cooldownExpired = now - nextState.shownAt >= NOTIFICATION_REPEAT_COOLDOWN_MS;
  const dismissedRecently = nextState.dismissedAt > 0 && (now - nextState.dismissedAt) < NOTIFICATION_REPEAT_COOLDOWN_MS;
  const shouldShow = force
    || signatureChanged
    || nextState.shownAt === 0
    || cooldownExpired;

  console.info('Review sync decision.', {
    reason,
    force,
    dueCount,
    notificationVisible,
    signatureChanged,
    cooldownExpired,
    dismissedRecently,
    shownAt: nextState.shownAt,
    dismissedAt: nextState.dismissedAt
  });

  if (!suppressReminder && shouldShow && (!dismissedRecently || force)) {
    const result = await showReviewReminder();
    nextState.notificationPermissionLevel = result.permissionLevel || nextState.notificationPermissionLevel;
    nextState.deliveryChannel = result.channel || nextState.deliveryChannel;
    if (result.shown) {
      nextState.shownAt = now;
      nextState.dismissedAt = 0;
      nextState.lastInteraction = `shown:${reason}:${result.channel || 'unknown'}`;
    }
  }

  await saveReviewDueCache(summary);
  await updateActionBadge(summary);
  await saveNotificationState(nextState);
  await scheduleNextDueAlarm(summary.nextFutureDue);
}

async function scheduleNextDueAlarm(nextFutureDue) {
  try {
    await chrome.alarms.clear(NEXT_DUE_ALARM);
  } catch (error) {
    console.warn('Could not clear next-due alarm.', error);
  }

  if (Number.isFinite(nextFutureDue)) {
    const when = Math.max(Date.now() + 5000, Number(nextFutureDue));
    chrome.alarms.create(NEXT_DUE_ALARM, { when });
  }

  chrome.alarms.create(SAFETY_CHECK_ALARM, {
    delayInMinutes: SAFETY_CHECK_PERIOD_MINUTES,
    periodInMinutes: SAFETY_CHECK_PERIOD_MINUTES
  });
}

async function initializeReviewNotifications(options = {}) {
  try {
    await syncReviewNotifications(options);
  } catch (error) {
    console.warn('Unable to initialize review notifications.', error);
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  setActionPopup(DEFAULT_ACTION_POPUP)
    .catch(() => {})
    .finally(() => saveNotificationState({})
      .catch(() => {})
      .finally(() => initializeReviewNotifications({ force: true, reason: `installed:${details?.reason || 'unknown'}` }))
    );
});

chrome.runtime.onStartup.addListener(() => {
  initializeReviewNotifications({ reason: 'startup' });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (!alarm) return;
  if (alarm.name === NEXT_DUE_ALARM || alarm.name === SAFETY_CHECK_ALARM) {
    initializeReviewNotifications({ reason: `alarm:${alarm.name}` });
  }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') return;
  if (changes.spacedSchedule || changes.wordList || changes.todayStats) {
    initializeReviewNotifications({ reason: 'storage-change' });
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || !message.type) {
    return false;
  }

  if (message.type === 'tugadi-sync-review-check') {
    const reason = message.reason || 'message-sync';
    initializeReviewNotifications({ reason, suppressReminder: reason === 'popup-open' })
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.warn('Unable to sync review notifications from message.', error);
        sendResponse({ ok: false });
      });

    return true;
  }

  if (message.type === 'tugadi-reset-action-popup') {
    setActionPopup(DEFAULT_ACTION_POPUP)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.warn('Unable to reset action popup.', error);
        sendResponse({ ok: false });
      });
    return true;
  }

  if (message.type === 'tugadi-dismiss-review-reminder') {
    setActionPopup(DEFAULT_ACTION_POPUP)
      .catch(() => {})
      .then(() => markNotificationDismissed(Date.now()))
      .then(() => clearReviewNotification())
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.warn('Unable to dismiss review reminder.', error);
        sendResponse({ ok: false });
      });
    return true;
  }

  if (message.type === 'tugadi-open-extension-from-reminder') {
    setActionPopup(DEFAULT_ACTION_POPUP)
      .catch(() => {})
      .then(() => markNotificationDismissed(0))
      .then(() => clearReviewNotification())
      .then(() => getReviewLaunchContext())
      .then((launchContext) => openExtensionPage(launchContext))
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.warn('Unable to open extension from reminder.', error);
        sendResponse({ ok: false });
      });
    return true;
  }

  return false;
});

chrome.action.onClicked.addListener(() => {
  openExtensionPage().catch((error) => {
    console.warn('Unable to open extension from action click.', error);
  });
});

chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
  if (notificationId !== REVIEW_NOTIFICATION_ID) return;

  if (buttonIndex === OPEN_EXTENSION_BUTTON_INDEX) {
    markNotificationDismissed(0)
      .catch(() => {})
      .finally(async () => {
        await clearReviewNotification();
        const launchContext = await getReviewLaunchContext();
        await openExtensionPage(launchContext);
      });
    return;
  }

  if (buttonIndex === DISMISS_BUTTON_INDEX) {
    markNotificationDismissed(Date.now())
      .catch(() => {})
      .finally(() => clearReviewNotification());
  }
});

chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId !== REVIEW_NOTIFICATION_ID) return;

  markNotificationDismissed(0)
    .catch(() => {})
    .finally(async () => {
      await clearReviewNotification();
      const launchContext = await getReviewLaunchContext();
      await openExtensionPage(launchContext);
    });
});

chrome.notifications.onClosed.addListener((notificationId, byUser) => {
  if (notificationId !== REVIEW_NOTIFICATION_ID || !byUser) return;
  markNotificationDismissed(Date.now()).catch(() => {});
});

// Run once when the service worker wakes so alarms stay in sync.
setActionPopup(DEFAULT_ACTION_POPUP).catch(() => {});
initializeReviewNotifications({ reason: 'service-worker-wake' });
